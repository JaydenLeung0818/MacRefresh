// Tools.swift — v1.0.1 additions:
// update history & one-click rollback, network monitor, signature cache,
// storage maintenance, extra report formats, appearance / quiet hours /
// snooze / skipped-version / favorites support, and the Tools pane.
import Cocoa
import Network
import UniformTypeIdentifiers

/// A button that carries an arbitrary payload (NSButton has no
/// `representedObject`; that property exists on NSMenuItem).
final class PayloadButton: NSButton {
    var payload: Any?
    var url: URL? { payload as? URL }
}

// MARK: - Update history

enum HistoryKind: String, Codable {
    case updated, installed, downloaded, installerOpened, failed, rolledBack
    var text: String {
        switch self {
        case .updated: return "Updated"
        case .installed: return "Installed"
        case .downloaded: return "Downloaded"
        case .installerOpened: return "Installer opened"
        case .failed: return "Failed"
        case .rolledBack: return "Rolled back"
        }
    }
}

struct HistoryEvent: Codable {
    var date: Date = Date()
    var kind: HistoryKind
    var appName: String
    var bundleID: String
    var fromVersion: String
    var toVersion: String
    var detail: String
    var rollbackPath: String?
}

final class HistoryStore {
    static let shared = HistoryStore()
    private let lock = NSLock()
    private(set) var events: [HistoryEvent] = []

    private var url: URL { supportDirectory().appendingPathComponent("History.json") }

    init() { load() }

    private func load() {
        guard let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder.macRefresh.decode([HistoryEvent].self, from: data) else { return }
        events = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder.macRefresh.encode(events) else { return }
        try? data.write(to: url, options: .atomic)
    }

    func record(_ event: HistoryEvent) {
        lock.lock()
        events.append(event)
        // Keep 180 days and at most 1000 events.
        let cutoff = Date().addingTimeInterval(-180 * 86400)
        events = events.filter { $0.date >= cutoff }
        if events.count > 1000 { events.removeFirst(events.count - 1000) }
        let snapshot = events
        lock.unlock()
        DispatchQueue.global(qos: .utility).async {
            if let data = try? JSONEncoder.macRefresh.encode(snapshot) {
                try? data.write(to: self.url, options: .atomic)
            }
        }
    }

    func clear() {
        lock.lock(); events.removeAll(); lock.unlock()
        try? FileManager.default.removeItem(at: url)
    }

    /// Newest first, for display.
    var displayed: [HistoryEvent] { events.reversed() }
}

extension JSONDecoder {
    static var macRefresh: JSONDecoder {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }
}

extension JSONEncoder {
    static var macRefresh: JSONEncoder {
        let e = JSONEncoder()
        e.dateEncodingStrategy = .iso8601
        return e
    }
}

// MARK: - Network monitor

final class NetworkMonitor {
    static let shared = NetworkMonitor()
    private let monitor = NWPathMonitor()
    private(set) var online = true
    var onChange: (() -> Void)?
    private var started = false

    func start() {
        guard !started else { return }
        started = true
        monitor.pathUpdateHandler = { [weak self] path in
            let ok = path.status == .satisfied
            DispatchQueue.main.async {
                self?.online = ok
                self?.onChange?()
            }
        }
        monitor.start(queue: DispatchQueue(label: "com.macrefresh.network"))
    }
}

// MARK: - Signature metadata cache

final class SignatureCache {
    static let shared = SignatureCache()
    private var storage: [String: (summary: String, team: String?)] = [:]
    private let lock = NSLock()

    func cached(for path: String) -> (summary: String, team: String?)? {
        lock.lock(); defer { lock.unlock() }
        return storage[path]
    }

    func reset() {
        lock.lock(); storage.removeAll(); lock.unlock()
    }

    /// Warm signatures for a list of app paths in the background with bounded
    /// concurrency, calling `changed` on the main thread after each batch so a
    /// table can fill its Signature column progressively instead of staying
    /// blank until the user manually runs "Verify all signatures".
    func prefetch(paths: [String], changed: (() -> Void)? = nil) {
        let pending = paths.filter { self.cached(for: $0) == nil }
        guard !pending.isEmpty else { return }
        DispatchQueue.global(qos: .utility).async {
            let maxConcurrent = 4
            var cursor = 0
            let cursorLock = NSLock()
            func next() -> String? {
                cursorLock.lock(); defer { cursorLock.unlock() }
                guard cursor < pending.count else { return nil }
                let p = pending[cursor]; cursor += 1
                return p
            }
            let group = DispatchGroup()
            for _ in 0..<maxConcurrent {
                group.enter()
                DispatchQueue.global(qos: .utility).async {
                    while let path = next() {
                        let one = DispatchSemaphore(value: 0)
                        self.signature(for: path) { _, _ in one.signal() }
                        _ = one.wait(timeout: .now() + 30)
                        DispatchQueue.main.async { changed?() }
                    }
                    group.leave()
                }
            }
            group.wait()
        }
    }

    /// Returns ("Signed"|"Ad-hoc"|"Unsigned", teamID). Computed off the calling thread.
    func signature(for path: String, completion: @escaping (String, String?) -> Void) {
        if let c = cached(for: path) { completion(c.summary, c.team); return }
        DispatchQueue.global(qos: .utility).async {
            let r = Installer.runProc("/usr/bin/codesign",
                                      ["-dv", "--verbose=4", path], timeout: 30)
            let out = r.output
            var summary = "Unsigned"
            if out.contains("Signature=adhoc") {
                summary = "Ad-hoc"
            } else if out.contains("Authority=") {
                summary = "Signed"
            } else if r.code == 0 {
                summary = "Signed"
            }
            var team: String?
            if let line = out.split(separator: "\n").first(where: { $0.contains("TeamIdentifier=") }) {
                let t = String(line.split(separator: "=").last ?? "")
                if t.count == 10, t != "not set" { team = t }
            }
            self.lock.lock()
            self.storage[path] = (summary, team)
            self.lock.unlock()
            DispatchQueue.main.async { completion(summary, team) }
        }
    }
}

// MARK: - Appearance / quiet hours / snooze

func applyAppearance(mode: String? = nil) {
    let m = mode ?? (UserDefaults.standard.string(forKey: Prefs.appearanceMode) ?? "system")
    switch m {
    case "light": NSApp.appearance = NSAppearance(named: .aqua)
    case "dark": NSApp.appearance = NSAppearance(named: .darkAqua)
    default: NSApp.appearance = nil
    }
}

/// Snooze scheduled checks until the given date; nil clears the snooze.
func setSnooze(until date: Date?) {
    UserDefaults.standard.set(date.map { $0.ISO8601() } ?? "", forKey: Prefs.snoozeUntil)
}

extension Date {
    func ISO8601() -> String {
        ISO8601DateFormatter().string(from: self)
    }
}

func snoozeUntilDate() -> Date? {
    let s = UserDefaults.standard.string(forKey: Prefs.snoozeUntil) ?? ""
    guard !s.isEmpty else { return nil }
    return ISO8601DateFormatter().date(from: s)
}

func isSnoozing(now: Date = Date()) -> Bool {
    guard let until = snoozeUntilDate() else { return false }
    if until > now { return true }
    setSnooze(until: nil)
    return false
}

// MARK: - Filesystem maintenance helpers

func directorySize(_ url: URL) -> Int64 {
    let fm = FileManager.default
    // Plain files (cask.json, appstore.json) have no enumerator; read their
    // allocated size directly, otherwise they always reported "Zero KB".
    var isDir: ObjCBool = false
    if fm.fileExists(atPath: url.path, isDirectory: &isDir) && !isDir.boolValue {
        if let v = try? url.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .fileAllocatedSizeKey]),
           let n = v.totalFileAllocatedSize ?? v.fileAllocatedSize {
            return Int64(n)
        }
        return (try? fm.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value ?? 0
    }
    guard let en = fm.enumerator(at: url,
                                 includingPropertiesForKeys: [.totalFileAllocatedSizeKey, .isRegularFileKey])
    else { return 0 }
    var total: Int64 = 0
    for case let u as URL in en {
        if let v = try? u.resourceValues(forKeys: [.totalFileAllocatedSizeKey]),
           let n = v.totalFileAllocatedSize { total += Int64(n) }
    }
    return total
}

func diskFreeBytes() -> Int64? {
    let vals = try? URL(fileURLWithPath: "/").resourceValues(
        forKeys: [.volumeAvailableCapacityForImportantUsageKey])
    return (vals?.volumeAvailableCapacityForImportantUsage).map { Int64($0) }
}

enum Maintenance {
    static func clearCatalog() {
        try? FileManager.default.removeItem(at: caskCacheURL())
    }
    static func clearAppStoreCache() {
        try? FileManager.default.removeItem(at: supportDirectory().appendingPathComponent("appstore.json"))
    }
    static func clearIcons() {
        ShopIconCache.shared.resetMissing()
        BundleMetaCache.shared.reset()
        SignatureCache.shared.reset()
        try? FileManager.default.removeItem(at: supportDirectory().appendingPathComponent("Icons"))
    }
    static func clearLogs() {
        let dir = supportDirectory().appendingPathComponent("Logs")
        if let entries = try? FileManager.default.contentsOfDirectory(atPath: dir.path) {
            for e in entries { try? FileManager.default.removeItem(at: dir.appendingPathComponent(e)) }
        }
    }
    static func clearDownloads() {
        let dir = supportDirectory().appendingPathComponent("Downloads")
        if let entries = try? FileManager.default.contentsOfDirectory(atPath: dir.path) {
            for e in entries { try? FileManager.default.removeItem(at: dir.appendingPathComponent(e)) }
        }
    }
    static func clearRollbacks() {
        let dir = supportDirectory().appendingPathComponent("Parked")
        if let entries = try? FileManager.default.contentsOfDirectory(atPath: dir.path) {
            for e in entries { try? FileManager.default.removeItem(at: dir.appendingPathComponent(e)) }
        }
    }

    static func storageBreakdown() -> [(name: String, url: URL, clearable: Bool)] {
        let base = supportDirectory()
        return [
            ("App catalog (cask.json)", base.appendingPathComponent("cask.json"), true),
            ("App Store cache", base.appendingPathComponent("appstore.json"), true),
            ("App icons", base.appendingPathComponent("Icons"), true),
            ("Logs", base.appendingPathComponent("Logs"), true),
            ("Downloaded installers", base.appendingPathComponent("Downloads"), true),
            ("Rollback builds", base.appendingPathComponent("Parked"), true)
        ]
    }
}

// MARK: - Reports

func markdownReport(rows: [AppRow]) -> String {
    let now = Date()
    let f = DateFormatter()
    f.dateStyle = .medium; f.timeStyle = .short
    var md = "# MacRefresh App Report\n\n"
    md += "Generated: \(f.string(from: now))\n\n"
    let updates = rows.filter { $0.status == .update }.count
    let noSource = rows.filter { $0.status == .unknown }.count
    let dups = rows.filter { $0.isDuplicate }.count
    md += "- Apps found: \(rows.count)\n- Updates available: \(updates)\n"
    md += "- No update source: \(noSource)\n- Duplicate copies: \(dups)\n\n"
    md += "| App | Installed | Latest | Source | Status | Path |\n"
    md += "|---|---|---|---|---|---|\n"
    for r in rows {
        md += "| \(r.name) | \(r.installed) | \(r.latest ?? "—") | \(r.source) "
            + "| \(statusText(r.status)) | \(r.path) |\n"
    }
    return md
}

func plainTextReport(rows: [AppRow]) -> String {
    var lines = ["MacRefresh App Report", ""]
    for r in rows {
        lines.append("\(r.name)\t\(r.installed)\t\(r.latest ?? "—")\t\(r.source)\t\(statusText(r.status))\t\(r.path)")
    }
    return lines.joined(separator: "\n")
}

func writePDFReport(rows: [AppRow], to url: URL) {
    let tv = NSTextView(frame: NSRect(x: 0, y: 0, width: 612, height: 792))
    tv.isEditable = false
    tv.isRichText = false
    tv.font = NSFont(name: "Menlo", size: 9) ?? .monospacedSystemFont(ofSize: 9, weight: .regular)
    tv.string = plainTextReport(rows: rows)
    let data = tv.dataWithPDF(inside: tv.bounds)
    try? data.write(to: url, options: .atomic)
}

func diagnosticsText() -> String {
    let d = runDiagnostics()
    let os = ProcessInfo.processInfo.operatingSystemVersion
    var lines = [
        "MacRefresh \(MacRefreshVersion) diagnostics",
        "macOS \(os.majorVersion).\(os.minorVersion).\(os.patchVersion) · \(Arch.isIntel ? "Intel" : "Apple Silicon")",
        "Date: \(Date())",
        "Network: \(NetworkMonitor.shared.online ? "online" : "offline")",
        ""
    ]
    lines.append(contentsOf: d.lines)
    return lines.joined(separator: "\n")
}

// MARK: - AppDelegate: Tools pane

extension AppDelegate {

    @objc func buildTools() -> NSView {
        let outer = NSView()
        let head = header(title: "Tools", subtitle: "History & rollback, storage, reports, maintenance and extra preferences")
        head.translatesAutoresizingMaskIntoConstraints = false
        outer.addSubview(head)

        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.borderType = .noBorder
        scroll.autohidesScrollers = true
        scroll.translatesAutoresizingMaskIntoConstraints = false
        outer.addSubview(scroll)
        let stack = NSStackView()
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 10
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.documentView = stack
        stack.leadingAnchor.constraint(equalTo: scroll.contentView.leadingAnchor).isActive = true
        stack.trailingAnchor.constraint(equalTo: scroll.contentView.trailingAnchor).isActive = true
        stack.topAnchor.constraint(equalTo: scroll.contentView.topAnchor).isActive = true
        stack.bottomAnchor.constraint(equalTo: scroll.contentView.bottomAnchor).isActive = true
        stack.widthAnchor.constraint(equalTo: scroll.contentView.widthAnchor).isActive = true

        func sectionTitle(_ t: String) {
            let l = makeLabel(t, size: 15, bold: true)
            l.translatesAutoresizingMaskIntoConstraints = false
            stack.addArrangedSubview(l)
            stack.setCustomSpacing(4, after: l)
        }
        @discardableResult
        func row(_ views: [NSView], spacing: CGFloat = 8) -> NSStackView {
            let r = NSStackView()
            r.orientation = .horizontal
            r.alignment = .centerY
            r.spacing = spacing
            for v in views { r.addArrangedSubview(v) }
            stack.addArrangedSubview(r)
            return r
        }
        func button(_ t: String, _ a: Selector) -> NSButton {
            let b = NSButton(title: t, target: self, action: a)
            b.bezelStyle = .rounded
            return b
        }
        func checkbox(_ title: String, _ key: String) -> NSButton {
            let b = NSButton(checkboxWithTitle: title, target: self, action: #selector(settingChanged(_:)))
            b.state = UserDefaults.standard.bool(forKey: key) ? .on : .off
            b.identifier = NSUserInterfaceItemIdentifier(key)
            return b
        }

        // System status
        sectionTitle("This Mac")
        systemStatusLabel = makeLabel("", size: 12, color: .secondaryLabelColor)
        systemStatusLabel.translatesAutoresizingMaskIntoConstraints = false
        stack.addArrangedSubview(systemStatusLabel)

        // History
        sectionTitle("Update history & rollback")
        historyTable = makeTable(columns: [
            ("date", "Date", 150), ("app", "App", 190), ("change", "Change", 230),
            ("detail", "Detail", 280), ("action", "", 120)
        ])
        historyTable.dataSource = self
        historyTable.delegate = self
        historyTable.identifier = NSUserInterfaceItemIdentifier("history")
        let hsv = container(for: historyTable)
        hsv.translatesAutoresizingMaskIntoConstraints = false
        hsv.heightAnchor.constraint(equalToConstant: 220).isActive = true
        hsv.widthAnchor.constraint(greaterThanOrEqualToConstant: 970).isActive = true
        stack.addArrangedSubview(hsv)
        row([button("Refresh list", #selector(refreshHistory)),
             button("Export history as CSV…", #selector(exportHistoryCSVClicked)),
             button("Copy history", #selector(copyHistoryClicked)),
             button("Reveal rollback builds", #selector(revealRollbackBuilds)),
             button("Clear history", #selector(clearHistoryClicked))])

        // Storage
        sectionTitle("Storage")
        storageStack = NSStackView()
        storageStack.orientation = .vertical
        storageStack.alignment = .leading
        storageStack.spacing = 4
        storageStack.translatesAutoresizingMaskIntoConstraints = false
        stack.addArrangedSubview(storageStack)
        row([button("Open data folder", #selector(openDataFolder)),
             button("Recalculate sizes", #selector(refreshStorage)),
             button("Clear all caches", #selector(clearAllCachesClicked))])

        // Reports
        sectionTitle("Reports")
        row([button("CSV…", #selector(exportCSVClicked)),
             button("JSON…", #selector(exportJSONClicked)),
             button("HTML…", #selector(exportHTMLClicked)),
             button("Markdown…", #selector(exportMarkdownClicked)),
             button("PDF…", #selector(exportPDFClicked)),
             button("Copy report", #selector(copyReportClicked)),
             button("Export diagnostics…", #selector(exportDiagnosticsClicked))])

        // Maintenance
        sectionTitle("Maintenance")
        row([button("Run diagnostics", #selector(runDiagnosticsClicked)),
             button("Verify all signatures", #selector(verifyAllSignaturesClicked)),
             button("Force catalog refresh", #selector(forceCatalogRefreshClicked)),
             button("Rotate logs now", #selector(rotateLogsClicked)),
             button("Reveal log file", #selector(revealLogClicked)),
             button("Copy diagnostics", #selector(copyDiagnosticsClicked)),
             button("Install essentials bundle…", #selector(installEssentialsClicked))])

        // Preferences — appearance & behavior
        sectionTitle("Appearance & behavior")
        let appearance = NSPopUpButton(frame: .zero, pullsDown: false)
        appearance.addItems(withTitles: ["System appearance", "Light", "Dark"])
        let mode = UserDefaults.standard.string(forKey: Prefs.appearanceMode) ?? "system"
        appearance.selectItem(at: ["system", "light", "dark"].firstIndex(of: mode) ?? 0)
        appearance.target = self; appearance.action = #selector(appearanceChanged(_:))
        row([makeLabel("Appearance:", size: 13), appearance])
        row([checkbox("Show update count on the Dock icon", Prefs.showDockBadge),
             checkbox("Clicking the menu-bar icon opens the window", Prefs.statusItemClickOpens)])
        row([checkbox("Ask before uninstalling apps", Prefs.confirmUninstall),
             checkbox("Ask before trashing duplicate copies", Prefs.confirmDuplicateTrash)])
        row([checkbox("Automatically retry failed downloads", Prefs.autoRetryDownloads)])
        let attempts = NSPopUpButton(frame: .zero, pullsDown: false)
        attempts.addItems(withTitles: ["1", "2", "3", "4", "5"])
        let maxAtt = UserDefaults.standard.integer(forKey: Prefs.maxDownloadAttempts)
        attempts.selectItem(withTitle: "\(maxAtt == 0 ? 3 : maxAtt)")
        attempts.target = self; attempts.action = #selector(attemptsChanged(_:))
        row([makeLabel("Maximum download attempts:", size: 13), attempts])
        row([checkbox("Treat trailing build numbers as the same version", Prefs.buildEquivalence)])

        // Quiet hours
        let qs = NSPopUpButton(frame: .zero, pullsDown: false)
        let qe = NSPopUpButton(frame: .zero, pullsDown: false)
        let hourTitles = ["Off"] + (0...23).map { String(format: "%02d:00", $0) }
        qs.addItems(withTitles: hourTitles); qe.addItems(withTitles: hourTitles)
        let s = UserDefaults.standard.integer(forKey: Prefs.quietHoursStart)
        let e = UserDefaults.standard.integer(forKey: Prefs.quietHoursEnd)
        qs.selectItem(at: s < 0 ? 0 : s + 1)
        qe.selectItem(at: e < 0 ? 0 : e + 1)
        qs.target = self; qs.action = #selector(quietStartChanged(_:))
        qe.target = self; qe.action = #selector(quietEndChanged(_:))
        row([makeLabel("Quiet hours (no notifications):", size: 13), qs, makeLabel("to", size: 13), qe])

        // Downloads folder
        row([button("Choose downloads folder…", #selector(chooseDownloadsFolder)),
             button("Reset downloads folder", #selector(resetDownloadsFolder))])
        downloadsFolderLabel = makeLabel("", size: 12, color: .secondaryLabelColor)
        downloadsFolderLabel.translatesAutoresizingMaskIntoConstraints = false
        stack.addArrangedSubview(downloadsFolderLabel)

        // Retention
        let retention = NSPopUpButton(frame: .zero, pullsDown: false)
        retention.addItems(withTitles: ["Keep for 3 days", "Keep for 7 days", "Keep for 14 days",
                                        "Keep for 30 days", "Keep forever"])
        let days = UserDefaults.standard.integer(forKey: Prefs.rollbackRetentionDays)
        retention.selectItem(at: [3, 7, 14, 30, -1].firstIndex(of: days) ?? 1)
        retention.target = self; retention.action = #selector(retentionChanged(_:))
        row([makeLabel("Keep rollback builds:", size: 13), retention])

        // Skipped versions
        sectionTitle("Skipped versions")
        skippedStack = NSStackView()
        skippedStack.orientation = .vertical
        skippedStack.alignment = .leading
        skippedStack.spacing = 3
        skippedStack.translatesAutoresizingMaskIntoConstraints = false
        stack.addArrangedSubview(skippedStack)
        row([button("Remove all skipped versions", #selector(removeAllSkipped))])

        // Extra single apps
        sectionTitle("Extra apps to scan")
        extraAppsStack = NSStackView()
        extraAppsStack.orientation = .vertical
        extraAppsStack.alignment = .leading
        extraAppsStack.spacing = 3
        extraAppsStack.translatesAutoresizingMaskIntoConstraints = false
        stack.addArrangedSubview(extraAppsStack)
        row([button("Add an app…", #selector(addExtraAppClicked))])

        // Settings management
        sectionTitle("Settings")
        row([button("Export settings…", #selector(exportSettingsClicked)),
             button("Import settings…", #selector(importSettingsClicked)),
             button("Reset all settings…", #selector(resetSettingsClicked))])

        let about = makeLabel("MacRefresh \(MacRefreshVersion) — independent, free, open-source, no accounts. "
                              + "MacRefresh is an original community project.",
                              size: 11, color: .tertiaryLabelColor)
        about.translatesAutoresizingMaskIntoConstraints = false
        stack.addArrangedSubview(about)

        NSLayoutConstraint.activate([
            head.topAnchor.constraint(equalTo: outer.topAnchor),
            head.leadingAnchor.constraint(equalTo: outer.leadingAnchor),
            head.trailingAnchor.constraint(equalTo: outer.trailingAnchor),
            scroll.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 4),
            scroll.leadingAnchor.constraint(equalTo: outer.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: outer.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: outer.bottomAnchor, constant: -12)
        ])

        refreshHistory()
        refreshStorage()
        refreshSkippedUI()
        refreshExtraAppsUI()
        refreshDownloadsFolderLabel()
        refreshSystemStatus()
        DispatchQueue.main.async {
            scroll.contentView.scroll(to: .zero)
            scroll.reflectScrolledClipView(scroll.contentView)
        }
        return outer
    }

    // MARK: Tools refresh

    @objc func refreshHistory() {
        historyTable?.reloadData()
    }

    @objc func refreshStorage() {
        guard let storageStack = storageStack else { return }
        storageRefreshGen += 1
        let gen = storageRefreshGen
        storageStack.subviews.forEach { $0.removeFromSuperview() }
        let items = Maintenance.storageBreakdown()
        DispatchQueue.global(qos: .utility).async { [weak self] in
            var sized: [(String, Int64, URL)] = []
            for item in items {
                let size = FileManager.default.fileExists(atPath: item.url.path)
                    ? directorySize(item.url) : 0
                sized.append((item.name, size, item.url))
            }
            DispatchQueue.main.async {
                guard let self = self, gen == self.storageRefreshGen else { return }
                // Clear again on the main thread so a fast double-refresh can't
                // leave two overlapping sets of rows appended.
                storageStack.subviews.forEach { $0.removeFromSuperview() }
                for (name, size, url) in sized {
                    let r = NSStackView()
                    r.orientation = .horizontal
                    r.alignment = .centerY
                    r.spacing = 10
                    let label = makeLabel("\(name): \(self.humanSize(size))", size: 12)
                    let clear = PayloadButton(title: "Clear", target: self,
                                         action: #selector(self.clearStorageItem(_:)))
                    clear.bezelStyle = .rounded
                    clear.toolTip = url.path
                    clear.payload = url
                    let reveal = PayloadButton(title: "Reveal", target: self,
                                          action: #selector(self.revealStorageItem(_:)))
                    reveal.bezelStyle = .rounded
                    reveal.payload = url
                    reveal.toolTip = url.path
                    r.addArrangedSubview(label); r.addArrangedSubview(clear); r.addArrangedSubview(reveal)
                    storageStack.addArrangedSubview(r)
                }
            }
        }
    }

    func refreshSystemStatus() {
        let osv = ProcessInfo.processInfo.operatingSystemVersion
        let mac = "macOS \(osv.majorVersion).\(osv.minorVersion).\(osv.patchVersion)"
        let net = NetworkMonitor.shared.online ? "Network: online" : "Network: offline"
        let free = diskFreeBytes().map { " · Free disk: \(humanSize($0))" } ?? ""
        systemStatusLabel?.stringValue = "\(mac) · \(net)\(free) · \(rows.count) apps found"
    }

    @objc func clearStorageItem(_ sender: NSButton) {
        guard let url = (sender as? PayloadButton)?.url else { return }
        switch url.lastPathComponent {
        case "cask.json": Maintenance.clearCatalog()
        case "appstore.json": Maintenance.clearAppStoreCache()
        case "Icons": Maintenance.clearIcons()
        case "Logs": Maintenance.clearLogs()
        case "Downloads": Maintenance.clearDownloads()
        case "Parked": Maintenance.clearRollbacks()
        default: try? FileManager.default.removeItem(at: url)
        }
        refreshStorage()
        updateDiskUsage()
    }

    @objc func revealStorageItem(_ sender: NSButton) {
        guard let url = (sender as? PayloadButton)?.url else { return }
        if FileManager.default.fileExists(atPath: url.path) {
            NSWorkspace.shared.activateFileViewerSelecting([url])
        } else {
            NSWorkspace.shared.activateFileViewerSelecting([supportDirectory()])
        }
    }

    @objc func clearAllCachesClicked() {
        Maintenance.clearCatalog()
        Maintenance.clearAppStoreCache()
        Maintenance.clearIcons()
        Maintenance.clearLogs()
        let a = NSAlert()
        a.messageText = "Caches cleared"
        a.informativeText = "The catalog and icon caches will be rebuilt on the next check."
        a.addButton(withTitle: "OK"); a.runModal()
        refreshStorage(); updateDiskUsage(); rescan(initial: false)
    }

    @objc func revealRollbackBuilds() {
        let dir = supportDirectory().appendingPathComponent("Parked")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        NSWorkspace.shared.activateFileViewerSelecting([dir])
    }

    @objc func clearHistoryClicked() {
        let a = NSAlert()
        a.messageText = "Clear update history?"
        a.informativeText = "This removes the history list. Rollback builds on disk are not deleted."
        a.addButton(withTitle: "Clear")
        a.addButton(withTitle: "Cancel")
        a.alertStyle = .warning
        guard a.runModal() == .alertFirstButtonReturn else { return }
        HistoryStore.shared.clear()
        refreshHistory()
    }

    /// Format history events as CSV rows.
    func historyCSV() -> String {
        let df = ISO8601DateFormatter()
        var out = ["Date,Kind,App,Bundle ID,From,To,Detail"]
        func esc(_ s: String) -> String {
            s.contains(",") || s.contains("\"") || s.contains("\n")
                ? "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\"" : s
        }
        for e in HistoryStore.shared.displayed {
            out.append([df.string(from: e.date), e.kind.text, e.appName, e.bundleID,
                        e.fromVersion, e.toVersion, e.detail].map { esc($0) }.joined(separator: ","))
        }
        return out.joined(separator: "\n")
    }

    @objc func exportHistoryCSVClicked() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "MacRefresh-history.csv"
        panel.beginSheetModal(for: window) { response in
            guard response == .OK, let url = panel.url else { return }
            try? self.historyCSV().data(using: .utf8)?.write(to: url)
        }
    }

    @objc func copyHistoryClicked() {
        let f = DateFormatter(); f.dateStyle = .medium; f.timeStyle = .short
        let text = HistoryStore.shared.displayed.map { e in
            "\(f.string(from: e.date))\t\(e.kind.text)\t\(e.appName)\t\(e.fromVersion) → \(e.toVersion)\t\(e.detail)"
        }.joined(separator: "\n")
        if text.isEmpty {
            let a = NSAlert(); a.messageText = "History is empty"; a.addButton(withTitle: "OK"); a.runModal()
            return
        }
        copyText(text)
        let a = NSAlert()
        a.messageText = "History copied"
        a.informativeText = "\(HistoryStore.shared.displayed.count) events are on the clipboard."
        a.addButton(withTitle: "OK"); a.runModal()
    }

    @objc func revealLogClicked() {
        let log = logsDirectory().appendingPathComponent("app.log")
        if FileManager.default.fileExists(atPath: log.path) {
            NSWorkspace.shared.activateFileViewerSelecting([log])
        } else {
            NSWorkspace.shared.activateFileViewerSelecting([logsDirectory()])
        }
    }

    @objc func copyDiagnosticsClicked() {
        copyText(diagnosticsText())
        let a = NSAlert()
        a.messageText = "Diagnostics copied"
        a.informativeText = "System and app diagnostics are on the clipboard, ready to paste into a bug report."
        a.addButton(withTitle: "OK"); a.runModal()
    }

    // MARK: Reports

    @objc func exportMarkdownClicked() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "MacRefresh-report.md"
        panel.beginSheetModal(for: window) { [weak self] response in
            guard response == .OK, let url = panel.url, let self = self else { return }
            try? markdownReport(rows: self.rows).data(using: .utf8)?.write(to: url)
        }
    }

    @objc func exportPDFClicked() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "MacRefresh-report.pdf"
        panel.beginSheetModal(for: window) { [weak self] response in
            guard response == .OK, let url = panel.url, let self = self else { return }
            writePDFReport(rows: self.rows, to: url)
        }
    }

    @objc func copyReportClicked() {
        copyText(plainTextReport(rows: rows))
        let a = NSAlert()
        a.messageText = "Report copied"
        a.informativeText = "A tab-separated report for \(rows.count) apps is on the clipboard."
        a.addButton(withTitle: "OK"); a.runModal()
    }

    @objc func exportDiagnosticsClicked() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "MacRefresh-diagnostics.txt"
        panel.beginSheetModal(for: window) { response in
            guard response == .OK, let url = panel.url else { return }
            try? diagnosticsText().data(using: .utf8)?.write(to: url)
        }
    }

    // MARK: Maintenance actions

    @objc func verifyAllSignaturesClicked() {
        let targets = rows
        let alert = NSAlert()
        alert.messageText = "Verifying \(targets.count) signatures…"
        alert.informativeText = "This runs codesign on every app and can take a minute."
        alert.addButton(withTitle: "Start")
        alert.addButton(withTitle: "Cancel")
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            var problems: [String] = []
            for row in targets {
                if let problem = Installer.verifySignature(at: URL(fileURLWithPath: row.path)) {
                    problems.append("\(row.name): \(problem)")
                }
            }
            DispatchQueue.main.async {
                let a = NSAlert()
                if problems.isEmpty {
                    a.messageText = "All \(targets.count) apps passed signature verification"
                } else {
                    a.messageText = "\(problems.count) of \(targets.count) apps have signature problems"
                    let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 540, height: 300))
                    scroll.hasVerticalScroller = true
                    scroll.borderType = .bezelBorder
                    let tv = NSTextView()
                    tv.isEditable = false; tv.isRichText = false; tv.drawsBackground = false
                    tv.font = NSFont(name: "Menlo", size: 11)
                    tv.string = problems.joined(separator: "\n")
                    scroll.documentView = tv
                    alert.accessoryView = scroll
                }
                a.addButton(withTitle: "OK"); a.runModal()
                self?.installedTable?.reloadData()
            }
        }
    }

    @objc func forceCatalogRefreshClicked() {
        checkSpinner?.startAnimation(nil)
        loadCaskIndex(forceRefresh: true) { [weak self] map, list in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.checkSpinner?.stopAnimation(nil)
                self.ingestCasks(map: map, list: list)
                self.rebuildShop()
                self.refreshCatalogDate()
            }
        }
    }

    @objc func rotateLogsClicked() {
        Installer.rotateLogsIfNeeded()
        let a = NSAlert(); a.messageText = "Logs rotated"
        a.addButton(withTitle: "OK"); a.runModal()
        refreshStorage()
    }

    @objc func installEssentialsClicked() {
        let tokens = ["the-unarchiver", "itsycal", "maccy", "rectangle", "stats",
                      "appcleaner", "monitorcontrol", "keepingyouawake"]
        let a = NSAlert()
        a.messageText = "Install the essentials bundle?"
        a.informativeText = "These free apps will be installed from their official sources: "
            + tokens.joined(separator: ", ")
        a.addButton(withTitle: "Install all")
        a.addButton(withTitle: "Cancel")
        guard a.runModal() == .alertFirstButtonReturn else { return }
        var started = 0
        for token in tokens {
            guard let cask = caskByToken[token] else { continue }
            let installed = cask.appTargets.first { FileManager.default.fileExists(atPath: $0) }
            let item = ShopItem(cask: cask, category: "Essentials", installedPath: installed)
            if installed == nil { startShopInstall(item); started += 1 }
        }
        if started > 0 { switchTo(.downloads) }
    }

    // MARK: Appearance / behavior handlers

    @objc func appearanceChanged(_ sender: NSPopUpButton) {
        let modes = ["system", "light", "dark"]
        let m = sender.indexOfSelectedItem < modes.count ? modes[sender.indexOfSelectedItem] : "system"
        UserDefaults.standard.set(m, forKey: Prefs.appearanceMode)
        applyAppearance()
    }

    @objc func attemptsChanged(_ sender: NSPopUpButton) {
        let n = Int(sender.titleOfSelectedItem ?? "3") ?? 3
        UserDefaults.standard.set(n, forKey: Prefs.maxDownloadAttempts)
    }

    @objc func quietStartChanged(_ sender: NSPopUpButton) {
        UserDefaults.standard.set(sender.indexOfSelectedItem == 0 ? -1 : sender.indexOfSelectedItem - 1,
                                  forKey: Prefs.quietHoursStart)
    }

    @objc func quietEndChanged(_ sender: NSPopUpButton) {
        UserDefaults.standard.set(sender.indexOfSelectedItem == 0 ? -1 : sender.indexOfSelectedItem - 1,
                                  forKey: Prefs.quietHoursEnd)
    }

    @objc func retentionChanged(_ sender: NSPopUpButton) {
        let values = [3, 7, 14, 30, -1]
        let days = sender.indexOfSelectedItem < values.count ? values[sender.indexOfSelectedItem] : 7
        UserDefaults.standard.set(days, forKey: Prefs.rollbackRetentionDays)
        Installer.pruneRollbackBuilds()
    }

    @objc func chooseDownloadsFolder() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.message = "Choose where downloaded installers are stored"
        panel.beginSheetModal(for: window) { [weak self] response in
            guard response == .OK, let url = panel.url else { return }
            UserDefaults.standard.set(url.path, forKey: Prefs.customDownloadsFolder)
            try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
            self?.refreshDownloadsFolderLabel()
        }
    }

    @objc func resetDownloadsFolder() {
        UserDefaults.standard.set("", forKey: Prefs.customDownloadsFolder)
        refreshDownloadsFolderLabel()
    }

    func refreshDownloadsFolderLabel() {
        let custom = (UserDefaults.standard.string(forKey: Prefs.customDownloadsFolder) ?? "")
            .trimmingCharacters(in: .whitespaces)
        downloadsFolderLabel?.stringValue = custom.isEmpty
            ? "Downloads are stored in MacRefresh's data folder."
            : "Downloads go to: \(custom)"
    }

    // MARK: Skipped versions

    func refreshSkippedUI() {
        guard let skippedStack = skippedStack else { return }
        skippedStack.subviews.forEach { $0.removeFromSuperview() }
        let skipped = Prefs.skippedVersions
        if skipped.isEmpty {
            skippedStack.addArrangedSubview(makeLabel("No versions are skipped.", size: 12,
                                                       color: .secondaryLabelColor))
            return
        }
        for (bid, version) in skipped.sorted(by: { $0.key < $1.key }) {
            let r = NSStackView()
            r.orientation = .horizontal; r.alignment = .centerY; r.spacing = 8
            let name = rows.first { $0.bundleID == bid }?.name ?? bid
            r.addArrangedSubview(makeLabel("\(name) — \(version)", size: 12))
            let b = PayloadButton(title: "Remove", target: self, action: #selector(removeSkipped(_:)))
            b.bezelStyle = .rounded; b.payload = bid
            r.addArrangedSubview(b)
            skippedStack.addArrangedSubview(r)
        }
    }

    @objc func removeSkipped(_ sender: NSButton) {
        guard let bid = (sender as? PayloadButton)?.payload as? String else { return }
        var skipped = Prefs.skippedVersions
        skipped.removeValue(forKey: bid)
        Prefs.skippedVersions = skipped
        refreshSkippedUI()
        rescan(initial: false)
    }

    @objc func removeAllSkipped() {
        Prefs.skippedVersions = [:]
        refreshSkippedUI()
        rescan(initial: false)
    }

    @objc func skipThisVersion(_ sender: NSMenuItem) {
        let rows = pickedRows(sender)
        guard let row = rows.first, let latest = row.latest else { return }
        var skipped = Prefs.skippedVersions
        skipped[row.bundleID] = latest
        Prefs.skippedVersions = skipped
        refreshSkippedUI()
        rescan(initial: false)
    }

    // MARK: Extra single apps

    @objc func addExtraAppClicked() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowedContentTypes = [.application]
        panel.allowsMultipleSelection = true
        panel.message = "Choose app bundles MacRefresh should scan even outside its usual folders"
        panel.beginSheetModal(for: window) { [weak self] response in
            guard response == .OK else { return }
            var apps = Prefs.extraScanApps
            for url in panel.urls where !apps.contains(url.path) { apps.append(url.path) }
            Prefs.extraScanApps = apps
            self?.refreshExtraAppsUI()
            self?.rescan(initial: false)
        }
    }

    func refreshExtraAppsUI() {
        guard let extraAppsStack = extraAppsStack else { return }
        extraAppsStack.subviews.forEach { $0.removeFromSuperview() }
        let apps = Prefs.extraScanApps
        if apps.isEmpty {
            extraAppsStack.addArrangedSubview(makeLabel("No extra apps added.", size: 12,
                                                         color: .secondaryLabelColor))
            return
        }
        for path in apps {
            let r = NSStackView()
            r.orientation = .horizontal; r.alignment = .centerY; r.spacing = 8
            r.addArrangedSubview(makeLabel((path as NSString).lastPathComponent, size: 12))
            let b = PayloadButton(title: "Remove", target: self, action: #selector(removeExtraApp(_:)))
            b.bezelStyle = .rounded; b.payload = path
            r.addArrangedSubview(b)
            extraAppsStack.addArrangedSubview(r)
        }
    }

    @objc func removeExtraApp(_ sender: NSButton) {
        guard let path = (sender as? PayloadButton)?.payload as? String else { return }
        Prefs.extraScanApps = Prefs.extraScanApps.filter { $0 != path }
        refreshExtraAppsUI()
        rescan(initial: false)
    }

    // MARK: Settings import/export/reset

    @objc func exportSettingsClicked() {
        guard let bid = Bundle.main.bundleIdentifier,
              let domain = UserDefaults.standard.persistentDomain(forName: bid) else { return }
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "MacRefresh-settings.plist"
        panel.beginSheetModal(for: window) { response in
            guard response == .OK, let url = panel.url else { return }
            let data = try? PropertyListSerialization.data(fromPropertyList: domain, format: .xml, options: 0)
            try? data?.write(to: url)
        }
    }

    @objc func importSettingsClicked() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true; panel.canChooseDirectories = false
        if let plistType = UTType(filenameExtension: "plist") {
            panel.allowedContentTypes = [plistType]
        }
        panel.beginSheetModal(for: window) { response in
            guard response == .OK, let url = panel.url,
                  let data = try? Data(contentsOf: url),
                  let plist = try? PropertyListSerialization.propertyList(from: data, format: nil)
                    as? [String: Any],
                  let bid = Bundle.main.bundleIdentifier else { return }
            UserDefaults.standard.setPersistentDomain(plist, forName: bid)
            let a = NSAlert()
            a.messageText = "Settings imported"
            a.informativeText = "MacRefresh needs to restart to apply the imported settings."
            a.addButton(withTitle: "Restart now")
            a.addButton(withTitle: "Later")
            if a.runModal() == .alertFirstButtonReturn { NSApp.relaunch() }
        }
    }

    @objc func resetSettingsClicked() {
        let a = NSAlert()
        a.messageText = "Reset all MacRefresh settings?"
        a.informativeText = "Ignored apps, custom sources and preferences return to defaults. Downloaded files and the app catalog are kept."
        a.addButton(withTitle: "Reset")
        a.addButton(withTitle: "Cancel")
        a.alertStyle = .warning
        guard a.runModal() == .alertFirstButtonReturn, let bid = Bundle.main.bundleIdentifier else { return }
        UserDefaults.standard.removePersistentDomain(forName: bid)
        NSApp.relaunch()
    }

    // MARK: Rollback

    @objc func historyAction(_ sender: NSButton) {
        let list = HistoryStore.shared.displayed
        guard sender.tag < list.count else { return }
        let event = list[sender.tag]
        guard let rb = event.rollbackPath,
              FileManager.default.fileExists(atPath: rb) else {
            let a = NSAlert(); a.messageText = "Rollback build no longer available"
            a.informativeText = "The retained previous build was removed (retention expired)."
            a.addButton(withTitle: "OK"); a.runModal()
            refreshHistory()
            return
        }
        let a = NSAlert()
        a.messageText = "Roll back \(event.appName) to \(event.fromVersion)?"
        a.informativeText = "The currently installed build will be replaced with the retained version."
        a.addButton(withTitle: "Roll back")
        a.addButton(withTitle: "Cancel")
        a.alertStyle = .warning
        guard a.runModal() == .alertFirstButtonReturn else { return }

        DispatchQueue.global(qos: .userInitiated).async {
            let fm = FileManager.default
            let dest = event.detail
            Installer.quitAppTree(destPath: dest,
                                  bundleIDs: event.bundleID.isEmpty ? [] : [event.bundleID])
            if fm.fileExists(atPath: dest) {
                if !Installer.recycleSync(URL(fileURLWithPath: dest)) {
                    _ = Installer.trash(URL(fileURLWithPath: dest))
                }
            }
            let ditto = Installer.runProc("/usr/bin/ditto", [rb, dest], timeout: 300)
            DispatchQueue.main.async { [weak self] in
                let ok = ditto.code == 0
                    && fm.fileExists(atPath: dest + "/Contents/Info.plist")
                let result = NSAlert()
                result.messageText = ok ? "\(event.appName) rolled back to \(event.fromVersion)"
                                        : "Rollback failed"
                result.informativeText = ok ? "" : ditto.output
                result.addButton(withTitle: "OK"); result.runModal()
                if ok {
                    HistoryStore.shared.record(HistoryEvent(
                        kind: .rolledBack, appName: event.appName, bundleID: event.bundleID,
                        fromVersion: event.toVersion, toVersion: event.fromVersion,
                        detail: dest, rollbackPath: nil))
                    self?.refreshHistory()
                    self?.rescan(initial: false)
                }
            }
        }
    }
}

// MARK: - NSApplication relaunch

extension NSApplication {
    func relaunch() {
        let path = Bundle.main.bundlePath
        let escaped = path.replacingOccurrences(of: "\"", with: "\\\"")
        // Launch from a detached, orphaned shell that waits for THIS process to
        // finish exiting before reopening the app. If we opened a new instance
        // immediately, the new process's single-instance guard would see the
        // still-dying process, activate it and exit itself — leaving the app
        // fully closed ("it just quits by itself").
        let inner = "sleep 1; /usr/bin/open -n \"\(escaped)\""
        let cmd = "nohup /bin/sh -c '\(inner)' >/dev/null 2>&1 &"
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/bin/sh")
        p.arguments = ["-c", cmd]
        try? p.run()
        terminate(nil)
    }
}
