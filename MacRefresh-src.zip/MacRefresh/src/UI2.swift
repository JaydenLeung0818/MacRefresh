// UI2.swift — continuation of AppDelegate: pane builders, features and actions
import Cocoa
import WebKit
import UserNotifications
import ServiceManagement
import UniformTypeIdentifiers

extension AppDelegate {

    // MARK: Downloads pane

    func buildDownloads() -> NSView {
        let v = NSView()
        let head = header(title: "Downloads", subtitle: "Downloads, extraction and installation happen here")
        v.addSubview(head)

        downloadsAggregateLabel = makeLabel("", size: 12, color: .secondaryLabelColor)
        downloadsAggregateLabel.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(downloadsAggregateLabel)

        downloadsTable = makeTable(columns: [
            ("app", "App", 240), ("kind", "Type", 90), ("state", "State", 120),
            ("progress", "Progress", 240), ("message", "Details", 220), ("action", "", 110)
        ])
        downloadsTable.dataSource = self
        downloadsTable.delegate = self
        downloadsTable.target = self
        downloadsTable.doubleAction = #selector(downloadsDoubleClick)
        downloadsTable.identifier = NSUserInterfaceItemIdentifier("downloads")
        let sv = container(for: downloadsTable)
        v.addSubview(sv)

        downloadsEmptyLabel = makeLabel("No downloads yet. Updates you install and free apps you get from the Shop will appear here.",
                                        size: 13, color: .secondaryLabelColor)
        downloadsEmptyLabel.alignment = .center
        downloadsEmptyLabel.translatesAutoresizingMaskIntoConstraints = false
        downloadsEmptyLabel.isHidden = true
        sv.addSubview(downloadsEmptyLabel)

        let actions = NSStackView()
        actions.orientation = .horizontal
        actions.spacing = 10
        actions.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(actions)
        let pauseAll = NSButton(title: "Pause all", target: self, action: #selector(pauseAllDownloads))
        let resumeAll = NSButton(title: "Resume all", target: self, action: #selector(resumeAllDownloads))
        let cancelAll = NSButton(title: "Cancel all", target: self, action: #selector(cancelAllDownloads))
        let retryAll = NSButton(title: "Retry all failed", target: self, action: #selector(retryAllDownloads))
        let clear = NSButton(title: "Clear finished", target: self, action: #selector(clearDownloads))
        for b in [pauseAll, resumeAll, cancelAll, retryAll, clear] {
            b.bezelStyle = .rounded; actions.addArrangedSubview(b)
        }

        NSLayoutConstraint.activate([
            head.topAnchor.constraint(equalTo: v.topAnchor),
            head.leadingAnchor.constraint(equalTo: v.leadingAnchor),
            head.trailingAnchor.constraint(equalTo: v.trailingAnchor),
            downloadsAggregateLabel.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 2),
            downloadsAggregateLabel.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 22),
            sv.topAnchor.constraint(equalTo: downloadsAggregateLabel.bottomAnchor, constant: 6),
            sv.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            sv.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            actions.topAnchor.constraint(equalTo: sv.bottomAnchor, constant: 10),
            actions.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            actions.bottomAnchor.constraint(equalTo: v.bottomAnchor, constant: -14),
            downloadsEmptyLabel.centerXAnchor.constraint(equalTo: sv.centerXAnchor),
            downloadsEmptyLabel.centerYAnchor.constraint(equalTo: sv.centerYAnchor),
            downloadsEmptyLabel.leadingAnchor.constraint(greaterThanOrEqualTo: sv.leadingAnchor, constant: 40),
            downloadsEmptyLabel.trailingAnchor.constraint(lessThanOrEqualTo: sv.trailingAnchor, constant: -40)
        ])
        updateDownloadsAggregate()
        return v
    }

    /// Double-click: open the installed app when done, otherwise reveal the
    /// downloaded installer file in Finder.
    @objc func downloadsDoubleClick() {
        let r = downloadsTable.clickedRow
        let jobs = DownloadManager.shared.jobs
        guard r >= 0, r < jobs.count else { return }
        let job = jobs[r]
        if let app = job.installedURL {
            NSWorkspace.shared.openApplication(at: app, configuration: .init())
        } else if let file = job.localURL, FileManager.default.fileExists(atPath: file.path) {
            NSWorkspace.shared.activateFileViewerSelecting([file])
        }
    }

    func updateDownloadsAggregate() {
        let dm = DownloadManager.shared
        let active = dm.jobs.filter { [.queued, .downloading, .extracting, .installing].contains($0.state) }
        downloadsEmptyLabel?.isHidden = !dm.jobs.isEmpty
        if active.isEmpty {
            let done = dm.jobs.filter { $0.state == .done }.count
            downloadsAggregateLabel?.stringValue = done > 0 ? "\(done) finished" : ""
        } else {
            let speed = humanSize(Int64(dm.aggregateSpeed))
            downloadsAggregateLabel?.stringValue =
                "\(active.count) active · \(speed)/s aggregate"
        }
    }

    @objc func clearDownloads() { DownloadManager.shared.clearFinished() }

    @objc func pauseAllDownloads() { DownloadManager.shared.pauseAll() }
    @objc func resumeAllDownloads() { DownloadManager.shared.resumeAll() }
    @objc func cancelAllDownloads() { DownloadManager.shared.cancelAll() }

    @objc func retryAllDownloads() {
        for job in DownloadManager.shared.jobs where job.state == .failed {
            DownloadManager.shared.retry(job)
        }
    }

    // MARK: Settings pane

    func buildSettings() -> NSView {
        let outer = NSView()
        let head = header(title: "Settings", subtitle: "Behavior, appearance, sources and data")
        head.translatesAutoresizingMaskIntoConstraints = false
        outer.addSubview(head)

        let scroll = NSScrollView()
        scroll.hasVerticalScroller = true
        scroll.borderType = .noBorder
        scroll.autohidesScrollers = true
        scroll.translatesAutoresizingMaskIntoConstraints = false
        outer.addSubview(scroll)
        let v = NSView()
        v.translatesAutoresizingMaskIntoConstraints = false
        scroll.documentView = v
        v.leadingAnchor.constraint(equalTo: scroll.contentView.leadingAnchor).isActive = true
        v.trailingAnchor.constraint(equalTo: scroll.contentView.trailingAnchor).isActive = true
        v.topAnchor.constraint(equalTo: scroll.contentView.topAnchor).isActive = true
        v.bottomAnchor.constraint(equalTo: scroll.contentView.bottomAnchor).isActive = true

        func checkbox(_ title: String, _ key: String) -> NSButton {
            let b = NSButton(checkboxWithTitle: title, target: self, action: #selector(settingChanged(_:)))
            b.state = UserDefaults.standard.bool(forKey: key) ? .on : .off
            b.identifier = NSUserInterfaceItemIdentifier(key)
            return b
        }
        func titleLabel(_ t: String) -> NSTextField {
            let l = makeLabel(t, size: 15, bold: true)
            l.translatesAutoresizingMaskIntoConstraints = false
            v.addSubview(l)
            return l
        }
        func roundedButton(_ t: String, _ a: Selector) -> NSButton {
            let b = NSButton(title: t, target: self, action: a)
            b.bezelStyle = .rounded
            b.translatesAutoresizingMaskIntoConstraints = false
            v.addSubview(b)
            return b
        }

        // Left column — behavior + catalog
        let behaviorTitle = titleLabel("Behavior")
        let auto = checkbox("Check for updates automatically on launch", Prefs.autoCheck)
        let launchLogin = checkbox("Launch MacRefresh when I log in", Prefs.launchAtLogin)
        let relaunch = checkbox("Relaunch apps after updating them", Prefs.relaunchAfterUpdate)
        let home = checkbox("Also scan ~/Applications", Prefs.scanHome)
        let desktop = checkbox("Also scan the Desktop folder", Prefs.scanDesktop)
        let downloads = checkbox("Also scan the Downloads folder", Prefs.scanDownloads)
        let keep = checkbox("Keep downloaded installers after installing", Prefs.keepInstallers)
        let showIgnored = checkbox("Show ignored apps in lists", Prefs.showIgnored)
        let statusBar = checkbox("Show MacRefresh in the menu bar (top-right)", Prefs.showStatusItem)
        let dockIcon = checkbox("Show MacRefresh in the Dock", Prefs.showDockIcon)
        let notify = checkbox("Notify me when downloads finish or fail", Prefs.notifications)
        let silentPkg = checkbox("Install .pkg updates in-app (administrator password prompt)", Prefs.silentPKG)
        let verify = checkbox("Verify app signatures after installing", Prefs.verifySignatures)
        let rememberSection = checkbox("Remember the last section I opened", Prefs.rememberSection)
        let rememberSize = checkbox("Remember the window size", Prefs.rememberWindowSize)
        let leftBoxes = [auto, launchLogin, relaunch, home, desktop, downloads, keep, showIgnored,
                         statusBar, dockIcon, notify, silentPkg, verify, rememberSection, rememberSize]
        for b in leftBoxes { b.translatesAutoresizingMaskIntoConstraints = false; v.addSubview(b) }

        let catalogTitle = titleLabel("App catalog")
        catalogDateLabel = makeLabel("Not loaded yet", size: 12, color: .secondaryLabelColor)
        catalogDateLabel.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(catalogDateLabel)
        let refreshCatalog = roundedButton("Refresh catalog now", #selector(refreshCatalogClicked))
        let openData = roundedButton("Open data folder", #selector(openDataFolder))

        // Right column — schedule, speed, storage, export, ignores
        let scheduleTitle = titleLabel("Scheduled checks")
        let schedule = NSPopUpButton(frame: .zero, pullsDown: false)
        schedule.addItems(withTitles: ["Manual only", "Every 6 hours", "Every 12 hours", "Every day", "Every week"])
        let iv = UserDefaults.standard.integer(forKey: Prefs.checkInterval)
        let scheduleTitles = [0, 6, 12, 24, 168]
        schedule.selectItem(at: scheduleTitles.firstIndex(of: iv) ?? 3)
        schedule.target = self; schedule.action = #selector(scheduleChanged(_:))
        schedule.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(schedule)

        let speedTitle = titleLabel("Speed")
        let speedLabel = makeLabel("Parallel downloads:", size: 13)
        speedLabel.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(speedLabel)
        let concurrency = NSPopUpButton(frame: .zero, pullsDown: false)
        concurrency.addItems(withTitles: ["1", "2", "3", "4", "6"])
        let cc = UserDefaults.standard.integer(forKey: Prefs.maxConcurrent)
        concurrency.selectItem(withTitle: "\(cc == 0 ? 3 : cc)")
        concurrency.target = self
        concurrency.action = #selector(concurrencyChanged(_:))
        concurrency.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(concurrency)

        let storageTitle = titleLabel("Storage")
        diskUsageLabel = makeLabel("Calculating…", size: 12, color: .secondaryLabelColor)
        diskUsageLabel.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(diskUsageLabel)
        let clearCaches = roundedButton("Clear caches and reset icon storage", #selector(clearCachesClicked))
        let diagnostics = roundedButton("Run diagnostics", #selector(runDiagnosticsClicked))
        let viewLogs = roundedButton("View log file", #selector(viewLogsClicked))
        let revealLogs = roundedButton("Reveal logs in Finder", #selector(revealLogsClicked))

        let dataTitle = titleLabel("Export")
        let exportCSV = roundedButton("Export app list as CSV…", #selector(exportCSVClicked))
        let exportJSON = roundedButton("Export app list as JSON…", #selector(exportJSONClicked))
        let exportHTML = roundedButton("Export app list as HTML…", #selector(exportHTMLClicked))

        let ignoredTitle = titleLabel("Ignored apps")
        let ignoreRow = NSStackView()
        ignoreRow.orientation = .horizontal
        ignoreRow.spacing = 8
        ignoreRow.alignment = .centerY
        ignoreRow.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(ignoreRow)
        ignoreAppPopup = NSPopUpButton(frame: .zero, pullsDown: false)
        ignoreAppPopup.translatesAutoresizingMaskIntoConstraints = false
        let addIgnore = NSButton(title: "Ignore selected app", target: self,
                                 action: #selector(addIgnoreClicked))
        addIgnore.bezelStyle = .rounded
        let browseIgnore = NSButton(title: "Browse to ignore…", target: self,
                                    action: #selector(browseIgnoreClicked))
        browseIgnore.bezelStyle = .rounded
        ignoreRow.addArrangedSubview(ignoreAppPopup)
        ignoreRow.addArrangedSubview(addIgnore)
        ignoreRow.addArrangedSubview(browseIgnore)

        let ignoredScroll = NSScrollView()
        ignoredScroll.hasVerticalScroller = true
        ignoredScroll.borderType = .lineBorder
        ignoredScroll.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(ignoredScroll)
        ignoredStack.orientation = .vertical
        ignoredStack.alignment = .leading
        ignoredStack.spacing = 3
        ignoredStack.translatesAutoresizingMaskIntoConstraints = false
        ignoredScroll.documentView = ignoredStack

        let removeIgnore = roundedButton("Remove all ignores", #selector(removeAllIgnores))

        // Left column — custom per-app update sources
        let customTitle = titleLabel("Custom update sources")
        let customRow = NSStackView()
        customRow.orientation = .horizontal
        customRow.spacing = 8
        customRow.alignment = .centerY
        customRow.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(customRow)
        customAppPopup = NSPopUpButton(frame: .zero, pullsDown: false)
        customAppPopup.translatesAutoresizingMaskIntoConstraints = false
        let addCustom = NSButton(title: "Add / Edit URL…", target: self,
                                 action: #selector(addCustomClicked))
        addCustom.bezelStyle = .rounded
        let testCustom = NSButton(title: "Test URL…", target: self,
                                  action: #selector(testCustomClicked))
        testCustom.bezelStyle = .rounded
        customRow.addArrangedSubview(customAppPopup)
        customRow.addArrangedSubview(addCustom)
        customRow.addArrangedSubview(testCustom)

        let customScroll = NSScrollView()
        customScroll.hasVerticalScroller = true
        customScroll.borderType = .lineBorder
        customScroll.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(customScroll)
        customStack.orientation = .vertical
        customStack.alignment = .leading
        customStack.spacing = 3
        customStack.translatesAutoresizingMaskIntoConstraints = false
        customScroll.documentView = customStack

        let removeAllCustom = roundedButton("Remove all custom sources",
                                            #selector(removeAllCustomSources))

        // Left column — extra scan folders
        let extraTitle = titleLabel("Extra scan folders")
        let extraRow = NSStackView()
        extraRow.orientation = .horizontal
        extraRow.spacing = 8
        extraRow.alignment = .centerY
        extraRow.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(extraRow)
        let addFolder = NSButton(title: "Add folder…", target: self,
                                 action: #selector(addExtraFolderClicked))
        addFolder.bezelStyle = .rounded
        extraRow.addArrangedSubview(addFolder)

        let extraScroll = NSScrollView()
        extraScroll.hasVerticalScroller = true
        extraScroll.borderType = .lineBorder
        extraScroll.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(extraScroll)
        extraFoldersStack.orientation = .vertical
        extraFoldersStack.alignment = .leading
        extraFoldersStack.spacing = 3
        extraFoldersStack.translatesAutoresizingMaskIntoConstraints = false
        extraScroll.documentView = extraFoldersStack

        let about = makeLabel("MacRefresh 1.0 — an independent, open-source macOS app updater.\nSources: app Sparkle and Squirrel feeds, asar package.json repositories, the public Homebrew cask index, the App Store lookup API, GitHub releases and your own custom URLs. No tracking, no accounts.",
                              size: 11, color: .tertiaryLabelColor)
        about.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(about)

        let lead: CGFloat = 24
        NSLayoutConstraint.activate([
            head.topAnchor.constraint(equalTo: outer.topAnchor),
            head.leadingAnchor.constraint(equalTo: outer.leadingAnchor),
            head.trailingAnchor.constraint(equalTo: outer.trailingAnchor),
            scroll.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 4),
            scroll.leadingAnchor.constraint(equalTo: outer.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: outer.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: outer.bottomAnchor, constant: -12),

            behaviorTitle.topAnchor.constraint(equalTo: v.topAnchor, constant: 14),
            behaviorTitle.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: lead),
            auto.topAnchor.constraint(equalTo: behaviorTitle.bottomAnchor, constant: 10),
            auto.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: lead),
            launchLogin.topAnchor.constraint(equalTo: auto.bottomAnchor, constant: 9),
            launchLogin.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            relaunch.topAnchor.constraint(equalTo: launchLogin.bottomAnchor, constant: 9),
            relaunch.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            home.topAnchor.constraint(equalTo: relaunch.bottomAnchor, constant: 9),
            home.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            desktop.topAnchor.constraint(equalTo: home.bottomAnchor, constant: 9),
            desktop.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            downloads.topAnchor.constraint(equalTo: desktop.bottomAnchor, constant: 9),
            downloads.leadingAnchor.constraint(equalTo: desktop.leadingAnchor),
            keep.topAnchor.constraint(equalTo: downloads.bottomAnchor, constant: 9),
            keep.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            showIgnored.topAnchor.constraint(equalTo: keep.bottomAnchor, constant: 9),
            showIgnored.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            statusBar.topAnchor.constraint(equalTo: showIgnored.bottomAnchor, constant: 9),
            statusBar.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            dockIcon.topAnchor.constraint(equalTo: statusBar.bottomAnchor, constant: 9),
            dockIcon.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            notify.topAnchor.constraint(equalTo: dockIcon.bottomAnchor, constant: 9),
            notify.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            silentPkg.topAnchor.constraint(equalTo: notify.bottomAnchor, constant: 9),
            silentPkg.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            verify.topAnchor.constraint(equalTo: silentPkg.bottomAnchor, constant: 9),
            verify.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            rememberSection.topAnchor.constraint(equalTo: verify.bottomAnchor, constant: 9),
            rememberSection.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            rememberSize.topAnchor.constraint(equalTo: rememberSection.bottomAnchor, constant: 9),
            rememberSize.leadingAnchor.constraint(equalTo: auto.leadingAnchor),

            catalogTitle.topAnchor.constraint(equalTo: rememberSize.bottomAnchor, constant: 22),
            catalogTitle.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            catalogDateLabel.topAnchor.constraint(equalTo: catalogTitle.bottomAnchor, constant: 6),
            catalogDateLabel.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            refreshCatalog.topAnchor.constraint(equalTo: catalogDateLabel.bottomAnchor, constant: 8),
            refreshCatalog.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            openData.topAnchor.constraint(equalTo: refreshCatalog.bottomAnchor, constant: 8),
            openData.leadingAnchor.constraint(equalTo: auto.leadingAnchor),

            scheduleTitle.topAnchor.constraint(equalTo: v.topAnchor, constant: 14),
            scheduleTitle.leadingAnchor.constraint(equalTo: v.centerXAnchor, constant: lead),
            schedule.topAnchor.constraint(equalTo: scheduleTitle.bottomAnchor, constant: 10),
            schedule.leadingAnchor.constraint(equalTo: scheduleTitle.leadingAnchor),

            speedTitle.topAnchor.constraint(equalTo: schedule.bottomAnchor, constant: 22),
            speedTitle.leadingAnchor.constraint(equalTo: scheduleTitle.leadingAnchor),
            speedLabel.topAnchor.constraint(equalTo: speedTitle.bottomAnchor, constant: 12),
            speedLabel.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            concurrency.centerYAnchor.constraint(equalTo: speedLabel.centerYAnchor),
            concurrency.leadingAnchor.constraint(equalTo: speedLabel.trailingAnchor, constant: 10),
            concurrency.widthAnchor.constraint(equalToConstant: 70),

            storageTitle.topAnchor.constraint(equalTo: speedLabel.bottomAnchor, constant: 24),
            storageTitle.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            diskUsageLabel.topAnchor.constraint(equalTo: storageTitle.bottomAnchor, constant: 8),
            diskUsageLabel.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            diskUsageLabel.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            clearCaches.topAnchor.constraint(equalTo: diskUsageLabel.bottomAnchor, constant: 8),
            clearCaches.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            diagnostics.topAnchor.constraint(equalTo: clearCaches.bottomAnchor, constant: 8),
            diagnostics.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            viewLogs.topAnchor.constraint(equalTo: diagnostics.bottomAnchor, constant: 8),
            viewLogs.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            revealLogs.topAnchor.constraint(equalTo: viewLogs.bottomAnchor, constant: 8),
            revealLogs.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),

            dataTitle.topAnchor.constraint(equalTo: revealLogs.bottomAnchor, constant: 22),
            dataTitle.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            exportCSV.topAnchor.constraint(equalTo: dataTitle.bottomAnchor, constant: 8),
            exportCSV.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            exportJSON.topAnchor.constraint(equalTo: exportCSV.bottomAnchor, constant: 6),
            exportJSON.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            exportHTML.topAnchor.constraint(equalTo: exportJSON.bottomAnchor, constant: 6),
            exportHTML.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),

            ignoredTitle.topAnchor.constraint(equalTo: exportHTML.bottomAnchor, constant: 22),
            ignoredTitle.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            ignoreRow.topAnchor.constraint(equalTo: ignoredTitle.bottomAnchor, constant: 8),
            ignoreRow.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            ignoreRow.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            ignoredScroll.topAnchor.constraint(equalTo: ignoreRow.bottomAnchor, constant: 8),
            ignoredScroll.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),
            ignoredScroll.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            ignoredScroll.heightAnchor.constraint(equalToConstant: 104),
            removeIgnore.topAnchor.constraint(equalTo: ignoredScroll.bottomAnchor, constant: 8),
            removeIgnore.leadingAnchor.constraint(equalTo: speedTitle.leadingAnchor),

            customTitle.topAnchor.constraint(equalTo: openData.bottomAnchor, constant: 24),
            customTitle.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            customRow.topAnchor.constraint(equalTo: customTitle.bottomAnchor, constant: 8),
            customRow.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            customRow.trailingAnchor.constraint(equalTo: v.centerXAnchor, constant: -20),
            customScroll.topAnchor.constraint(equalTo: customRow.bottomAnchor, constant: 8),
            customScroll.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            customScroll.trailingAnchor.constraint(equalTo: v.centerXAnchor, constant: -20),
            customScroll.heightAnchor.constraint(equalToConstant: 104),
            removeAllCustom.topAnchor.constraint(equalTo: customScroll.bottomAnchor, constant: 8),
            removeAllCustom.leadingAnchor.constraint(equalTo: auto.leadingAnchor),

            extraTitle.topAnchor.constraint(equalTo: removeAllCustom.bottomAnchor, constant: 24),
            extraTitle.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            extraRow.topAnchor.constraint(equalTo: extraTitle.bottomAnchor, constant: 8),
            extraRow.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            extraScroll.topAnchor.constraint(equalTo: extraRow.bottomAnchor, constant: 8),
            extraScroll.leadingAnchor.constraint(equalTo: auto.leadingAnchor),
            extraScroll.trailingAnchor.constraint(equalTo: v.centerXAnchor, constant: -20),
            extraScroll.heightAnchor.constraint(equalToConstant: 96),

            about.topAnchor.constraint(greaterThanOrEqualTo: extraScroll.bottomAnchor, constant: 24),
            about.topAnchor.constraint(greaterThanOrEqualTo: removeIgnore.bottomAnchor, constant: 24),
            about.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: lead),
            about.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            about.bottomAnchor.constraint(equalTo: v.bottomAnchor, constant: -14)
        ])
        ignoreAppPopup.widthAnchor.constraint(equalToConstant: 250).isActive = true
        customAppPopup.widthAnchor.constraint(equalToConstant: 250).isActive = true
        refreshIgnoredUI()
        refreshCustomUI()
        refreshExtraFoldersUI()
        updateDiskUsage()
        // Always open Settings at the top of the document.
        DispatchQueue.main.async {
            scroll.contentView.scroll(to: .zero)
            scroll.reflectScrolledClipView(scroll.contentView)
        }
        return outer
    }

    @objc func scheduleChanged(_ sender: NSPopUpButton) {
        let values = [0, 6, 12, 24, 168]
        let v = sender.indexOfSelectedItem < values.count ? values[sender.indexOfSelectedItem] : 24
        UserDefaults.standard.set(v, forKey: Prefs.checkInterval)
        applySchedule()
    }

    func applySchedule() {
        scheduleTimer?.invalidate()
        scheduleTimer = nil
        let hours = UserDefaults.standard.integer(forKey: Prefs.checkInterval)
        guard hours > 0 else { return }
        let timer = Timer.scheduledTimer(withTimeInterval: TimeInterval(hours * 3600),
                                         repeats: true) { [weak self] _ in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if isSnoozing() { return }
                if !self.isChecking { self.startCheck() }
            }
        }
        RunLoop.main.add(timer, forMode: .common)
        scheduleTimer = timer
    }

    @objc func settingChanged(_ sender: NSButton) {
        guard let key = sender.identifier?.rawValue else { return }
        UserDefaults.standard.set(sender.state == .on, forKey: key)
        if key == Prefs.launchAtLogin {
            // SMAppService is available on macOS 13+; macOS 12 has no supported
            // in-app API, so report that instead of pretending it worked.
            if #available(macOS 13.0, *) {
                do {
                    if sender.state == .on {
                        try SMAppService.mainApp.register()
                    } else {
                        try SMAppService.mainApp.unregister()
                    }
                } catch {
                    UserDefaults.standard.set(false, forKey: key)
                    sender.state = .off
                    let a = NSAlert()
                    a.messageText = "Could not change the login item"
                    a.informativeText = error.localizedDescription
                    a.addButton(withTitle: "OK"); a.runModal()
                }
            } else {
                UserDefaults.standard.set(false, forKey: key)
                sender.state = .off
                let a = NSAlert()
                a.messageText = "Launch at login needs macOS 13 or newer"
                a.informativeText = "On macOS 12, add MacRefresh in System Preferences → Users & Groups → Login Items."
                a.addButton(withTitle: "OK"); a.runModal()
            }
        }
        if key == Prefs.scanHome || key == Prefs.scanDesktop || key == Prefs.scanDownloads {
            rescan(initial: false)
        }
        if key == Prefs.showIgnored {
            installedTable?.reloadData()
            updatesTable?.reloadData()
        }
        if key == Prefs.showStatusItem { applyStatusItemVisibility() }
        if key == Prefs.showDockIcon {
            NSApp.setActivationPolicy(sender.state == .on ? .regular : .accessory)
        }
    }

    @objc func concurrencyChanged(_ sender: NSPopUpButton) {
        let n = Int(sender.titleOfSelectedItem ?? "3") ?? 3
        UserDefaults.standard.set(n, forKey: Prefs.maxConcurrent)
    }

    @objc func exportCSVClicked() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "MacRefresh-apps.csv"
        panel.title = "Export app list"
        panel.message = "Save the list of installed apps and versions as CSV"
        panel.beginSheetModal(for: window) { [weak self] response in
            guard response == .OK, let url = panel.url, let self = self else { return }
            let csv = csvRows(self.rows)
            do {
                try csv.data(using: .utf8)?.write(to: url)
            } catch {
                let alert = NSAlert()
                alert.messageText = "Could not write the CSV"
                alert.informativeText = error.localizedDescription
                alert.runModal()
            }
        }
    }

    @objc func refreshCatalogClicked() {
        catalogDateLabel?.stringValue = "Downloading…"
        loadCaskIndex(forceRefresh: true) { [weak self] map, list in
            DispatchQueue.main.async {
                self?.ingestCasks(map: map, list: list)
                self?.refreshCatalogDate()
            }
        }
    }

    @objc func openDataFolder() {
        NSWorkspace.shared.open(supportDirectory())
    }

    @objc func removeAllIgnores() {
        Prefs.ignoredIDs = []
        applyIgnoredState()
    }

    // Kept as a compatibility entry point; rescan() calls it.
    func refreshIgnoredLabel() { refreshIgnoredUI() }

    func refreshIgnoredUI() {
        let ids = Prefs.ignoredIDs
        // Popup: every known, non-ignored app.
        ignoreAppPopup.removeAllItems()
        let candidates = rows.filter { !ids.contains($0.bundleID) }
            .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        for r in candidates {
            ignoreAppPopup.addItem(withTitle: r.name)
            ignoreAppPopup.lastItem?.representedObject = r.bundleID
        }
        // Stack: one removable row per ignored app.
        ignoredStack.subviews.forEach { $0.removeFromSuperview() }
        let ignoredRows = rows.filter { ids.contains($0.bundleID) }
            .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        if ignoredRows.isEmpty {
            let l = makeLabel("No apps are ignored.", size: 12, color: .secondaryLabelColor)
            ignoredStack.addArrangedSubview(l)
        }
        for r in ignoredRows {
            let row = NSView()
            row.translatesAutoresizingMaskIntoConstraints = false
            let l = makeLabel(r.name, size: 12)
            l.translatesAutoresizingMaskIntoConstraints = false
            let b = NSButton(title: "Remove", target: self, action: #selector(removeIgnoreRow(_:)))
            b.bezelStyle = .rounded
            b.controlSize = .small
            b.translatesAutoresizingMaskIntoConstraints = false
            b.identifier = NSUserInterfaceItemIdentifier(r.bundleID)
            row.addSubview(l); row.addSubview(b)
            NSLayoutConstraint.activate([
                l.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 6),
                l.centerYAnchor.constraint(equalTo: row.centerYAnchor),
                l.trailingAnchor.constraint(lessThanOrEqualTo: b.leadingAnchor, constant: -8),
                b.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -6),
                b.centerYAnchor.constraint(equalTo: row.centerYAnchor),
                row.widthAnchor.constraint(greaterThanOrEqualToConstant: 300),
                row.heightAnchor.constraint(equalToConstant: 24)
            ])
            ignoredStack.addArrangedSubview(row)
        }
        updateDiskUsage()
    }

    /// Apply the current ignore set to the in-memory rows and refresh views
    /// without doing a full disk re-scan (fast, avoids the laggy pause).
    func applyIgnoredState() {
        let set = Set(Prefs.ignoredIDs)
        for i in rows.indices { rows[i].ignored = set.contains(rows[i].bundleID) }
        updatesTable?.reloadData()
        installedTable?.reloadData()
        updateStats()
        updateBadge()
        refreshIgnoredUI()
    }

    @objc func addIgnoreClicked() {
        guard let bid = ignoreAppPopup.selectedItem?.representedObject as? String else {
            // Empty list: offer to browse for an app instead of doing nothing.
            browseIgnoreClicked()
            return
        }
        var ids = Prefs.ignoredIDs
        if !ids.contains(bid) { ids.append(bid) }
        Prefs.ignoredIDs = ids
        applyIgnoredState()
    }

    @objc func browseIgnoreClicked() {
        let panel = NSOpenPanel()
        panel.title = "Choose an app to ignore"
        panel.allowedContentTypes = [.applicationBundle]
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = URL(fileURLWithPath: "/Applications")
        guard panel.runModal() == .OK, let url = panel.url else { return }
        guard let bundle = Bundle(url: url), let bid = bundle.bundleIdentifier else {
            let alert = NSAlert()
            alert.messageText = "Not a valid app"
            alert.informativeText = "That item doesn't have a bundle identifier, so it can't be ignored."
            alert.addButton(withTitle: "OK")
            alert.runModal()
            return
        }
        var ids = Prefs.ignoredIDs
        if !ids.contains(bid) { ids.append(bid) }
        Prefs.ignoredIDs = ids
        // The picked app may not be in the current scan list; rescan once so it
        // appears in the Ignored list, then re-apply state.
        rescan(initial: false) { [weak self] in self?.applyIgnoredState() }
    }

    @objc func removeIgnoreRow(_ sender: NSButton) {
        guard let bid = sender.identifier?.rawValue else { return }
        var ids = Prefs.ignoredIDs
        ids.removeAll { $0 == bid }
        Prefs.ignoredIDs = ids
        applyIgnoredState()
    }

    // MARK: Custom update sources

    func refreshCustomUI() {
        customAppPopup.removeAllItems()
        let candidates = rows.filter { !$0.isAppStore }
            .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        for r in candidates {
            customAppPopup.addItem(withTitle: r.name)
            customAppPopup.lastItem?.representedObject = r.bundleID
        }
        customStack.subviews.forEach { $0.removeFromSuperview() }
        let sources = Prefs.customSources
        if sources.isEmpty {
            customStack.addArrangedSubview(makeLabel("No custom sources.", size: 12,
                                                     color: .secondaryLabelColor))
        }
        for (bid, url) in sources.sorted(by: { $0.key < $1.key }) {
            let row = NSView()
            row.translatesAutoresizingMaskIntoConstraints = false
            let name = rows.first { $0.bundleID == bid }?.name ?? bid
            let l = makeLabel("\(name): \(url)", size: 11)
            l.translatesAutoresizingMaskIntoConstraints = false
            l.lineBreakMode = .byTruncatingMiddle
            let b = NSButton(title: "Remove", target: self, action: #selector(removeCustomClicked(_:)))
            b.bezelStyle = .rounded
            b.controlSize = .small
            b.translatesAutoresizingMaskIntoConstraints = false
            b.identifier = NSUserInterfaceItemIdentifier(bid)
            row.addSubview(l); row.addSubview(b)
            NSLayoutConstraint.activate([
                l.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 6),
                l.centerYAnchor.constraint(equalTo: row.centerYAnchor),
                l.trailingAnchor.constraint(lessThanOrEqualTo: b.leadingAnchor, constant: -8),
                b.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -6),
                b.centerYAnchor.constraint(equalTo: row.centerYAnchor),
                row.widthAnchor.constraint(greaterThanOrEqualToConstant: 300),
                row.heightAnchor.constraint(equalToConstant: 24)
            ])
            customStack.addArrangedSubview(row)
        }
    }

    @objc func addCustomClicked() {
        guard let bid = customAppPopup.selectedItem?.representedObject as? String else { return }
        let name = customAppPopup.selectedItem?.title ?? bid
        let alert = NSAlert()
        alert.messageText = "Custom update source for \(name)"
        alert.informativeText = "Enter a Sparkle or Squirrel feed URL, or a GitHub project URL (https://github.com/owner/repo)."
        let input = NSTextField(frame: NSRect(x: 0, y: 0, width: 380, height: 24))
        input.stringValue = Prefs.customSources[bid] ?? ""
        alert.accessoryView = input
        alert.addButton(withTitle: "Save")
        alert.addButton(withTitle: "Cancel")
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let url = input.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        var sources = Prefs.customSources
        if url.isEmpty {
            sources.removeValue(forKey: bid)
        } else {
            guard URL(string: url)?.scheme != nil else { return }
            sources[bid] = url
        }
        Prefs.customSources = sources
        refreshCustomUI()
        if let row = rows.first(where: { $0.bundleID == bid }) { checkSingle(row) }
    }

    @objc func removeCustomClicked(_ sender: NSButton) {
        guard let bid = sender.identifier?.rawValue else { return }
        var sources = Prefs.customSources
        sources.removeValue(forKey: bid)
        Prefs.customSources = sources
        refreshCustomUI()
    }

    @objc func removeAllCustomSources() {
        Prefs.customSources = [:]
        refreshCustomUI()
    }

    // MARK: Extra scan folders

    func refreshExtraFoldersUI() {
        extraFoldersStack.subviews.forEach { $0.removeFromSuperview() }
        let folders = Prefs.extraFolders
        if folders.isEmpty {
            extraFoldersStack.addArrangedSubview(makeLabel("No extra folders. Apps anywhere on disk can be added.",
                                                           size: 12, color: .secondaryLabelColor))
        }
        for path in folders {
            let row = NSView()
            row.translatesAutoresizingMaskIntoConstraints = false
            let l = makeLabel(path, size: 11)
            l.translatesAutoresizingMaskIntoConstraints = false
            l.lineBreakMode = .byTruncatingMiddle
            let b = NSButton(title: "Remove", target: self, action: #selector(removeExtraFolderClicked(_:)))
            b.bezelStyle = .rounded
            b.controlSize = .small
            b.translatesAutoresizingMaskIntoConstraints = false
            b.identifier = NSUserInterfaceItemIdentifier(path)
            row.addSubview(l); row.addSubview(b)
            NSLayoutConstraint.activate([
                l.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 6),
                l.centerYAnchor.constraint(equalTo: row.centerYAnchor),
                l.trailingAnchor.constraint(lessThanOrEqualTo: b.leadingAnchor, constant: -8),
                b.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -6),
                b.centerYAnchor.constraint(equalTo: row.centerYAnchor),
                row.widthAnchor.constraint(greaterThanOrEqualToConstant: 300),
                row.heightAnchor.constraint(equalToConstant: 24)
            ])
            extraFoldersStack.addArrangedSubview(row)
        }
    }

    @objc func addExtraFolderClicked() {
        let panel = NSOpenPanel()
        panel.title = "Choose folders to scan"
        panel.message = "MacRefresh will scan the selected folders for apps."
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = true
        guard panel.runModal() == .OK else { return }
        var folders = Prefs.extraFolders
        var changed = false
        for url in panel.urls {
            let path = url.path
            var isDir: ObjCBool = false
            guard FileManager.default.fileExists(atPath: path, isDirectory: &isDir), isDir.boolValue else { continue }
            if !folders.contains(path) { folders.append(path); changed = true }
        }
        guard changed else { return }
        Prefs.extraFolders = folders
        refreshExtraFoldersUI()
        rescan(initial: false)
    }

    @objc func removeExtraFolderClicked(_ sender: NSButton) {
        guard let path = sender.identifier?.rawValue else { return }
        var folders = Prefs.extraFolders
        folders.removeAll { $0 == path }
        Prefs.extraFolders = folders
        refreshExtraFoldersUI()
        rescan(initial: false)
    }

    // MARK: Log viewer

    @objc func viewLogsClicked() {
        let logURL = logsDirectory().appendingPathComponent("app.log")
        let text = (try? String(contentsOf: logURL, encoding: .utf8)) ?? ""
        let trimmed: String
        if text.count > 6000 {
            trimmed = String(text.suffix(6000))
        } else {
            trimmed = text
        }
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 620, height: 360))
        scroll.hasVerticalScroller = true
        let tv = NSTextView(frame: scroll.bounds)
        tv.isEditable = false
        tv.isRichText = false
        tv.font = .monospacedSystemFont(ofSize: 11, weight: .regular)
        tv.string = trimmed.isEmpty ? "(log is empty)" : trimmed
        tv.autoresizingMask = [.width]
        scroll.documentView = tv
        let alert = NSAlert()
        alert.messageText = "MacRefresh log (latest entries)"
        alert.accessoryView = scroll
        alert.addButton(withTitle: "OK")
        _ = alert.addButton(withTitle: "Reveal in Finder")
        let result = alert.runModal()
        if result == .alertSecondButtonReturn {
            NSWorkspace.shared.activateFileViewerSelecting([logURL])
        }
    }

    @objc func revealLogsClicked() {
        NSWorkspace.shared.activateFileViewerSelecting([logsDirectory()])
    }

    // MARK: Custom source test

    @objc func testCustomClicked() {
        let alert = NSAlert()
        alert.messageText = "Test a custom update URL"
        alert.informativeText = "Enter a Sparkle/Squirrel feed URL or a GitHub project URL."
        let input = NSTextField(frame: NSRect(x: 0, y: 0, width: 400, height: 24))
        if let bid = customAppPopup.selectedItem?.representedObject as? String {
            input.stringValue = Prefs.customSources[bid] ?? ""
        }
        alert.accessoryView = input
        alert.addButton(withTitle: "Test")
        alert.addButton(withTitle: "Cancel")
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let raw = input.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }
        testCustomSource(urlString: raw)
    }

    /// Fetch the given URL off the main thread and report what it resolves to.
    func testCustomSource(urlString: String) {
        DispatchQueue.global(qos: .userInitiated).async {
            var report = ""
            if let slug = repositoryStringToSlug(urlString) {
                let sem = DispatchSemaphore(value: 0)
                var rel: GitHubRelease?
                fetchGitHubRelease(repo: slug, force: true) { r in rel = r; sem.signal() }
                _ = sem.wait(timeout: .now() + 20)
                if let rel = rel {
                    report = "GitHub project found.\nLatest: \(rel.version)\nDownload: \(rel.url)"
                } else {
                    report = "No usable GitHub release was found at that URL."
                }
            } else if let u = URL(string: urlString), u.scheme != nil {
                var req = URLRequest(url: u)
                req.timeoutInterval = 20
                let sem = DispatchSemaphore(value: 0)
                var data: Data?
                URLSession.shared.dataTask(with: req) { d, _, _ in data = d; sem.signal() }.resume()
                _ = sem.wait(timeout: .now() + 25)
                if let data = data {
                    let xml = SparkleFeedParser().parse(data: data)
                    if let v = xml.version {
                        report = "Sparkle feed found.\nLatest: \(v)\nDownload: \(xml.download ?? "—")"
                    } else if let sq = parseSquirrelJSON(data) {
                        report = "Squirrel feed found.\nLatest: \(sq.version)\nDownload: \(sq.url ?? "—")"
                    } else {
                        report = "The URL responded but no version information could be parsed."
                    }
                } else {
                    report = "The URL did not respond."
                }
            } else {
                report = "That does not look like a valid URL."
            }
            DispatchQueue.main.async {
                let a = NSAlert()
                a.messageText = "Custom source test"
                a.informativeText = report
                a.addButton(withTitle: "OK"); a.runModal()
            }
        }
    }

    // MARK: Storage / diagnostics

    func humanSize(_ bytes: Int64) -> String {
        let f = ByteCountFormatter()
        f.countStyle = .file
        return f.string(fromByteCount: bytes)
    }

    func updateDiskUsage() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let base = supportDirectory()
            var total: Int64 = 0
            if let en = FileManager.default.enumerator(at: base,
                includingPropertiesForKeys: [.totalFileAllocatedSizeKey]) {
                for case let u as URL in en {
                    if let v = try? u.resourceValues(forKeys: [.totalFileAllocatedSizeKey]),
                       let n = v.totalFileAllocatedSize { total += Int64(n) }
                }
            }
            DispatchQueue.main.async {
                self?.diskUsageLabel?.stringValue = "MacRefresh data takes \(self?.humanSize(total) ?? "?")"
            }
        }
    }

    @objc func clearCachesClicked() {
        ShopIconCache.shared.resetMissing()
        BundleMetaCache.shared.reset()
        let fm = FileManager.default
        for name in ["Icons"] {
            let p = supportDirectory().appendingPathComponent(name).path
            try? fm.removeItem(atPath: p)
        }
        let alert = NSAlert()
        alert.messageText = "Caches cleared"
        alert.informativeText = "Icons and metadata will be rebuilt on the next scan."
        alert.runModal()
        rescan(initial: false)
        updateDiskUsage()
    }

    @objc func runDiagnosticsClicked() {
        // Diagnostics exercise the real download pipeline (temp zips) and
        // toggle a few preferences. Isolate all data in a throwaway folder and
        // snapshot/restore any touched preferences so the user's history,
        // downloads and sort orders are never modified.
        let d = UserDefaults.standard
        let savedSupport = headlessSupportDirectory
        let savedHeadless = headlessMode
        let iso = FileManager.default.temporaryDirectory
            .appendingPathComponent("MacRefreshDiag-\(UUID().uuidString)", isDirectory: true)
        let saved: [(String, Any?)] = [
            (Prefs.updatesSortKey, d.object(forKey: Prefs.updatesSortKey)),
            (Prefs.updatesSortAsc, d.object(forKey: Prefs.updatesSortAsc)),
            (Prefs.installedSortKey, d.object(forKey: Prefs.installedSortKey)),
            (Prefs.installedSortAsc, d.object(forKey: Prefs.installedSortAsc)),
            (Prefs.maxConcurrent, d.object(forKey: Prefs.maxConcurrent))
        ]
        headlessSupportDirectory = iso
        headlessMode = true
        let results = runDiagnostics()
        headlessMode = savedHeadless
        headlessSupportDirectory = savedSupport
        try? FileManager.default.removeItem(at: iso)
        for (key, value) in saved { if let v = value { d.set(v, forKey: key) } }
        updatesTable?.reloadData()
        installedTable?.reloadData()
        let alert = NSAlert()
        alert.messageText = results.failed == 0 ? "All checks passed" : "\(results.failed) check(s) failed"
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 540, height: 320))
        scroll.hasVerticalScroller = true
        scroll.borderType = .bezelBorder
        scroll.autohidesScrollers = true
        let tv = NSTextView()
        tv.isEditable = false
        tv.isRichText = false
        tv.drawsBackground = false
        tv.font = NSFont(name: "Menlo", size: 11) ?? .monospacedSystemFont(ofSize: 11, weight: .regular)
        tv.string = results.lines.joined(separator: "\n")
        scroll.documentView = tv
        alert.accessoryView = scroll
        alert.addButton(withTitle: "OK")
        alert.runModal()
    }

    func refreshCatalogDate() {
        guard let url = try? caskCacheURL().resourceValues(forKeys: [.contentModificationDateKey]),
              let date = url.contentModificationDate else {
            catalogDateLabel?.stringValue = "Not loaded yet"
            return
        }
        let f = DateFormatter()
        f.dateStyle = .medium; f.timeStyle = .short
        catalogDateLabel?.stringValue = "\(caskList.count) apps · updated \(f.string(from: date))"
        updateOverviewInfo()
    }

    // MARK: Data flow

    @objc func rescanAction() { rescan(initial: false) }

    /// Re-scan the disk off the main thread, then refresh every table on the
    /// main thread. `completion` runs after the UI refresh (used by ignore
    /// management and the single-app check flow).
    func rescan(initial: Bool, completion: (() -> Void)? = nil) {
        let includeHome = UserDefaults.standard.bool(forKey: Prefs.scanHome)
        DispatchQueue.global(qos: .userInitiated).async {
            let scanned = scanForApps(includeHome: includeHome)
            DispatchQueue.main.async {
                self.rows = scanned
                self.installedTable?.reloadData()
                self.updatesTable?.reloadData()
                self.updateStats()
                self.refreshSystemStatus()
                self.refreshIgnoredLabel()
                self.refreshCustomUI()
                // Warm size/architecture caches off-main; coalesce one reload
                // as values arrive instead of a reload per cell.
                BundleMetaCache.shared.prefetch(paths: scanned.map { $0.path }) { [weak self] in
                    self?.scheduleMetadataReload()
                }
                SignatureCache.shared.prefetch(paths: scanned.map { $0.path }) { [weak self] in
                    self?.scheduleMetadataReload()
                }
                if initial { self.loadCasksThenCheck(auto: false) }
                completion?()
            }
        }
    }

    func scheduleMetadataReload() {
        metadataReloadWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self = self else { return }
            // A plain reload re-runs filteredInstalled() and therefore
            // re-sorts a list ordered by size/kind.
            self.installedTable?.reloadData()
        }
        metadataReloadWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4, execute: work)
    }

    func loadCasksThenCheck(auto: Bool) {
        loadCaskIndex { [weak self] map, list in
            DispatchQueue.main.async {
                self?.ingestCasks(map: map, list: list)
                if auto { self?.startCheck() }
            }
        }
    }

    func ingestCasks(map: [String: Cask]?, list: [Cask]) {
        caskMap = map
        caskList = list
        caskByToken = Dictionary(uniqueKeysWithValues: list.map { ($0.token, $0) })
        rebuildShop()
        refreshCatalogDate()
    }

    func rebuildShop() {
        shopItems.removeAll()
        let fm = FileManager.default
        let installedNames = Set(rows.map { normalizeName($0.name) })
        for (category, tokens) in shopCatalog {
            for token in tokens {
                guard let cask = caskByToken[token] else { continue }
                var installed: String?
                for target in cask.appTargets where fm.fileExists(atPath: target) { installed = target; break }
                if installed == nil {
                    for name in cask.names where installedNames.contains(normalizeName(name)) {
                        installed = "/Applications/" + (cask.appArtifacts.first ?? name + ".app")
                    }
                }
                shopItems.append(ShopItem(cask: cask, category: category, installedPath: installed))
            }
        }
        shopItems.sort { $0.cask.names.first ?? $0.cask.token < $1.cask.names.first ?? $1.cask.token }
        shopTable?.reloadData()
    }

    @objc func startCheck() {
        guard !isChecking else { return }
        isChecking = true
        checkStopped = false
        checkSpinner?.startAnimation(nil)
        checkButton?.isEnabled = false
        lastCheckLabel?.stringValue = "Checking…"
        refreshStatusMenu()

        let run: () -> Void = { [weak self] in
            guard let self = self else { return }
            // Global watchdog: a check cannot sit unfinished forever even if
            // a source callback is lost beyond the per-app timeout.
            DispatchQueue.main.asyncAfter(deadline: .now() + 150) { [weak self] in
                guard let self = self, self.isChecking, !self.checkStopped else { return }
                self.finishCheck(reason: "timed out")
            }
            let apps = self.rows
            checkUpdates(apps: apps, caskMap: self.caskMap, force: true,
                         completionQueue: .main, progress: { [weak self] _, _, updated in
                guard let self = self, !self.checkStopped else { return }
                if let idx = self.rows.firstIndex(where: {
                    $0.bundleID == updated.bundleID && $0.path == updated.path }) {
                    self.rows[idx] = updated
                }
                self.scheduleCheckProgressReload()
            }, done: { [weak self] in
                guard let self = self, !self.checkStopped else { return }
                self.finishCheck(reason: "done")
            })
        }

        if caskMap == nil {
            loadCaskIndex { [weak self] map, list in
                DispatchQueue.main.async {
                    guard let self = self, !self.checkStopped else { return }
                    self.ingestCasks(map: map, list: list)
                    run()
                }
            }
        } else {
            run()
        }
    }

    /// Coalesce table reloads while a check runs (previously every completed
    /// app triggered two whole-table reloadData calls).
    func scheduleCheckProgressReload() {
        checkProgressWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self = self else { return }
            self.installedTable?.reloadData()
            self.updatesTable?.reloadData()
            self.updateStats()
        }
        checkProgressWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: work)
    }

    /// Finalize a check: "done", "stopped" (⌘.) or "timed out" (watchdog).
    func finishCheck(reason: String) {
        guard isChecking else { return }
        isChecking = false
        checkSpinner?.stopAnimation(nil)
        checkButton?.isEnabled = true
        checkProgressWork?.cancel()

        if reason != "done" {
            // Rows still pending cannot complete now; mark them unknown so
            // the UI doesn't show perpetual "…".
            for i in rows.indices where rows[i].status == .pending {
                rows[i].status = .unknown
                if rows[i].note.isEmpty {
                    rows[i].note = reason == "stopped" ? "Check stopped" : "Check timed out"
                }
            }
        }

        installedTable?.reloadData()
        updatesTable?.reloadData()
        lastCheck = Date()
        UserDefaults.standard.set(Date(), forKey: Prefs.lastCheck)
        let updates = rows.filter { !$0.ignored && $0.status == .update }.count
        let failedLoads = rows.filter {
            !$0.ignored && $0.status == .unknown &&
            ($0.note.lowercased().contains("timed out") ||
             $0.note.lowercased().contains("unavailable"))
        }.count
        lastCheckLabel?.stringValue = lastCheckSummary(reason: reason, updates: updates)
        updateStats()
        rebuildShop()
        updateBadge()
        refreshStatusMenu()
        if reason == "done", updates > 0 { notifyCheckComplete(updates) }
        if failedLoads > 0 { notifyCheckFailed(failedLoads) }
    }

    private func lastCheckSummary(reason: String, updates: Int) -> String {
        let rel = relativeTimeText(Date())
        switch reason {
        case "stopped": return "Check stopped · \(rel)"
        case "timed out": return "Check timed out · \(rel)"
        default: return "Checked \(rel) · \(updates) update\(updates == 1 ? "" : "s")"
        }
    }

    /// Relative "last checked" wording ("2 minutes ago").
    func relativeTimeText(_ date: Date) -> String {
        if Date().timeIntervalSince(date) < 5 { return "just now" }
        let f = RelativeDateTimeFormatter()
        f.unitsStyle = .short
        return f.localizedString(for: date, relativeTo: Date())
    }

    /// Notification when one or more apps could not be reached at all.
    func notifyCheckFailed(_ count: Int) {
        guard UserDefaults.standard.bool(forKey: Prefs.notifications) else { return }
        guard let center = safeNotificationCenter() else { return }
        center.getNotificationSettings { settings in
            guard settings.authorizationStatus == .authorized ||
                  settings.authorizationStatus == .provisional else { return }
            let content = UNMutableNotificationContent()
            content.title = "Some apps could not be checked"
            content.body = "\(count) app\(count == 1 ? "" : "s") did not respond. You can retry from MacRefresh."
            let req = UNNotificationRequest(
                identifier: "macrefresh-checkfail-\(Int(Date().timeIntervalSince1970))",
                content: content, trigger: nil)
            center.add(req)
        }
    }

    func postInstallRefresh() {
        DispatchQueue.main.async {
            let previous = Dictionary(uniqueKeysWithValues: self.rows.map {
                ($0.bundleID + "|" + $0.path, $0)
            })
            self.rescan(initial: false) {
                for i in self.rows.indices {
                    if let old = previous[self.rows[i].bundleID + "|" + self.rows[i].path] {
                        self.rows[i].latest = old.latest
                        self.rows[i].source = old.source
                        self.rows[i].downloadURL = old.downloadURL
                        self.rows[i].homepage = old.homepage
                        self.rows[i].releaseNotesURL = old.releaseNotesURL
                        self.rows[i].caskToken = old.caskToken
                        self.rows[i].appStoreURL = old.appStoreURL
                        self.rows[i].githubRepo = old.githubRepo
                        finalizeStatus(&self.rows[i])
                    }
                }
                self.installedTable?.reloadData()
                self.updatesTable?.reloadData()
                self.rebuildShop()
                self.updateStats()
                self.updateBadge()
            }
        }
    }

    func updateStats() {
        let visible = rows.filter { !$0.ignored }
        let updates = visible.filter { $0.status == .update }.count
        let current = visible.filter { $0.status == .upToDate }.count
        let noSource = visible.filter { $0.status == .unknown }.count
        let dupIDs = duplicateBundleIDs(rows)
        let dupCount = visible.filter { dupIDs.contains($0.bundleID) }.count
        let dupColor = NSColor(calibratedRed: 0.83, green: 0.47, blue: 0.08, alpha: 1)
        let colors: [NSColor] = [.labelColor, .systemOrange, .systemGreen,
                                 .secondaryLabelColor, dupColor]
        for (i, val) in [visible.count, updates, current, noSource, dupCount].enumerated() {
            cards[safe: i]?.setValue("\(val)", color: colors[i])
        }
        if let b = navButtons.first(where: { $0.tag == Section.updates.rawValue }) {
            b.badge.stringValue = updates > 0 ? "\(updates)" : ""
        }
        if let b = navButtons.first(where: { $0.tag == Section.downloads.rawValue }) {
            let active = DownloadManager.shared.jobs.filter {
                $0.state == .downloading || $0.state == .queued || $0.state == .extracting || $0.state == .installing
            }.count
            b.badge.stringValue = active > 0 ? "\(active)" : ""
        }
        refreshStatusMenu()
    }

    func updateBadge() {
        let show = UserDefaults.standard.bool(forKey: Prefs.showDockBadge)
        let updates = rows.filter { !$0.ignored && $0.status == .update }.count
        NSApp.dockTile.badgeLabel = (show && updates > 0) ? "\(updates)" : ""
        NSApp.dockTile.display()
    }

    func notifyCheckComplete(_ updates: Int) {
        guard UserDefaults.standard.bool(forKey: Prefs.notifications) else { return }
        guard let center = safeNotificationCenter() else { return }
        center.getNotificationSettings { settings in
            guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else { return }
            let content = UNMutableNotificationContent()
            content.title = "\(updates) app update\(updates == 1 ? "" : "s") available"
            content.body = "Open MacRefresh to review and install them."
            let req = UNNotificationRequest(identifier: "macrefresh-check-\(Int(Date().timeIntervalSince1970))",
                                            content: content, trigger: nil)
            center.add(req)
        }
    }

    // MARK: Filtering

    func filteredUpdates() -> [AppRow] {
        var list = rows.filter { UserDefaults.standard.bool(forKey: Prefs.showIgnored) || !$0.ignored }
        if updatesOnly { list = list.filter { $0.status == .update } }
        // "Direct updates only": hide rows that would hand off to a web page or
        // the App Store (e.g. page-only installers).
        if UserDefaults.standard.bool(forKey: Prefs.updatesDirectOnly) {
            list = list.filter { directURL(for: $0) != nil }
        }
        if !updatesFilter.isEmpty {
            let q = updatesFilter.lowercased()
            list = list.filter {
                $0.name.lowercased().contains(q)
                || $0.bundleID.lowercased().contains(q)
                || $0.path.lowercased().contains(q)
            }
        }
        // Source popup (All sources / App Store / Homebrew / Sparkle / GitHub / Web).
        switch updatesSourceFilter.titleOfSelectedItem {
        case "App Store": list = list.filter { $0.source.contains("App Store") }
        case "Homebrew": list = list.filter { $0.source.contains("Homebrew") }
        case "Sparkle": list = list.filter { $0.source.contains("Sparkle") || $0.source.contains("feed") }
        case "GitHub": list = list.filter { $0.source.contains("GitHub") }
        case "Web": list = list.filter { $0.source.lowercased().contains("web") }
        default: break
        }
        return sortUpdates(list)
    }

    /// Sort updates rows by the clicked column (App / Installed / Source).
    func sortUpdates(_ list: [AppRow]) -> [AppRow] {
        let key = UserDefaults.standard.string(forKey: Prefs.updatesSortKey) ?? "app"
        let asc = UserDefaults.standard.bool(forKey: Prefs.updatesSortAsc)
        let cmp: (AppRow, AppRow) -> ComparisonResult
        switch key {
        case "change":
            cmp = { compareVersions($0.installed, $1.installed) }
        case "source":
            cmp = { $0.source.localizedCaseInsensitiveCompare($1.source) }
        default:
            cmp = { $0.name.localizedCaseInsensitiveCompare($1.name) }
        }
        var out = list.sorted { cmp($0, $1) == .orderedAscending }
        if !asc { out.reverse() }
        return out
    }

    func filteredInstalled() -> [AppRow] {
        var list = rows
        if !UserDefaults.standard.bool(forKey: Prefs.showIgnored) { list = list.filter { !$0.ignored } }
        // Kind popup: All apps / Duplicates / App Store / Universal / Apple Silicon /
        // Intel / Unsigned / Quarantined.
        switch installedKindFilter.titleOfSelectedItem {
        case "Duplicates":
            list = list.filter { $0.isDuplicate }
        case "App Store":
            list = list.filter { $0.isAppStore || $0.source.contains("App Store") }
        case "Universal":
            list = list.filter { BundleMetaCache.shared.cachedArchitecture(for: $0.path) == "Universal" }
        case "Apple Silicon":
            list = list.filter {
                let a = BundleMetaCache.shared.cachedArchitecture(for: $0.path)
                return a == "Apple Silicon"
            }
        case "Intel":
            list = list.filter {
                let a = BundleMetaCache.shared.cachedArchitecture(for: $0.path)
                return a == "Intel"
            }
        case "Unsigned":
            list = list.filter {
                if let s = SignatureCache.shared.cached(for: $0.path)?.summary {
                    return s == "Unsigned"
                }
                return $0.signatureSummary == "Unsigned"
            }
        case "Quarantined":
            list = list.filter { $0.quarantined }
        default:
            break
        }
        if !installedFilter.isEmpty {
            let q = installedFilter.lowercased()
            if q == "duplicate" {
                list = list.filter { $0.isDuplicate }
            } else {
                list = list.filter {
                    $0.name.lowercased().contains(q)
                    || $0.bundleID.lowercased().contains(q)
                    || $0.path.lowercased().contains(q)
                }
            }
        }
        return sortInstalled(list)
    }

    func filteredShop() -> [ShopItem] {
        let cat = shopCategory.titleOfSelectedItem ?? "All categories"
        var list = shopItems
        if cat != "All categories" { list = list.filter { $0.category == cat } }
        switch shopFilterSegment.selectedSegment {
        case 1: list = list.filter { $0.installedPath == nil }
        case 2: list = list.filter { $0.installedPath != nil }
        case 3: list = list.filter { Prefs.shopFavorites.contains($0.cask.token) }
        default: break
        }
        if !shopFilter.isEmpty {
            let q = shopFilter.lowercased()
            list = list.filter { item in
                item.cask.names.joined(separator: " ").lowercased().contains(q)
                || item.cask.token.contains(q) || item.cask.desc.lowercased().contains(q)
            }
        }
        return sortShop(list)
    }

    // MARK: Downloads / installs

    func directURL(for row: AppRow) -> URL? {
        if let s = row.downloadURL, isDirectInstallerURL(s), let u = URL(string: s) { return u }
        if let token = row.caskToken, let cask = caskByToken[token], isDirectInstallerURL(cask.url) {
            return URL(string: cask.url)
        }
        return nil
    }

    func startDownloadOrOpen(_ row: AppRow) {
        if let url = directURL(for: row) {
            let job = DownloadJob(title: row.name, kind: "Update", url: url, relaunch: true)
            job.existingPath = row.path
            job.bundleID = row.bundleID
            job.expectedVersion = row.latest
            if let token = row.caskToken, let cask = caskByToken[token] {
                job.expectedAppName = cask.appArtifacts.first
                job.expectedTarget = cask.appTargets.first
                job.quitIDs = cask.quitIDs
            }
            if job.expectedAppName == nil {
                job.expectedAppName = (row.path as NSString).lastPathComponent
            }
            DownloadManager.shared.enqueue(job)
            switchTo(.downloads)
        } else if let url = row.bestPageURL() {
            // App Store apps open in the App Store; everything else opens its page.
            NSWorkspace.shared.open(url)
        } else {
            NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: row.path)])
        }
    }

    // MARK: Duplicate resolution

    /// Open the selected app's homepage (or best available page).
    @objc func openSelectedHomepage() {
        guard let row = selectedInstalledRows().first, let url = row.bestPageURL() else { return }
        NSWorkspace.shared.open(url)
    }

    /// One-click duplicate cleanup: trash every extra copy, no modal.
    @objc func quickClearDuplicates() {
        let groups = duplicateGroups(in: rows)
        guard !groups.isEmpty else {
            let a = NSAlert()
            a.messageText = "No duplicate apps found"
            a.addButton(withTitle: "OK"); a.runModal()
            return
        }
        clearDuplicateCopies(groups)
    }

    /// One-click: download the newest build into every older extra copy.
    @objc func quickUpdateDuplicates() {
        let groups = duplicateGroups(in: rows)
        guard !groups.isEmpty else {
            let a = NSAlert()
            a.messageText = "No duplicate apps found"
            a.addButton(withTitle: "OK"); a.runModal()
            return
        }
        updateOlderDuplicateCopies(groups)
    }

    @objc func resolveDuplicatesClicked() {
        let groups = duplicateGroups(in: rows)
        guard !groups.isEmpty else {
            let a = NSAlert()
            a.messageText = "No duplicate apps found"
            a.informativeText = "MacRefresh has not found multiple copies sharing a bundle identifier."
            a.addButton(withTitle: "OK"); a.runModal()
            return
        }
        let extraCount = groups.reduce(0) { $0 + $1.count - 1 }
        let listText = groups.map { g -> String in
            let copies = g.map { "  • \($0.installed) — \($0.path)" }.joined(separator: "\n")
            return "\(g[0].name):\n\(copies)"
        }.joined(separator: "\n\n")
        let alert = NSAlert()
        alert.messageText = "Resolve \(groups.count) duplicate group\(groups.count == 1 ? "" : "s")?"
        alert.informativeText = "\(extraCount) extra cop\(extraCount == 1 ? "y" : "ies") detected.\n\n\(listText)\n\n“Keep Newest” moves every extra copy to Trash. “Update Older” downloads the newest version into each extra copy’s own location."
        alert.addButton(withTitle: "Keep Newest, Trash Older Copies")
        alert.addButton(withTitle: "Update Older Copies")
        alert.addButton(withTitle: "Cancel")
        alert.alertStyle = .warning
        switch alert.runModal() {
        case .alertFirstButtonReturn: clearDuplicateCopies(groups)
        case .alertSecondButtonReturn: updateOlderDuplicateCopies(groups)
        default: break
        }
    }

    /// Trash every non-primary copy in each group (primary = best location/newest).
    func clearDuplicateCopies(_ groups: [[AppRow]]) {
        var toTrash: [URL] = []
        for g in groups where g.count > 1 {
            toTrash.append(contentsOf: g.dropFirst().map { URL(fileURLWithPath: $0.path) })
        }
        guard !toTrash.isEmpty else { return }
        NSWorkspace.shared.recycle(toTrash) { [weak self] _, error in
            DispatchQueue.main.async {
                if let error = error {
                    let a = NSAlert()
                    a.messageText = "Some copies could not be moved to Trash"
                    a.informativeText = "Quit the app first if it is running.\n\n\(error.localizedDescription)"
                    a.addButton(withTitle: "OK"); a.runModal()
                }
                self?.rescan(initial: false)
            }
        }
    }

    /// Download the newest version into each extra copy's own location.
    func updateOlderDuplicateCopies(_ groups: [[AppRow]]) {
        var started = 0
        for g in groups where g.count > 1 {
            for copy in g.dropFirst() {
                guard let latest = copy.latest, isPlausibleVersion(latest) else { continue }
                if compareVersions(copy.installed, latest) == .orderedAscending {
                    startDownloadOrOpen(copy); started += 1
                }
            }
        }
        if started == 0 {
            let a = NSAlert()
            a.messageText = "All copies are already up to date"
            a.informativeText = "Run a check first so MacRefresh can discover newer versions."
            a.addButton(withTitle: "OK"); a.runModal()
        }
    }

    func startShopInstall(_ item: ShopItem) {
        guard isDirectInstallerURL(item.cask.url), let url = URL(string: item.cask.url) else {
            if let home = URL(string: item.cask.homepage) { NSWorkspace.shared.open(home) }
            return
        }
        let job = DownloadJob(title: item.cask.names.first ?? item.cask.token,
                              kind: "Install", url: url, relaunch: false)
        job.expectedAppName = item.cask.appArtifacts.first
        job.expectedTarget = item.cask.appTargets.first
        job.quitIDs = item.cask.quitIDs
        if !item.cask.marketingVersion.isEmpty && item.cask.marketingVersion != "latest" && item.cask.marketingVersion != "0" {
            job.expectedVersion = item.cask.marketingVersion
        }
        DownloadManager.shared.enqueue(job)
        switchTo(.downloads)
    }

    func activeJob(for url: URL?) -> DownloadJob? {
        guard let url = url else { return nil }
        return DownloadManager.shared.jobs.first { $0.url == url && ($0.state == .queued || $0.state == .downloading
            || $0.state == .extracting || $0.state == .installing || $0.state == .openingInstaller) }
    }

    func downloadsChanged() {
        downloadsReloadWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            self?.downloadsTable?.reloadData()
            self?.updatesTable?.reloadData()
            self?.shopTable?.reloadData()
            self?.updateStats()
            self?.updateDownloadsAggregate()
        }
        downloadsReloadWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: work)
    }

    @objc func updatesAction(_ sender: NSButton) {
        let list = filteredUpdates()
        guard sender.tag < list.count else { return }
        startDownloadOrOpen(list[sender.tag])
    }

    @objc func shopAction(_ sender: NSButton) {
        let list = filteredShop()
        guard sender.tag < list.count else { return }
        let item = list[sender.tag]
        if item.installedPath == nil { startShopInstall(item) }
        else if let p = item.installedPath { NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: p)]) }
    }

    @objc func downloadsAction(_ sender: NSButton) {
        let jobs = DownloadManager.shared.jobs
        guard sender.tag < jobs.count else { return }
        let job = jobs[sender.tag]
        switch job.state {
        case .queued:
            DownloadManager.shared.cancel(job)
        case .downloading:
            DownloadManager.shared.pause(job)
        case .paused:
            DownloadManager.shared.resumeDownload(job)
        case .done:
            if let app = job.installedURL {
                NSWorkspace.shared.openApplication(at: app, configuration: .init())
            } else if let f = job.localURL {
                NSWorkspace.shared.activateFileViewerSelecting([f])
            }
        case .failed:
            DownloadManager.shared.retry(job)
        case .canceled:
            if let f = job.localURL {
                NSWorkspace.shared.activateFileViewerSelecting([f])
            } else {
                DownloadManager.shared.retry(job)
            }
        case .openingInstaller:
            if let f = job.localURL { NSWorkspace.shared.activateFileViewerSelecting([f]) }
        default: break
        }
    }

    // MARK: Release notes popover

    @objc func updatesNotes(_ sender: NSButton) {
        let list = filteredUpdates()
        guard sender.tag < list.count else { return }
        showReleaseNotes(row: list[sender.tag], anchor: sender)
    }

    func showReleaseNotes(row: AppRow, anchor: NSView) {
        let popover = NSPopover()
        popover.behavior = .transient
        let vc = NSViewController()
        let doc = NSView(frame: NSRect(x: 0, y: 0, width: 460, height: 320))
        if let s = row.releaseNotesURL, let u = URL(string: s) {
            let wv = WKWebView(frame: doc.bounds)
            wv.autoresizingMask = [.width, .height]
            wv.load(URLRequest(url: u))
            doc.addSubview(wv)
        } else {
            let text = row.note.isEmpty ? (row.homepage ?? "No release notes are available.") : row.note
            let tv = NSTextField(wrappingLabelWithString: text)
            tv.frame = NSRect(x: 14, y: 14, width: 432, height: 292)
            tv.autoresizingMask = [.width, .height]
            doc.addSubview(tv)
        }
        vc.view = doc
        popover.contentViewController = vc
        popover.show(relativeTo: anchor.bounds, of: anchor, preferredEdge: .minY)
        releaseNotesPopover = popover
    }

    // MARK: Signature verification / data reveal

    func verifySignature(row: AppRow) {
        DispatchQueue.global(qos: .userInitiated).async {
            let r = Installer.runProc("/usr/bin/codesign",
                ["--verify", "--deep", "--strict", "--verbose=2", row.path], timeout: 60)
            DispatchQueue.main.async {
                let ok = r.code == 0
                let alert = NSAlert()
                alert.messageText = ok ? "\(row.name): valid signature" : "\(row.name): signature problem"
                alert.informativeText = r.output.isEmpty ? "(no output)" : r.output
                alert.alertStyle = ok ? .informational : .warning
                alert.addButton(withTitle: "OK")
                alert.runModal()
            }
        }
    }

    func revealAppData(row: AppRow) {
        let fm = FileManager.default
        let home = fm.homeDirectoryForCurrentUser
        var found: [URL] = []
        let candidates = [
            home.appendingPathComponent("Library/Containers/\(row.bundleID)"),
            home.appendingPathComponent("Library/Application Support/\(row.bundleID)"),
            home.appendingPathComponent("Library/Application Support/\(row.name)"),
            home.appendingPathComponent("Library/Preferences/\(row.bundleID).plist")
        ]
        for u in candidates where fm.fileExists(atPath: u.path) { found.append(u) }
        let gc = home.appendingPathComponent("Library/Group Containers")
        if let entries = try? fm.contentsOfDirectory(atPath: gc.path) {
            for e in entries where e.contains(row.bundleID) {
                found.append(gc.appendingPathComponent(e))
            }
        }
        if found.isEmpty {
            let alert = NSAlert()
            alert.messageText = "No data folders found for \(row.name)"
            alert.informativeText = "The app may store its data inside its own bundle or use a different identifier."
            alert.addButton(withTitle: "OK")
            alert.runModal()
            return
        }
        NSWorkspace.shared.activateFileViewerSelecting(found)
    }

    // MARK: Copy / pasteboard

    func copyText(_ s: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(s, forType: .string)
    }

    // MARK: Dropped files

    func handleDroppedURLs(_ urls: [URL]) {
        for u in urls {
            if u.pathExtension.lowercased() == "app" {
                guard let row = rows.first(where: { $0.path == u.path }) else {
                    rescan(initial: false) { [weak self] in
                        guard let self = self else { return }
                        if let row = self.rows.first(where: { $0.path == u.path }) {
                            self.checkSingle(row)
                        }
                    }
                    return
                }
                checkSingle(row)
            } else if ["dmg", "zip", "pkg", "mpkg"].contains(u.pathExtension.lowercased()) {
                DownloadManager.shared.enqueueLocal(u)
                switchTo(.downloads)
            } else {
                NSWorkspace.shared.activateFileViewerSelecting([u])
            }
        }
    }

    func checkSingle(_ row: AppRow) {
        switchTo(.updates)
        checkUpdates(apps: [row], caskMap: caskMap, force: true,
                     completionQueue: .main, progress: { _, _, _ in }) { [weak self] in
            guard let self = self else { return }
            self.rescan(initial: false) {
                self.presentCheckSingleAlert(row: row)
            }
        }
    }

    func presentCheckSingleAlert(row: AppRow) {
        let alert = NSAlert()
        guard let fresh = rows.first(where: {
            $0.bundleID == row.bundleID && $0.path == row.path }) else { return }
        switch fresh.status {
        case .update:
            alert.messageText = "\(fresh.name) has an update: \(fresh.latest ?? "?")"
            alert.addButton(withTitle: "Update")
            alert.addButton(withTitle: "Later")
            if alert.runModal() == .alertFirstButtonReturn { self.startDownloadOrOpen(fresh) }
        case .upToDate:
            alert.messageText = "\(fresh.name) is up to date (\(fresh.installed))"
            alert.addButton(withTitle: "OK")
            alert.runModal()
        default:
            alert.messageText = "No update source found for \(fresh.name)"
            alert.addButton(withTitle: "OK")
            alert.runModal()
        }
    }

    // MARK: JSON / HTML export

    @objc func exportJSONClicked() { exportUsingPanel(ext: "json", name: "MacRefresh-apps.json") }
    @objc func exportHTMLClicked() { exportUsingPanel(ext: "html", name: "MacRefresh-apps.html") }

    func exportUsingPanel(ext: String, name: String) {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = name
        panel.beginSheetModal(for: window) { [weak self] response in
            guard response == .OK, let url = panel.url, let self = self else { return }
            let content: String
            if ext == "json" { content = self.jsonReport() } else { content = self.htmlReport() }
            do {
                try content.data(using: .utf8)?.write(to: url)
            } catch {
                let a = NSAlert(); a.messageText = "Could not write the file"
                a.informativeText = error.localizedDescription; a.runModal()
            }
        }
    }

    func jsonReport() -> String {
        let objs: [[String: String]] = rows.map { r in
            [
                "name": r.name, "path": r.path, "bundleID": r.bundleID,
                "installed": r.installed, "latest": r.latest ?? "",
                "source": r.source, "status": statusText(r.status),
                "duplicate": r.isDuplicate ? "yes" : "no"
            ]
        }
        if let d = try? JSONSerialization.data(withJSONObject: objs, options: [.prettyPrinted, .sortedKeys]),
           let s = String(data: d, encoding: .utf8) { return s }
        return "[]"
    }

    func htmlReport() -> String {
        func esc(_ s: String) -> String {
            s.replacingOccurrences(of: "&", with: "&amp;")
             .replacingOccurrences(of: "<", with: "&lt;")
             .replacingOccurrences(of: ">", with: "&gt;")
        }
        var rowsHtml = ""
        for r in rows {
            rowsHtml += "<tr><td>\(esc(r.name))</td><td>\(esc(r.installed))</td>"
                + "<td>\(esc(r.latest ?? ""))</td><td>\(esc(r.source))</td>"
                + "<td>\(esc(statusText(r.status)))</td>"
                + "<td>\(r.isDuplicate ? "Yes" : "No")</td></tr>"
        }
        return """
        <!doctype html><html><head><meta charset="utf-8">
        <title>MacRefresh App List</title>
        <style>
        body{font:-apple-system,sans-serif;margin:32px;color:#1d1d1f}
        h1{font-size:22px} table{border-collapse:collapse;width:100%;margin-top:16px}
        th,td{border:1px solid #d2d2d7;padding:7px 10px;text-align:left;font-size:13px}
        th{background:#f5f5f7}
        </style></head><body>
        <h1>MacRefresh App List</h1>
        <p>Generated \(Date())</p>
        <table><thead><tr><th>App</th><th>Installed</th><th>Latest</th>
        <th>Source</th><th>Status</th><th>Duplicate</th></tr></thead><tbody>
        \(rowsHtml)
        </tbody></table></body></html>
        """
    }

    // MARK: Changelog

    /// One-time first-run welcome (separate flag from the per-version
    /// changelog so re-installs don't re-prompt forever).
    func maybeShowOnboarding() {
        guard !UserDefaults.standard.bool(forKey: Prefs.onboardingDoneV1) else { return }
        UserDefaults.standard.set(true, forKey: Prefs.onboardingDoneV1)
        perform(#selector(showOnboarding), with: nil, afterDelay: 0.6)
    }

    @objc func showOnboarding() {
        let a = NSAlert()
        a.messageText = "Welcome to MacRefresh"
        a.informativeText = """
        MacRefresh checks apps in /Applications, ~/Applications, your Desktop and (optionally) Downloads \
        for updates from official sources: Homebrew casks, Sparkle and Squirrel feeds, GitHub releases \
        and the App Store.

        It is free, open-source, has no accounts and no tracking. Downloads happen inside the app; \
        packages that truly need an installer prompt you with the native macOS dialog.

        Tip: open the Tools pane for update history with one-click rollback, storage management, \
        reports and quiet hours.
        """
        a.addButton(withTitle: "Get started")
        a.runModal()
    }

    func maybeShowChangelog() {
        let seen = UserDefaults.standard.string(forKey: Prefs.seenVersion) ?? ""
        guard seen != MacRefreshVersion else { return }
        UserDefaults.standard.set(MacRefreshVersion, forKey: Prefs.seenVersion)
        perform(#selector(showChangelog), with: nil, afterDelay: 1.0)
    }

    @objc func showChangelog() {
        let alert = NSAlert()
        alert.messageText = "What's new in MacRefresh 1.0"
        alert.informativeText = changelogText()
        alert.addButton(withTitle: "Continue")
        alert.runModal()
    }

    func changelogText() -> String {
        return """
        Welcome to MacRefresh 1.0, an independent update manager for macOS.

        Duplicate apps:
        • “Resolve Duplicates…” lists every group of copies sharing an app ID.
        • Keep Newest moves the extra copies to Trash in one step.
        • Update Older downloads the newest version into each extra copy’s own location.
        • “Quick Clear Duplicates” and “Quick Update Older Copies” buttons act in one click.
        • “Keep This Copy, Trash Others” is available in the row context menu.

        No more fake updates:
        • Every source’s minimum macOS requirement is checked against your system.
        • Updates that cannot run on your macOS (for example an App Store app whose latest release needs macOS 18) are reported as up-to-date with an explanation instead of being offered.
        • Strict version normalization: a leading “v”, build numbers, brackets and marketing text never trigger false updates; implausible strings are rejected.
        • Updates tables can be sorted by app, installed version or source, with a “Direct only” filter.

        More update sources:
        • Electron apps without an updater config are resolved from app.asar’s package.json repository.
        • Squirrel.Mac JSON feeds are supported alongside Sparkle XML feeds.
        • Per-app custom update URLs can be added and tested in Settings (Sparkle, Squirrel or GitHub).
        • Extra scan folders can be added so copies anywhere on disk are found.

        Automatic, in-app updates:
        • Downloads and installs complete inside MacRefresh: DMGs are mounted and swapped in, packages install with the native administrator prompt, and old copies are replaced in place.
        • Parallel downloads with pause/resume, speed and ETA, retry, and a stall watchdog.
        • Download Only keeps the installer without installing it; SHA-256 digests and signature verification are one click away.
        • A menu-bar item, finish notifications and scheduled checks (including twice daily).

        Finding every app:
        • Scans /Applications, ~/Applications and the Desktop (Downloads optional), all off the main thread.
        • A free Shop of 193 free apps with real icons, categories, minimum-macOS info and multi-select install.
        • Release notes, signature verification, app data, and CSV/JSON/HTML reports.
        """
    }

    // MARK: Context menus

    func tableView(_ tableView: NSTableView, menuForRows rows: IndexSet) -> NSMenu? {
        let menu = NSMenu()
        func mi(_ title: String, _ action: Selector, _ obj: Any?) -> NSMenuItem {
            let i = NSMenuItem(title: title, action: action, keyEquivalent: "")
            i.target = self; i.representedObject = obj
            return i
        }
        switch tableView.identifier?.rawValue {
        case "updates", "installed":
            let list = tableView.identifier?.rawValue == "updates" ? filteredUpdates() : filteredInstalled()
            let picked = rows.compactMap { $0 < list.count ? list[$0] : nil }
            guard let first = picked.first else { return nil }
            menu.addItem(mi("Update", #selector(cmUpdate), picked))
            menu.addItem(mi("Download Only (Don't Install)", #selector(cmDownloadOnly), picked))
            menu.addItem(mi("Open App", #selector(cmOpenApp), first))
            menu.addItem(mi("Reveal in Finder", #selector(cmReveal), picked))
            if first.isDuplicate {
                menu.addItem(mi("Reveal duplicates", #selector(cmRevealDuplicates), first))
                menu.addItem(mi("Keep This Copy, Trash Others…", #selector(cmKeepThisCopy), first))
            }
            menu.addItem(.separator())
            menu.addItem(mi(first.ignored ? "Unignore" : "Ignore", #selector(cmToggleIgnore), picked))
            menu.addItem(mi("Verify signature", #selector(cmVerify), first))
            menu.addItem(mi("Show app data", #selector(cmShowData), first))
            menu.addItem(mi("Release notes", #selector(cmNotes), first))
            menu.addItem(.separator())
            menu.addItem(mi("Copy name", #selector(cmCopyName), first))
            menu.addItem(mi("Copy installed version", #selector(cmCopyVersion), first))
            menu.addItem(mi("Copy bundle identifier", #selector(cmCopyBundleID), first))
            menu.addItem(mi("Copy version info", #selector(cmCopyVersionInfo), first))
            menu.addItem(mi("Copy download URL", #selector(cmCopyURL), first))
            menu.addItem(mi("Check now", #selector(cmCheckNow), first))
            menu.addItem(mi("Set Custom Update URL…", #selector(cmSetCustomSource), first))
            if first.status == .unknown {
                menu.addItem(mi("Search Web for Updates", #selector(cmWebSearch), first))
            }
            menu.addItem(mi("Trash this copy…", #selector(cmTrashCopy), picked))
            menu.addItem(mi("Uninstall…", #selector(cmUninstall), picked))
        case "shop":
            let list = filteredShop()
            let picked = rows.compactMap { $0 < list.count ? list[$0] : nil }
            guard let first = picked.first else { return nil }
            menu.addItem(mi(first.installedPath == nil ? "Install" : "Reveal in Finder",
                            #selector(cmShopPrimary), picked))
            menu.addItem(mi("Open homepage", #selector(cmShopHomepage), first))
            menu.addItem(.separator())
            let faved = Prefs.shopFavorites.contains(first.cask.token)
            menu.addItem(mi(faved ? "Remove from Favorites" : "Add to Favorites",
                            #selector(cmShopFavorite), first))
            menu.addItem(.separator())
            menu.addItem(mi("Copy name", #selector(cmShopCopyName), first))
            menu.addItem(mi("Copy cask token", #selector(cmShopCopyToken), first))
        case "downloads":
            let jobs = DownloadManager.shared.jobs
            let picked = rows.compactMap { $0 < jobs.count ? jobs[$0] : nil }
            guard let first = picked.first else { return nil }
            menu.addItem(mi("Retry", #selector(cmJobRetry), first))
            menu.addItem(mi("Cancel", #selector(cmJobCancel), first))
            menu.addItem(mi("Reveal in Finder", #selector(cmJobReveal), first))
            menu.addItem(mi("Copy SHA-256", #selector(cmJobCopySHA), first))
            menu.addItem(.separator())
            menu.addItem(mi("Clear finished", #selector(cmClearFinished), nil))
        default: return nil
        }
        return menu
    }

    func pickedRows(_ sender: NSMenuItem) -> [AppRow] {
        (sender.representedObject as? [AppRow]) ?? []
    }
    @objc func cmUpdate(_ s: NSMenuItem) {
        for r in pickedRows(s) { startDownloadOrOpen(r) }
    }
    /// Download the installer without installing it; the file is revealed.
    @objc func cmDownloadOnly(_ s: NSMenuItem) {
        for r in pickedRows(s) {
            guard let url = directURL(for: r) else {
                if let page = r.bestPageURL() { NSWorkspace.shared.open(page) }
                continue
            }
            let job = DownloadJob(title: r.name, kind: "Download", url: url, relaunch: false)
            job.installAfterDownload = false
            job.existingPath = r.path
            job.bundleID = r.bundleID
            job.expectedVersion = r.latest
            if let token = r.caskToken, let cask = caskByToken[token] {
                job.expectedAppName = cask.appArtifacts.first
                job.expectedTarget = cask.appTargets.first
                job.quitIDs = cask.quitIDs
            }
            DownloadManager.shared.enqueue(job)
            switchTo(.downloads)
        }
    }
    @objc func cmOpenApp(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        NSWorkspace.shared.openApplication(at: URL(fileURLWithPath: r.path), configuration: .init())
    }
    @objc func cmReveal(_ s: NSMenuItem) {
        let rs = pickedRows(s)
        NSWorkspace.shared.activateFileViewerSelecting(rs.map { URL(fileURLWithPath: $0.path) })
    }
    @objc func cmToggleIgnore(_ s: NSMenuItem) {
        let rs = pickedRows(s)
        var ids = Prefs.ignoredIDs
        for r in rs {
            if ids.contains(r.bundleID) { ids.removeAll { $0 == r.bundleID } }
            else { ids.append(r.bundleID) }
        }
        Prefs.ignoredIDs = ids
        applyIgnoredState()
    }
    @objc func cmVerify(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        verifySignature(row: r)
    }
    @objc func cmShowData(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        revealAppData(row: r)
    }
    @objc func cmNotes(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        showReleaseNotes(row: r, anchor: window.contentView!)
    }
    @objc func cmCopyName(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        copyText(r.name)
    }
    @objc func cmCopyVersion(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        copyText(r.installed)
    }
    @objc func cmCheckNow(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        checkSingle(r)
    }
    @objc func cmUninstall(_ s: NSMenuItem) {
        let rs = pickedRows(s)
        let alert = NSAlert()
        alert.messageText = "Uninstall \(rs.map { $0.name }.joined(separator: ", "))?"
        alert.informativeText = "The app(s) will be moved to the Trash."
        alert.addButton(withTitle: "Move to Trash")
        alert.addButton(withTitle: "Cancel")
        alert.alertStyle = .warning
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        NSWorkspace.shared.recycle(rs.map { URL(fileURLWithPath: $0.path) }) { [weak self] _, _ in
            DispatchQueue.main.async { self?.rescan(initial: false) }
        }
    }
    @objc func cmRevealDuplicates(_ s: NSMenuItem) {
        guard let r = s.representedObject as? AppRow else { return }
        let copies = rows.filter { $0.bundleID == r.bundleID }
        NSWorkspace.shared.activateFileViewerSelecting(copies.map { URL(fileURLWithPath: $0.path) })
    }
    @objc func cmKeepThisCopy(_ s: NSMenuItem) {
        guard let keep = s.representedObject as? AppRow else { return }
        let others = rows.filter { $0.bundleID == keep.bundleID && $0.path != keep.path }
        guard !others.isEmpty else { return }
        let alert = NSAlert()
        alert.messageText = "Keep this copy and trash \(others.count) other\(others.count == 1 ? "" : "s")?"
        alert.informativeText = "Keep:\n\(keep.path)\n\nMove to Trash:\n" + others.map { $0.path }.joined(separator: "\n")
        alert.addButton(withTitle: "Move Others to Trash")
        alert.addButton(withTitle: "Cancel")
        alert.alertStyle = .warning
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        NSWorkspace.shared.recycle(others.map { URL(fileURLWithPath: $0.path) }) { [weak self] _, error in
            DispatchQueue.main.async {
                if let error = error {
                    let a = NSAlert()
                    a.messageText = "Some copies could not be moved to Trash"
                    a.informativeText = error.localizedDescription
                    a.addButton(withTitle: "OK"); a.runModal()
                }
                self?.rescan(initial: false)
            }
        }
    }
    @objc func cmSetCustomSource(_ s: NSMenuItem) {
        guard let row = s.representedObject as? AppRow else { return }
        let alert = NSAlert()
        alert.messageText = "Custom update source for \(row.name)"
        alert.informativeText = "Enter a Sparkle or Squirrel feed URL, or a GitHub project URL. Leave blank to clear."
        let input = NSTextField(frame: NSRect(x: 0, y: 0, width: 380, height: 24))
        input.stringValue = Prefs.customSources[row.bundleID] ?? ""
        alert.accessoryView = input
        alert.addButton(withTitle: "Save")
        alert.addButton(withTitle: "Cancel")
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let url = input.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        var sources = Prefs.customSources
        if url.isEmpty { sources.removeValue(forKey: row.bundleID) }
        else {
            guard URL(string: url)?.scheme != nil else { return }
            sources[row.bundleID] = url
        }
        Prefs.customSources = sources
        refreshCustomUI()
        checkSingle(row)
    }
    @objc func cmWebSearch(_ s: NSMenuItem) {
        guard let row = s.representedObject as? AppRow else { return }
        let q = "\(row.name) for mac download"
            .addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? row.name
        if let u = URL(string: "https://duckduckgo.com/?q=\(q)") {
            NSWorkspace.shared.open(u)
        }
    }
    @objc func cmTrashCopy(_ s: NSMenuItem) {
        let rs = pickedRows(s)
        let alert = NSAlert()
        alert.messageText = "Move this copy to the Trash?"
        alert.informativeText = rs.map { $0.path }.joined(separator: "\n")
        alert.addButton(withTitle: "Move to Trash")
        alert.addButton(withTitle: "Cancel")
        alert.alertStyle = .warning
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        NSWorkspace.shared.recycle(rs.map { URL(fileURLWithPath: $0.path) }) { [weak self] _, _ in
            DispatchQueue.main.async { self?.rescan(initial: false) }
        }
    }
    @objc func cmCopyURL(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first, let u = r.downloadURL else { return }
        copyText(u)
    }
    @objc func cmCopyBundleID(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        copyText(r.bundleID)
    }
    @objc func cmCopyVersionInfo(_ s: NSMenuItem) {
        guard let r = pickedRows(s).first else { return }
        var lines = [
            "Name: \(r.name)",
            "Bundle ID: \(r.bundleID)",
            "Installed version: \(r.installed)",
            "Path: \(r.path)",
            "Source: \(r.source)"
        ]
        if let latest = r.latest { lines.append("Latest version: \(latest)") }
        if let url = r.downloadURL { lines.append("Download URL: \(url)") }
        if let home = r.homepage { lines.append("Homepage: \(home)") }
        lines.append("Status: \(statusText(r.status))")
        copyText(lines.joined(separator: "\n"))
    }
    @objc func cmShopPrimary(_ s: NSMenuItem) {
        guard let items = s.representedObject as? [ShopItem], let first = items.first else { return }
        if first.installedPath == nil {
            for i in items { startShopInstall(i) }
        } else {
            NSWorkspace.shared.activateFileViewerSelecting(
                items.compactMap { $0.installedPath }.map { URL(fileURLWithPath: $0) })
        }
    }
    @objc func cmShopHomepage(_ s: NSMenuItem) {
        guard let i = s.representedObject as? ShopItem, let u = URL(string: i.cask.homepage) else { return }
        NSWorkspace.shared.open(u)
    }
    @objc func cmShopCopyName(_ s: NSMenuItem) {
        guard let i = s.representedObject as? ShopItem else { return }
        copyText(i.cask.names.first ?? i.cask.token)
    }
    @objc func cmShopCopyToken(_ s: NSMenuItem) {
        guard let i = s.representedObject as? ShopItem else { return }
        copyText(i.cask.token)
    }
    @objc func cmShopFavorite(_ s: NSMenuItem) {
        guard let i = s.representedObject as? ShopItem else { return }
        var favs = Prefs.shopFavorites
        let token = i.cask.token
        if favs.contains(token) { favs.removeAll { $0 == token } }
        else { favs.append(token) }
        Prefs.shopFavorites = favs
        shopTable.reloadData()
    }
    @objc func cmJobRetry(_ s: NSMenuItem) {
        guard let j = s.representedObject as? DownloadJob else { return }
        DownloadManager.shared.retry(j)
    }
    @objc func cmJobCancel(_ s: NSMenuItem) {
        guard let j = s.representedObject as? DownloadJob else { return }
        DownloadManager.shared.cancel(j)
    }
    @objc func cmJobReveal(_ s: NSMenuItem) {
        guard let j = s.representedObject as? DownloadJob, let u = j.localURL else { return }
        NSWorkspace.shared.activateFileViewerSelecting([u])
    }
    /// Compute the file's SHA-256 digest off the main thread and copy it.
    @objc func cmJobCopySHA(_ s: NSMenuItem) {
        guard let j = s.representedObject as? DownloadJob, let u = j.localURL,
              FileManager.default.fileExists(atPath: u.path) else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            let digest = Installer.sha256(of: u) ?? ""
            DispatchQueue.main.async {
                if digest.isEmpty {
                    let a = NSAlert()
                    a.messageText = "Could not compute SHA-256"
                    a.informativeText = u.lastPathComponent
                    a.addButton(withTitle: "OK"); a.runModal()
                } else {
                    self.copyText(digest)
                }
            }
        }
    }
    @objc func cmClearFinished(_ s: NSMenuItem) { DownloadManager.shared.clearFinished() }

    // MARK: Sorting

    func tableView(_ tableView: NSTableView, sortDescriptorsDidChange oldDescriptors: [NSSortDescriptor]) {
        guard let key = tableView.sortDescriptors.first?.key else { return }
        let asc = tableView.sortDescriptors.first?.ascending ?? true
        switch tableView.identifier?.rawValue {
        case "updates":
            UserDefaults.standard.set(key, forKey: Prefs.updatesSortKey)
            UserDefaults.standard.set(asc, forKey: Prefs.updatesSortAsc)
        case "installed":
            installedSortKey = key; installedSortAsc = asc
        case "shop":
            shopSortKey = key; shopSortAsc = asc
        default: break
        }
        tableView.reloadData()
    }
}

// MARK: - NSTableView data source / delegate

extension AppDelegate: NSTableViewDataSource, NSTableViewDelegate {

    func numberOfRows(in tableView: NSTableView) -> Int {
        switch tableView.identifier?.rawValue {
        case "updates": return filteredUpdates().count
        case "installed": return filteredInstalled().count
        case "shop": return filteredShop().count
        case "downloads": return DownloadManager.shared.jobs.count
        case "history": return HistoryStore.shared.displayed.count
        default: return 0
        }
    }

    func appCell(_ tableView: NSTableView, _ id: String, row: AppRow) -> NSTableCellView {
        let identifier = NSUserInterfaceItemIdentifier(id)
        let cell = tableView.makeView(withIdentifier: identifier, owner: nil) as? NSTableCellView ?? {
            let c = NSTableCellView()
            c.identifier = identifier
            let iv = NSImageView()
            iv.translatesAutoresizingMaskIntoConstraints = false
            let tf = NSTextField(labelWithString: "")
            tf.translatesAutoresizingMaskIntoConstraints = false
            tf.lineBreakMode = .byTruncatingTail
            c.addSubview(iv); c.addSubview(tf)
            c.imageView = iv; c.textField = tf
            NSLayoutConstraint.activate([
                iv.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 2),
                iv.centerYAnchor.constraint(equalTo: c.centerYAnchor),
                iv.widthAnchor.constraint(equalToConstant: 18),
                iv.heightAnchor.constraint(equalToConstant: 18),
                tf.leadingAnchor.constraint(equalTo: iv.trailingAnchor, constant: 6),
                tf.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -4),
                tf.centerYAnchor.constraint(equalTo: c.centerYAnchor)
            ])
            return c
        }()
        let icon = NSWorkspace.shared.icon(forFile: row.path)
        icon.size = NSSize(width: 18, height: 18)
        cell.imageView?.image = icon
        var label = row.name
        if row.isDuplicate { label += "  (duplicate)" }
        if row.ignored { label += "  (ignored)" }
        cell.textField?.stringValue = label
        if row.ignored {
            cell.textField?.textColor = .secondaryLabelColor
        } else if row.isDuplicate {
            cell.textField?.textColor = NSColor(calibratedRed: 0.83, green: 0.47, blue: 0.08, alpha: 1)
        } else {
            cell.textField?.textColor = .labelColor
        }
        cell.toolTip = row.path
        return cell
    }

    func textCell(_ tableView: NSTableView, _ id: String) -> NSTableCellView {
        let identifier = NSUserInterfaceItemIdentifier(id)
        if let c = tableView.makeView(withIdentifier: identifier, owner: nil) as? NSTableCellView { return c }
        let c = NSTableCellView()
        c.identifier = identifier
        let tf = NSTextField(labelWithString: "")
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.lineBreakMode = .byTruncatingTail
        c.addSubview(tf)
        c.textField = tf
        NSLayoutConstraint.activate([
            tf.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 2),
            tf.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -2),
            tf.centerYAnchor.constraint(equalTo: c.centerYAnchor)
        ])
        return c
    }

    func buttonCell(_ tableView: NSTableView, _ id: String, title: String,
                            tag: Int, action: Selector, enabled: Bool = true,
                            tint: NSColor? = nil) -> NSView {
        let identifier = NSUserInterfaceItemIdentifier(id)
        let b = (tableView.makeView(withIdentifier: identifier, owner: nil) as? NSButton) ?? {
            let b = NSButton()
            b.identifier = identifier
            b.bezelStyle = .rounded
            b.target = self
            b.translatesAutoresizingMaskIntoConstraints = false
            return b
        }()
        b.title = title
        b.tag = tag
        b.action = action
        b.isEnabled = enabled
        b.contentTintColor = tint
        let wrap = NSView()
        wrap.addSubview(b)
        NSLayoutConstraint.activate([
            b.centerYAnchor.constraint(equalTo: wrap.centerYAnchor),
            b.leadingAnchor.constraint(equalTo: wrap.leadingAnchor, constant: 2),
            b.trailingAnchor.constraint(lessThanOrEqualTo: wrap.trailingAnchor, constant: -2)
        ])
        return wrap
    }

    func progressCell(_ tableView: NSTableView, _ id: String, job: DownloadJob?,
                              fallback: String, fallbackColor: NSColor = .secondaryLabelColor) -> NSView {
        let identifier = NSUserInterfaceItemIdentifier(id)
        let c = tableView.makeView(withIdentifier: identifier, owner: nil) as? NSTableCellView ?? {
            let c = NSTableCellView()
            c.identifier = identifier
            let bar = NSProgressIndicator()
            bar.isIndeterminate = false
            bar.minValue = 0; bar.maxValue = 100
            bar.translatesAutoresizingMaskIntoConstraints = false
            bar.isHidden = true
            let tf = NSTextField(labelWithString: "")
            tf.translatesAutoresizingMaskIntoConstraints = false
            tf.lineBreakMode = .byTruncatingTail
            c.addSubview(bar); c.addSubview(tf)
            c.textField = tf
            bar.identifier = NSUserInterfaceItemIdentifier("bar")
            NSLayoutConstraint.activate([
                bar.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 2),
                bar.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -2),
                bar.centerYAnchor.constraint(equalTo: c.centerYAnchor),
                tf.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 2),
                tf.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -2),
                tf.centerYAnchor.constraint(equalTo: c.centerYAnchor)
            ])
            return c
        }()
        let bar = c.subviews.compactMap { $0 as? NSProgressIndicator }.first
        let tf = c.textField
        if let job = job, [.queued, .downloading, .extracting, .installing, .openingInstaller].contains(job.state) {
            bar?.isHidden = false
            tf?.isHidden = true
            if job.progress < 0 { bar?.isIndeterminate = true; bar?.startAnimation(nil) }
            else { bar?.isIndeterminate = false; bar?.doubleValue = job.progress * 100 }
        } else {
            bar?.isHidden = true
            bar?.stopAnimation(nil)
            tf?.isHidden = false
            tf?.stringValue = fallback
            tf?.textColor = fallbackColor
        }
        return c
    }

    /// Kind/Size cell: render the cached value instantly, "…" while unknown,
    /// and reload just this row when the off-main computation completes.
    func asyncMetaCell(_ tableView: NSTableView, _ id: String,
                       app: AppRow, isKind: Bool) -> NSTableCellView {
        let c = textCell(tableView, id)
        c.textField?.textColor = .secondaryLabelColor
        if isKind {
            if let v = BundleMetaCache.shared.cachedArchitecture(for: app.path) {
                c.textField?.stringValue = v
            } else {
                c.textField?.stringValue = "…"
                BundleMetaCache.shared.architecture(for: app.path) { [weak self] _ in
                    self?.reloadInstalledRow(path: app.path)
                }
            }
        } else {
            if let v = BundleMetaCache.shared.cachedSize(for: app.path) {
                c.textField?.stringValue = humanSize(v)
            } else {
                c.textField?.stringValue = "…"
                BundleMetaCache.shared.size(for: app.path) { [weak self] _ in
                    self?.reloadInstalledRow(path: app.path)
                }
            }
        }
        return c
    }

    func reloadInstalledRow(path: String) {
        let list = filteredInstalled()
        guard let r = list.firstIndex(where: { $0.path == path }) else { return }
        installedTable?.reloadData(forRowIndexes: IndexSet(integer: r),
                                   columnIndexes: IndexSet(integersIn: 1..<3))
    }

    // swiftlint:disable function_body_length
    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        guard let colID = tableColumn?.identifier.rawValue else { return nil }

        switch tableView.identifier?.rawValue {
        case "updates":
            let list = filteredUpdates()
            guard row < list.count else { return nil }
            let app = list[row]
            switch colID {
            case "app": return appCell(tableView, colID, row: app)
            case "change":
                let c = textCell(tableView, colID)
                c.textField?.stringValue = "\(app.installed.isEmpty ? "—" : app.installed)  →  \(app.latest ?? "—")"
                return c
            case "source":
                let c = textCell(tableView, colID)
                c.textField?.stringValue = app.source
                c.textField?.textColor = .secondaryLabelColor
                return c
            case "progress":
                let job = activeJob(for: directURL(for: app))
                let fallback: String
                if app.status == .update { fallback = app.appStoreURL != nil ? "Update in App Store" : "Ready to update" }
                else { fallback = statusText(app.status) }
                return progressCell(tableView, colID, job: job,
                                    fallback: fallback,
                                    fallbackColor: app.status == .update ? .systemOrange : .secondaryLabelColor)
            case "notes":
                let hasNotes = app.releaseNotesURL != nil || app.bestPageURL() != nil
                return buttonCell(tableView, colID, title: "Notes",
                                  tag: row, action: #selector(updatesNotes(_:)),
                                  enabled: hasNotes)
            case "action":
                let direct = directURL(for: app) != nil
                let store = app.appStoreURL != nil
                let running = activeJob(for: directURL(for: app)) != nil
                let title: String
                if running { title = "Working…" }
                else if direct { title = "Update" }
                else if store { title = "App Store" }
                else { title = "Open page" }
                return buttonCell(tableView, colID,
                                  title: title,
                                  tag: row, action: #selector(updatesAction(_:)),
                                  enabled: !running, tint: direct ? .systemOrange : nil)
            default: return nil
            }

        case "installed":
            let list = filteredInstalled()
            guard row < list.count else { return nil }
            let app = list[row]
            switch colID {
            case "app": return appCell(tableView, colID, row: app)
            case "kind":
                return asyncMetaCell(tableView, colID, app: app, isKind: true)
            case "size":
                return asyncMetaCell(tableView, colID, app: app, isKind: false)
            case "installed":
                let c = textCell(tableView, colID)
                c.textField?.stringValue = app.installed.isEmpty ? "—" : app.installed
                return c
            case "latest":
                let c = textCell(tableView, colID)
                c.textField?.stringValue = app.latest ?? "—"
                if app.status == .update { c.textField?.textColor = .systemOrange }
                return c
            case "source":
                let c = textCell(tableView, colID)
                c.textField?.stringValue = app.source
                c.textField?.textColor = .secondaryLabelColor
                return c
            case "status":
                let c = textCell(tableView, colID)
                let text: String
                let dup = app.isDuplicate ? " · duplicate" : ""
                switch app.status {
                case .update: text = "Update available" + dup; c.textField?.textColor = .systemOrange
                case .upToDate: text = "Up to date" + dup; c.textField?.textColor = .systemGreen
                case .pending: text = "Not checked" + dup; c.textField?.textColor = .secondaryLabelColor
                case .unknown: text = (app.note.isEmpty ? "No source" : app.note) + dup
                    c.textField?.textColor = .secondaryLabelColor
                }
                c.textField?.stringValue = text
                return c
            default: return nil
            }

        case "shop":
            let list = filteredShop()
            guard row < list.count else { return nil }
            let item = list[row]
            if colID == "app" {
                let identifier = NSUserInterfaceItemIdentifier(colID)
                let cell = tableView.makeView(withIdentifier: identifier, owner: nil) as? NSTableCellView ?? {
                    let c = NSTableCellView()
                    c.identifier = identifier
                    let iv = NSImageView()
                    iv.translatesAutoresizingMaskIntoConstraints = false
                    let name = NSTextField(labelWithString: "")
                    name.translatesAutoresizingMaskIntoConstraints = false
                    name.font = .systemFont(ofSize: 13, weight: .semibold)
                    name.lineBreakMode = .byTruncatingTail
                    let desc = NSTextField(labelWithString: "")
                    desc.translatesAutoresizingMaskIntoConstraints = false
                    desc.font = .systemFont(ofSize: 11)
                    desc.textColor = .secondaryLabelColor
                    desc.lineBreakMode = .byTruncatingTail
                    c.addSubview(iv); c.addSubview(name); c.addSubview(desc)
                    c.textField = name
                    c.imageView = iv
                    NSLayoutConstraint.activate([
                        iv.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 2),
                        iv.centerYAnchor.constraint(equalTo: c.centerYAnchor),
                        iv.widthAnchor.constraint(equalToConstant: 30),
                        iv.heightAnchor.constraint(equalToConstant: 30),
                        name.leadingAnchor.constraint(equalTo: iv.trailingAnchor, constant: 8),
                        name.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -4),
                        name.topAnchor.constraint(equalTo: c.topAnchor, constant: 5),
                        desc.leadingAnchor.constraint(equalTo: name.leadingAnchor),
                        desc.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -4),
                        desc.bottomAnchor.constraint(equalTo: c.bottomAnchor, constant: -5)
                    ])
                    return c
                }()
                let displayName = item.cask.names.first ?? item.cask.token
                let icon: NSImage
                if let p = item.installedPath, FileManager.default.fileExists(atPath: p) {
                    icon = NSWorkspace.shared.icon(forFile: p)
                } else if let t = item.cask.appTargets.first, FileManager.default.fileExists(atPath: t) {
                    icon = NSWorkspace.shared.icon(forFile: t)
                } else {
                    icon = ShopIconCache.shared.image(token: item.cask.token, displayName: displayName) { [weak self, weak tableView] _ in
                        DispatchQueue.main.async {
                            guard let self = self, let tableView = tableView else { return }
                            let list = self.filteredShop()
                            if let r = list.firstIndex(where: { $0.cask.token == item.cask.token }) {
                                tableView.reloadData(forRowIndexes: IndexSet(integer: r), columnIndexes: IndexSet(integer: 0))
                            }
                        }
                    }
                }
                icon.size = NSSize(width: 30, height: 30)
                cell.imageView?.image = icon
                let labels = cell.subviews.compactMap { $0 as? NSTextField }
                labels.first?.stringValue = displayName
                labels.last?.stringValue = item.cask.desc
                return cell
            }
            if colID == "category" {
                let c = textCell(tableView, colID); c.textField?.stringValue = item.category
                c.textField?.textColor = .secondaryLabelColor; return c
            }
            if colID == "version" {
                let c = textCell(tableView, colID)
                let shown = item.cask.marketingVersion
                c.textField?.stringValue = shown == "latest" ? "—" : shown
                return c
            }
            if colID == "minos" {
                let c = textCell(tableView, colID)
                c.textField?.stringValue = item.cask.minOS ?? "—"
                c.textField?.textColor = .secondaryLabelColor
                return c
            }
            if colID == "status" {
                let c = textCell(tableView, colID)
                let running = DownloadManager.shared.jobs.contains {
                    $0.title == (item.cask.names.first ?? item.cask.token)
                        && [.queued, .downloading, .extracting, .installing, .openingInstaller].contains($0.state)
                }
                c.textField?.stringValue = running ? "Installing…" : (item.installedPath != nil ? "Installed" : "Free")
                c.textField?.textColor = item.installedPath != nil ? .systemGreen : .secondaryLabelColor
                return c
            }
            if colID == "action" {
                let running = DownloadManager.shared.jobs.contains {
                    $0.title == (item.cask.names.first ?? item.cask.token)
                        && [.queued, .downloading, .extracting, .installing, .openingInstaller].contains($0.state)
                }
                return buttonCell(tableView, colID,
                                  title: running ? "Working…" : (item.installedPath != nil ? "Reveal" : "Install"),
                                  tag: row, action: #selector(shopAction(_:)), enabled: !running)
            }
            return nil

        case "downloads":
            let jobs = DownloadManager.shared.jobs
            guard row < jobs.count else { return nil }
            let job = jobs[row]
            switch colID {
            case "app":
                let identifier = NSUserInterfaceItemIdentifier(colID)
                let c = tableView.makeView(withIdentifier: identifier, owner: nil) as? NSTableCellView ?? {
                    let c = NSTableCellView()
                    c.identifier = identifier
                    let iv = NSImageView()
                    iv.translatesAutoresizingMaskIntoConstraints = false
                    let tf = NSTextField(labelWithString: "")
                    tf.translatesAutoresizingMaskIntoConstraints = false
                    tf.lineBreakMode = .byTruncatingTail
                    c.addSubview(iv); c.addSubview(tf)
                    c.imageView = iv; c.textField = tf
                    NSLayoutConstraint.activate([
                        iv.leadingAnchor.constraint(equalTo: c.leadingAnchor, constant: 2),
                        iv.centerYAnchor.constraint(equalTo: c.centerYAnchor),
                        iv.widthAnchor.constraint(equalToConstant: 18),
                        iv.heightAnchor.constraint(equalToConstant: 18),
                        tf.leadingAnchor.constraint(equalTo: iv.trailingAnchor, constant: 6),
                        tf.trailingAnchor.constraint(equalTo: c.trailingAnchor, constant: -4),
                        tf.centerYAnchor.constraint(equalTo: c.centerYAnchor)
                    ])
                    return c
                }()
                c.textField?.stringValue = job.title
                c.textField?.font = .systemFont(ofSize: 13, weight: .medium)
                let icon: NSImage
                if let p = job.existingPath, FileManager.default.fileExists(atPath: p) {
                    icon = NSWorkspace.shared.icon(forFile: p)
                } else if let t = job.expectedTarget, FileManager.default.fileExists(atPath: t) {
                    icon = NSWorkspace.shared.icon(forFile: t)
                } else if let u = job.localURL {
                    icon = NSWorkspace.shared.icon(forFile: u.path)
                } else {
                    icon = NSImage(systemSymbolName: "tray.and.arrow.down",
                                   accessibilityDescription: nil) ?? NSImage()
                }
                icon.size = NSSize(width: 18, height: 18)
                c.imageView?.image = icon
                return c
            case "kind":
                let c = textCell(tableView, colID); c.textField?.stringValue = job.kind
                c.textField?.textColor = .secondaryLabelColor; return c
            case "state":
                let c = textCell(tableView, colID); c.textField?.stringValue = job.state.text
                switch job.state {
                case .done: c.textField?.textColor = .systemGreen
                case .failed: c.textField?.textColor = .systemRed
                case .canceled: c.textField?.textColor = .secondaryLabelColor
                default: c.textField?.textColor = .controlAccentColor
                }
                return c
            case "progress":
                return progressCell(tableView, colID, job:
                    [.queued, .downloading, .extracting, .installing, .openingInstaller].contains(job.state) ? job : nil,
                    fallback: job.state == .done ? "100%" : "—")
            case "message":
                let c = textCell(tableView, colID); c.textField?.stringValue = job.message
                c.textField?.textColor = job.state == .failed ? .systemRed : .secondaryLabelColor
                return c
            case "action":
                let title: String
                let enabled: Bool
                switch job.state {
                case .queued: title = "Cancel"; enabled = true
                case .downloading: title = "Pause"; enabled = true
                case .paused: title = "Resume"; enabled = true
                case .extracting, .installing: title = "Working…"; enabled = false
                case .openingInstaller: title = "Reveal"; enabled = job.localURL != nil
                case .done: title = job.installedURL != nil ? "Open App" : "Reveal"; enabled = true
                case .failed: title = "Retry"; enabled = true
                case .canceled: title = job.localURL != nil ? "Reveal" : "Retry"; enabled = true
                }
                return buttonCell(tableView, colID, title: title, tag: row,
                                  action: #selector(downloadsAction(_:)), enabled: enabled)
            default: return nil
            }

        case "history":
            let list = HistoryStore.shared.displayed
            guard row < list.count else { return nil }
            let event = list[row]
            switch colID {
            case "date":
                let c = textCell(tableView, colID)
                let f = DateFormatter()
                f.dateStyle = .medium; f.timeStyle = .short
                c.textField?.stringValue = f.string(from: event.date)
                c.textField?.textColor = .secondaryLabelColor
                return c
            case "app":
                let c = textCell(tableView, colID)
                c.textField?.stringValue = event.appName
                c.textField?.font = .systemFont(ofSize: 13, weight: .medium)
                return c
            case "change":
                let c = textCell(tableView, colID)
                c.textField?.stringValue = event.kind.text
                    + (event.fromVersion.isEmpty ? "" : "  \(event.fromVersion) → \(event.toVersion)")
                return c
            case "detail":
                let c = textCell(tableView, colID)
                c.textField?.stringValue = event.detail
                c.textField?.textColor = event.kind == .failed ? .systemRed : .secondaryLabelColor
                return c
            case "action":
                let canRollback = event.kind == .updated
                    && event.rollbackPath != nil
                    && FileManager.default.fileExists(atPath: event.rollbackPath ?? "")
                return buttonCell(tableView, colID,
                                  title: canRollback ? "Roll back" : "—",
                                  tag: row, action: #selector(historyAction(_:)),
                                  enabled: canRollback)
            default: return nil
            }
        default:
            return nil
        }
    }
}

// Safe subscript helper
extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
