// main.swift — entry point + headless/self-test modes
import Cocoa

setbuf(stdout, nil)

let appDelegate = AppDelegate()

struct DiagnosticsResult { let failed: Int; let lines: [String] }

func runDiagnostics() -> DiagnosticsResult {
    var lines: [String] = []
    var fail = 0
    func check(_ cond: Bool, _ label: String) {
        if cond { lines.append("PASS  \(label)") }
        else { fail += 1; lines.append("FAIL  \(label)") }
    }
    func note(_ label: String) { lines.append("INFO  \(label)") }
    func warn(_ label: String) { lines.append("WARN  \(label)") }
    check(compareVersions("1.0", "1.0.0") == .orderedSame, "same")
    check(compareVersions("2.0", "1.9.9") == .orderedDescending, "major")
    check(compareVersions("1.2.3", "1.2.4") == .orderedAscending, "patch")
    check(compareVersions("1.2beta", "1.2") == .orderedAscending, "suffix lower")
    check(compareVersions("10.0", "9.9.9") == .orderedDescending, "numeric not lexicographic")
    check(compareVersions("1.2.3-beta2", "1.2.3-beta1") == .orderedDescending, "suffix compare")
    check(compareVersions("3.5.0", "3.6.1") == .orderedAscending, "version ordering")
    check(normalizeName("Google Chrome") == "googlechrome", "name normalize")
    check(normalizeName("‎WhatsApp") == "whatsapp", "strip unicode marks")

    // build-number suffixes must not be reported as updates forever
    check(isBuildNumberEquivalent(installed: "9.5.1", latest: "9.5.1.2.4"), "build suffix equivalent (9.5.1.2.4)")
    check(isBuildNumberEquivalent(installed: "9.4.1", latest: "9.4.1.4574"), "build suffix equivalent (capcut)")
    check(isBuildNumberEquivalent(installed: "16.113", latest: "16.113.26091433"), "build suffix equivalent (office)")
    check(!isBuildNumberEquivalent(installed: "1.0", latest: "1.0.1"), "real patch release not equivalent")
    check(!isBuildNumberEquivalent(installed: "9.5.1", latest: "9.5.2.4"), "changed component not equivalent")
    check(!isBuildNumberEquivalent(installed: "1.0.0", latest: "1.0.0.1beta"), "beta suffix not a build number")
    check(isBuildNumberEquivalent(installed: "2.6", latest: "2.6.1234"), "2-part version + long build equivalent")
    check(!isBuildNumberEquivalent(installed: "16.113", latest: "16.114.26091433"), "changed 2-part prefix not equivalent")
    check(!isBuildNumberEquivalent(installed: "2.6", latest: "2.6.1"), "2-part short tail is a patch")
    check(!isUpdateAvailable(installed: "9.5.1", latest: "9.5.1.2.4"), "no update loop for build suffix")
    check(isUpdateAvailable(installed: "1.0", latest: "1.0.1"), "patch update still detected")
    check(isUpdateAvailable(installed: "2.1", latest: "2.2.0"), "minor update detected")
    check(!isUpdateAvailable(installed: "3.0", latest: "3.0"), "same version is no update")

    // pre-release builds are never pushed to stable users
    check(isPrereleaseVersion("2.8-rc.2"), "2.8-rc.2 detected as pre-release")
    check(isPrereleaseVersion("1.2b3"), "1.2b3 detected as pre-release")
    check(isPrereleaseVersion("0.12.0-beta.5"), "beta detected as pre-release")
    check(isPrereleaseVersion("1.0-alpha1"), "alpha detected as pre-release")
    check(!isPrereleaseVersion("2.7.3"), "2.7.3 is stable")
    check(!isPrereleaseVersion("1.0.0"), "1.0.0 is stable")
    check(!isUpdateAvailable(installed: "2.7.3", latest: "2.8-rc.2"), "stable user not pushed an rc")
    check(!isUpdateAvailable(installed: "1.0", latest: "1.1-beta1"), "stable user not pushed a beta")
    check(isUpdateAvailable(installed: "0.12.0-beta.5", latest: "0.13.0-beta.4"), "beta channel user gets newer beta")

    // placeholder versions (self-updating apps) never trigger updates
    check(isPlaceholderInstalledVersion("0.0.0"), "0.0.0 is placeholder")
    check(isPlaceholderInstalledVersion("0.0.0.1"), "0.0.0.1 is placeholder")
    check(!isPlaceholderInstalledVersion("0.5.1"), "0.5.1 is a real version")
    check(!isPlaceholderInstalledVersion("1.0.0"), "1.0.0 is a real version")
    check(!isUpdateAvailable(installed: "0.0.0.1", latest: "0.743.0.7431133"), "placeholder version never updates")

    // The scan path (finalizeStatus -> updateIsAvailable) must enforce the same
    // gates as the headless comparison. These guard against the fake-update
    // regressions (Roblox Studio 0.0.0.1, TheBoringNotch rc) coming back.
    func scanRow(_ installed: String, _ latest: String?, bid: String = "com.test.row") -> AppRow {
        AppRow(name: "Test", bundleID: bid, installed: installed, path: "/tmp/Test.app",
               feedURL: nil, homepage: nil, downloadURL: nil, releaseNotesURL: nil,
               latest: latest, source: "Homebrew", note: "", status: .pending)
    }
    check(!updateIsAvailable(scanRow("0.0.0.1", "0.743.0.7431133")), "scan: placeholder never updates")
    check(!updateIsAvailable(scanRow("2.7.3", "2.8-rc.2")), "scan: stable user not pushed an rc")
    check(!updateIsAvailable(scanRow("1.0", "1.1-beta1")), "scan: stable user not pushed a beta")
    check(updateIsAvailable(scanRow("0.12.0-beta.5", "0.13.0-beta.4")), "scan: beta user gets newer beta")
    check(updateIsAvailable(scanRow("2.31.4", "2.32.6")), "scan: normal patch update offered")
    check(!updateIsAvailable(scanRow("155.0.8059.85", "155.0.8059.40")), "scan: older cask never downgrades")
    check(!updateIsAvailable(scanRow("9.5.1", "9.5.1.2.4")), "scan: build suffix not an update")
    check(!updateIsAvailable(scanRow("1.0", nil)), "scan: no latest means no update")

    // silent PKG admin AppleScript escaping
    let pkgScript = Installer.pkgAdminScript(path: "/tmp/My Package.pkg")
    check(pkgScript == "do shell script \"/usr/sbin/installer -pkg \\\"/tmp/My Package.pkg\\\" -target /\" with administrator privileges",
          "pkg admin script shape")
    check(Installer.pkgAdminScript(path: "/tmp/a\"b.pkg").contains("a\\\"b.pkg"), "pkg script escapes quotes")
    check(Installer.pkgAdminScript(path: "/tmp/a\\b.pkg").contains("a\\\\b.pkg"), "pkg script escapes backslashes")

    // shop icon monogram fallback
    let monogram = ShopIconCache.shared.monogram(name: "VLC media player", token: "vlc")
    check(monogram.isValid && monogram.size.width > 0 && monogram.size.height > 0, "shop monogram icon generated")

    // cask parsing + arch URL resolution
    let vlc: [String: Any] = [
        "token": "vlc", "name": ["VLC media player"], "version": "3.0.23",
        "url": "https://get.videolan.org/vlc/3.0.23/macosx/vlc-3.0.23-arm64.dmg",
        "artifacts": [["app": ["VLC.app"], "target": "/Applications/VLC.app"]],
        "variations": [
            "sequoia": ["url": "https://get.videolan.org/vlc/3.0.23/macosx/vlc-3.0.23-intel64.dmg"]
        ]
    ]
    if let cask = parseCask(vlc) {
        check(cask.appArtifacts == ["VLC.app"], "artifact parse")
        check(cask.appTargets == ["/Applications/VLC.app"], "target parse")
        if Arch.isIntel {
            check(cask.url.contains("intel64"), "intel picks intel url (got \(cask.url))")
        } else {
            check(cask.url.contains("arm64"), "arm picks arm url (got \(cask.url))")
        }
    } else {
        check(false, "cask parse")
    }

    // "linearmouse" must not be misread as an ARM build
    let linearMouse: [String: Any] = [
        "token": "linearmouse", "name": ["LinearMouse"], "version": "0.12.0",
        "url": "https://dl.linearmouse.org/v0.12.0/LinearMouse.dmg"
    ]
    if let c = parseCask(linearMouse) {
        check(c.url.contains("LinearMouse.dmg"), "linearmouse not flagged as arm (got \(c.url))")
    } else { check(false, "linearmouse parse") }

    // arm-only default with an unmarked (universal) macOS variant
    let spotify: [String: Any] = [
        "token": "spotify", "name": ["Spotify"], "version": "1.0",
        "url": "https://download.scdn.co/SpotifyARM64.dmg",
        "variations": ["sequoia": ["url": "https://download.scdn.co/Spotify.dmg"]]
    ]
    if let c = parseCask(spotify) {
        if Arch.isIntel {
            check(c.url == "https://download.scdn.co/Spotify.dmg",
                  "intel falls back to universal variant (got \(c.url))")
        } else {
            check(c.url.contains("ARM64"), "arm keeps arm default (got \(c.url))")
        }
    } else { check(false, "spotify parse") }

    // direct-installer URL detection (including redirect endpoints)
    check(isDirectInstallerURL("https://x.test/App.dmg"), "direct dmg")
    check(isDirectInstallerURL("https://web.whatsapp.com/release/?extension=zip&x=1"), "whatsapp redirect")
    check(isDirectInstallerURL("https://app.warp.dev/download?package=dmg"), "warp redirect")
    check(isDirectInstallerURL("https://update.code.visualstudio.com/1.0/darwin/stable"), "vscode intel redirect")
    check(isDirectInstallerURL("https://handbrake.fr/rotation.php?file=HandBrake.dmg&update=true"), "handbrake redirect")
    check(isDirectInstallerURL("https://portswigger-cdn.net/burp/releases/download?product=desktop&version=1&type=MacOsx"), "burp type redirect")
    check(isDirectInstallerURL("https://dl.pstmn.io/download/version/1/osx64"), "postman redirect")
    check(!isDirectInstallerURL("https://example.com/page"), "plain web page rejected")
    check(!isDirectInstallerURL("https://downloads.vivaldi.com/Vivaldi.universal.tar.xz"), "tar.xz rejected")

    // Electron app-update.yml parsing
    let yml = """
    provider: github
    owner: some-org
    repo: CoolApp
    releases:
      url: ignored
    """
    check(parseElectronUpdateYML(yml.data(using: .utf8)!) == "some-org/CoolApp", "electron yml github parse")
    check(parseElectronUpdateYML("provider: generic\nurl: https://x\n".data(using: .utf8)!) == nil,
          "electron yml generic ignored")

    // GitHub release asset selection
    let gh1 = pickGitHubAssetName([
        ("CoolApp-1.2-arm64.dmg", "https://x/arm.dmg"),
        ("CoolApp-1.2-x64.dmg", "https://x/x64.dmg"),
        ("CoolApp-1.2-x64.dmg.blockmap", "https://x/x64.dmg.blockmap"),
        ("latest-linux.yml", "https://x/linux.yml")
    ])
    check(gh1 == "https://x/x64.dmg", "github picks intel dmg (got \(gh1 ?? "nil"))")
    let gh2 = pickGitHubAssetName([
        ("CoolApp-1.2-mac.zip", "https://x/mac.zip"),
        ("CoolApp-1.2-win.zip", "https://x/win.zip")
    ])
    check(gh2 == "https://x/mac.zip", "github picks unmarked mac zip (got \(gh2 ?? "nil"))")

    // App Store URL + CSV
    check(macAppStoreURL(trackID: 123) == "macappstore://apps.apple.com/app/id123?mt=12", "app store url")
    check(csvEscape("a,b") == "\"a,b\"", "csv escape comma")
    check(csvRows([AppRow(name: "X", bundleID: "b.x", installed: "1", path: "/Applications/X.app",
                          feedURL: nil, homepage: nil, downloadURL: nil, releaseNotesURL: nil,
                          latest: nil, source: "—", note: "", status: .unknown)])
            .contains("X,b.x,1,"), "csv row content")

    // installer pipeline: build a fake app, zip it, run the ZIP installer into a temp target
    do {
        let tmp = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("mu-selftest-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: tmp, withIntermediateDirectories: true)
        let fake = tmp.appendingPathComponent("Fake.app")
        try FileManager.default.createDirectory(at: fake.appendingPathComponent("Contents/MacOS"),
                                                withIntermediateDirectories: true)
        let plist = """
        <?xml version="1.0" encoding="UTF-8"?>
        <plist version="1.0"><dict><key>CFBundleIdentifier</key><string>com.test.fake</string>
        <key>CFBundleName</key><string>Fake</string><key>CFBundleExecutable</key><string>Fake</string>
        <key>CFBundleShortVersionString</key><string>1.0</string>
        <key>CFBundlePackageType</key><string>APPL</string></dict></plist>
        """
        try plist.write(to: fake.appendingPathComponent("Contents/Info.plist"), atomically: true, encoding: .utf8)
        try "#!/bin/sh\necho hi\n".write(to: fake.appendingPathComponent("Contents/MacOS/Fake"),
                                        atomically: true, encoding: .utf8)
        let zip = tmp.appendingPathComponent("Fake.zip")
        let zipResult = Installer.runProc("/usr/bin/ditto",
                                          ["-c", "-k", "--keepParent", fake.path, zip.path])
        check(zipResult.code == 0, "create test zip")

        let job = DownloadJob(title: "Fake", kind: "Install", url: zip, relaunch: false)
        job.expectedAppName = "Fake.app"
        // point destination at temp "Applications" by using expectedTarget
        let fakeApps = tmp.appendingPathComponent("Applications")
        try FileManager.default.createDirectory(at: fakeApps, withIntermediateDirectories: true)
        job.expectedTarget = fakeApps.appendingPathComponent("Fake.app").path
        let result = Installer.installZIP(zip, job: job)
        var installedURL: URL?
        if case .installed(let url, _) = result {
            installedURL = url
            check(url.lastPathComponent == "Fake.app", "zip install pipeline -> \(url.path)")
            check(FileManager.default.fileExists(atPath: url.appendingPathComponent("Contents/MacOS/Fake").path),
                  "installed app contents present")
        } else {
            check(false, "zip install pipeline result: \(result)")
        }

        // Upgrade: a 2.0 build must replace the 1.0 build with no .old leftovers
        if let installedURL = installedURL {
            let fake2 = tmp.appendingPathComponent("Fake2.app")
            try FileManager.default.createDirectory(at: fake2.appendingPathComponent("Contents/MacOS"),
                                                    withIntermediateDirectories: true)
            let plist2 = """
            <?xml version="1.0" encoding="UTF-8"?>
            <plist version="1.0"><dict><key>CFBundleIdentifier</key><string>com.test.fake</string>
            <key>CFBundleName</key><string>Fake</string><key>CFBundleExecutable</key><string>Fake</string>
            <key>CFBundleShortVersionString</key><string>2.0</string>
            <key>CFBundlePackageType</key><string>APPL</string></dict></plist>
            """
            try plist2.write(to: fake2.appendingPathComponent("Contents/Info.plist"), atomically: true, encoding: .utf8)
            try "#!/bin/sh\necho v2\n".write(to: fake2.appendingPathComponent("Contents/MacOS/Fake"),
                                             atomically: true, encoding: .utf8)
            let zip2 = tmp.appendingPathComponent("Fake2.zip")
            _ = Installer.runProc("/usr/bin/ditto", ["-c", "-k", "--keepParent", fake2.path, zip2.path])
            let job2 = DownloadJob(title: "Fake", kind: "Update", url: zip2, relaunch: false)
            job2.expectedAppName = "Fake.app"
            job2.existingPath = installedURL.path
            job2.expectedTarget = installedURL.path
            let result2 = Installer.installZIP(zip2, job: job2)
            if case .installed(let url2, let rollback) = result2 {
                let v = installedVersion(at: url2)
                check(v == "2.0", "upgrade replaces old build (got \(v ?? "nil"))")
                let leftovers = (try? FileManager.default.contentsOfDirectory(atPath: fakeApps.path))?
                    .filter { $0.contains(".old-") } ?? []
                check(leftovers.isEmpty, "no .old leftovers after upgrade (found \(leftovers))")
                // The previous build is retained for one-click rollback.
                if let rb = rollback {
                    let rv = installedVersion(at: rb)
                    check(rv == "1.0", "old build retained for rollback at 1.0 (got \(rv ?? "nil"))")
                } else {
                    // Retention disabled ("keep forever" aside) — then it must be trashed.
                    let trashItems = (try? FileManager.default.contentsOfDirectory(
                        at: FileManager.default.urls(for: .trashDirectory, in: .userDomainMask).first!,
                        includingPropertiesForKeys: nil)) ?? []
                    let trashed = trashItems.contains { $0.lastPathComponent.hasPrefix("Fake") && $0.pathExtension == "app" }
                    check(trashed, "old build moved to Trash when rollback retention is off")
                }
            } else {
                check(false, "upgrade pipeline result: \(result2)")
            }
        }
        try? FileManager.default.removeItem(at: tmp)
    } catch {
        check(false, "installer test setup: \(error)")
    }

    // DownloadManager: two concurrent installs via file:// URLs + retry path
    do {
        let tmp = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("mu-dm-\(UUID().uuidString)")
        let apps = tmp.appendingPathComponent("Applications")
        try FileManager.default.createDirectory(at: apps, withIntermediateDirectories: true)
        UserDefaults.standard.set(3, forKey: Prefs.maxConcurrent)
        func makeApp(_ name: String, id: String, version: String) throws -> URL {
            let app = tmp.appendingPathComponent("\(name).app")
            try FileManager.default.createDirectory(at: app.appendingPathComponent("Contents/MacOS"),
                                                    withIntermediateDirectories: true)
            let plist = """
            <?xml version="1.0" encoding="UTF-8"?>
            <plist version="1.0"><dict><key>CFBundleIdentifier</key><string>\(id)</string>
            <key>CFBundleName</key><string>\(name)</string><key>CFBundleExecutable</key><string>\(name)</string>
            <key>CFBundleShortVersionString</key><string>\(version)</string>
            <key>CFBundlePackageType</key><string>APPL</string></dict></plist>
            """
            try plist.write(to: app.appendingPathComponent("Contents/Info.plist"), atomically: true, encoding: .utf8)
            let zip = tmp.appendingPathComponent("\(name).zip")
            _ = Installer.runProc("/usr/bin/ditto", ["-c", "-k", "--keepParent", app.path, zip.path])
            try FileManager.default.removeItem(at: app)
            return zip
        }
        let zipA = try makeApp("Alpha", id: "com.test.alpha", version: "1.0")
        let zipB = try makeApp("Beta", id: "com.test.beta", version: "2.0")
        func jobFor(_ zip: URL, name: String) -> DownloadJob {
            let job = DownloadJob(title: name, kind: "Install", url: zip, relaunch: false)
            job.expectedAppName = "\(name).app"
            job.expectedTarget = apps.appendingPathComponent("\(name).app").path
            return job
        }
        let jA = jobFor(zipA, name: "Alpha")
        let jB = jobFor(zipB, name: "Beta")
        let dm = DownloadManager.shared
        let before = dm.jobs.count
        dm.enqueue(jA); dm.enqueue(jB)
        let deadline = Date().addingTimeInterval(40)
        while Date() < deadline {
            RunLoop.current.run(mode: .default, before: Date().addingTimeInterval(0.2))
            if [jA.state, jB.state].allSatisfy({ $0 == .done || $0 == .failed }) { break }
        }
        check(jA.state == .done && jB.state == .done,
              "parallel downloads both finish (A=\(jA.state) B=\(jB.state) \(jA.message) \(jB.message))")
        check(FileManager.default.fileExists(atPath: apps.appendingPathComponent("Alpha.app/Contents/Info.plist").path)
              && FileManager.default.fileExists(atPath: apps.appendingPathComponent("Beta.app/Contents/Info.plist").path),
              "parallel installs land in distinct targets")

        // Retry path: a missing file fails, then retry re-queues and fails again cleanly
        let bad = DownloadJob(title: "Ghost", kind: "Install",
                              url: tmp.appendingPathComponent("does-not-exist.zip"), relaunch: false)
        bad.expectedAppName = "Ghost.app"
        dm.enqueue(bad)
        let d2 = Date().addingTimeInterval(20)
        while Date() < d2 {
            RunLoop.current.run(mode: .default, before: Date().addingTimeInterval(0.2))
            if bad.state == .failed { break }
        }
        check(bad.state == .failed, "bad download fails cleanly (got \(bad.state))")
        dm.retry(bad)
        RunLoop.current.run(mode: .default, before: Date().addingTimeInterval(0.5))
        check(bad.state == .queued || bad.state == .downloading || bad.state == .failed,
              "retry re-queues a failed job")
        let d3 = Date().addingTimeInterval(20)
        while Date() < d3 {
            RunLoop.current.run(mode: .default, before: Date().addingTimeInterval(0.2))
            if bad.state == .failed { break }
        }
        check(bad.state == .failed, "retried bad download fails again without hanging")
        _ = before
        try? FileManager.default.removeItem(at: tmp)
    } catch {
        check(false, "download manager test setup: \(error)")
    }

    // 3.6.4 — natural ordering inside prerelease suffixes
    check(naturalCompare("beta10", "beta9") == .orderedDescending, "natural compare beta10 > beta9")
    check(compareVersions("1.0-beta10", "1.0-beta9") == .orderedDescending, "beta10 newer than beta9 via compareVersions")
    check(compareVersions("1.0-rc.2", "1.0-rc.10") == .orderedAscending, "rc.10 newer than rc.2")
    check(compareVersions("", "1.0") == .orderedAscending, "empty version sorts first")
    check(compareVersions("  ", " ") == .orderedSame, "whitespace versions equal")

    // 3.6.4 — cask comma versions expose the marketing version only
    let commaCask: [String: Any] = [
        "token": "comma-app", "name": ["Comma App"], "version": "4.2.1,20260531.1",
        "url": "https://x.test/App.dmg"
    ]
    if let c = parseCask(commaCask) {
        check(c.marketingVersion == "4.2.1", "marketing version from comma version (got \(c.marketingVersion))")
    } else { check(false, "comma cask parse") }

    // 3.6.4 — diacritics fold instead of disappearing
    check(normalizeName("Café") == "cafe", "normalize folds accents (got \(normalizeName("Café")))")
    check(normalizeName("ÜberEdit") == "uberedit", "normalize folds umlaut")

    // 3.6.4 — title version extraction prefers the number after "Version"
    check(extractVersionFromTitle("Build 2024.1 — Version 2.3") == "2.3",
          "title picks version after 'Version' (got \(extractVersionFromTitle("Build 2024.1 — Version 2.3") ?? "nil"))")
    check(extractVersionFromTitle("CoolApp 1.4.2 download") == "1.4.2", "title plain version")

    // 3.6.4 — monogram fallback never fails on non-letter input
    let mono = ShopIconCache.shared.monogram(name: "!!!", token: "")
    check(mono.isValid && mono.size.width > 0, "monogram fallback for non-letters")

    // 3.6.4 — reports and changelog exist
    appDelegate.rows = [AppRow(name: "X", bundleID: "b.x", installed: "1", path: "/Applications/X.app",
                               feedURL: nil, homepage: nil, downloadURL: nil, releaseNotesURL: nil,
                               latest: nil, source: "—", note: "", status: .unknown)]
    check(appDelegate.jsonReport().contains("\"name\""), "json report shape")
    check(appDelegate.htmlReport().contains("<table"), "html report shape")
    check(!appDelegate.changelogText().isEmpty, "changelog text present")
    check(!appDelegate.humanSize(2_048).isEmpty, "human size formatter")

    // 3.6.4 — changelog first-launch preference round trip
    UserDefaults.standard.set("3.6.3", forKey: Prefs.seenVersion)
    check(UserDefaults.standard.string(forKey: Prefs.seenVersion) == "3.6.3", "seen version pref round trip")

    // 3.6.5 — strict version normalization
    check(normalizeVersion("v1.63") == "1.63", "leading v stripped (got \(normalizeVersion("v1.63")))")
    check(normalizeVersion("V2.0") == "2.0", "leading V stripped")
    check(normalizeVersion("version 3.1") == "3.1", "'version ' prefix stripped")
    check(normalizeVersion("(1.2.3)") == "1.2.3", "wrapping parentheses peeled")
    check(normalizeVersion("[4.5]") == "4.5", "wrapping brackets peeled")
    check(normalizeVersion("1_2_3") == "1.2.3", "underscores become dots")
    check(normalizeVersion("1.0 beta 2") == "1.0beta2", "internal spaces removed")
    check(normalizeVersion("vapp") == "vapp", "v not stripped before letters")

    // 3.6.5 — the reported bug: v1.63 vs 1.63 must be equal, not an update
    check(compareVersions("v1.63", "1.63") == .orderedSame, "v1.63 equals 1.63")
    var vdupRow = AppRow(name: "T", bundleID: "b.t", installed: "v1.63",
                         path: "/Applications/T.app", feedURL: nil, homepage: nil,
                         downloadURL: nil, releaseNotesURL: nil, latest: "1.63",
                         source: "Test", note: "", status: .unknown)
    finalizeStatus(&vdupRow)
    check(vdupRow.status != .update, "v1.63 -> 1.63 is not an update (got \(statusText(vdupRow.status)))")

    // 3.6.5 — plausibility gate
    check(isPlausibleVersion("1.0"), "1.0 plausible")
    check(!isPlausibleVersion("latest"), "'latest' is not a version")
    check(!isPlausibleVersion("https://example.com/x"), "a URL is not a version")
    check(!isPlausibleVersion("abc"), "letters-only is not a version")

    // 3.6.5 — strict prerelease ordering
    check(compareVersions("1.0-beta", "1.0") == .orderedAscending, "beta < release")
    check(compareVersions("1.0-alpha", "1.0-beta") == .orderedAscending, "alpha < beta")
    check(compareVersions("1.0-rc1", "1.0-beta9") == .orderedDescending, "rc > beta")
    check(compareVersions("1.0-BETA2", "1.0-beta1") == .orderedDescending, "case-insensitive beta")

    // 3.6.5 — duplicate bundle detection
    let dc1 = AppRow(name: "WhatsApp", bundleID: "net.whatsapp", installed: "1",
                     path: "/Applications/WhatsApp.app", feedURL: nil, homepage: nil,
                     downloadURL: nil, releaseNotesURL: nil, latest: nil, source: "-",
                     note: "", status: .unknown)
    var dc2 = dc1; dc2.path = "/Users/x/Desktop/WhatsApp.app"
    let dupSet = duplicateBundleIDs([dc1, dc2])
    check(dupSet.contains("net.whatsapp"), "duplicate bundle id detected")
    check(duplicateBundleIDs([dc1]).isEmpty, "a single copy is not a duplicate")

    // 3.6.5 — relative time text
    check(!appDelegate.relativeTimeText(Date().addingTimeInterval(-120)).isEmpty,
          "relative last-checked text is produced")

    // 3.6.5 — CSV duplicate column
    var flagged = dc1; flagged.isDuplicate = true
    let csvOut = csvRows([flagged])
    let csvHeader = csvOut.split(separator: "\n", maxSplits: 1).first ?? ""
    check(csvHeader.contains("Duplicate"), "csv header has a Duplicate column")
    check(csvOut.contains("Yes"), "csv row flags the duplicate copy")

    // 3.6.0 — OS version parsing
    let p1 = parseOSVersion("18.0")
    check(p1?.0 == 18 && p1?.1 == 0 && p1?.2 == 0, "parse os version 18.0")
    let p2 = parseOSVersion("10.11.6")
    check(p2?.0 == 10 && p2?.1 == 11 && p2?.2 == 6, "parse os version 10.11.6")
    check(parseOSVersion("garbage") == nil, "garbage os version is nil")
    check(isOSVersionAtLeast("10.15"), "current os satisfies 10.15")
    check(!isOSVersionAtLeast("99.0"), "current os does not satisfy 99.0")
    check(isOSVersionAtLeast("??"), "unknown os requirement treated as satisfied")
    check(caskMacOSRequirement(["macos": [">= :ventura"]]) == "13.0.0",
          "cask symbol macos requirement (got \(caskMacOSRequirement(["macos": [">= :ventura"]]) ?? "nil"))")
    check(caskMacOSRequirement(["macos": [">= 14.0"]]) == "14.0.0", "cask numeric macos requirement")
    check(caskMacOSRequirement([:]) == nil, "no cask macos requirement is nil")

    // 3.6.0 — finalizeStatus honors the OS compatibility gate
    var gated = AppRow(name: "Status Monitor", bundleID: "com.tony.Status", installed: "1.1",
                       path: "/Applications/Status Monitor.app", feedURL: nil, homepage: nil,
                       downloadURL: nil, releaseNotesURL: nil, latest: "1.9.2",
                       source: "App Store", note: "", status: .unknown)
    gated.requiresOS = "18.0"
    finalizeStatus(&gated)
    check(gated.status == .upToDate, "OS-gated update shown up-to-date (got \(statusText(gated.status)))")
    check(gated.note.lowercased().contains("macos"), "OS gate note explains the reason")
    var ungated = gated; ungated.requiresOS = "10.15"
    finalizeStatus(&ungated)
    check(ungated.status == .update, "satisfiable OS requirement still offers the update")

    // 3.6.0 — cask minOS parsing
    let minOSCask: [String: Any] = [
        "token": "needs-sonoma", "name": ["Needs Sonoma"], "version": "1.0",
        "url": "https://x.test/App.dmg",
        "depends_on": ["macos": [">= :sonoma"]]
    ]
    if let c = parseCask(minOSCask) {
        check(c.minOS == "14.0.0", "cask parses minimum OS (got \(c.minOS ?? "nil"))")
    } else { check(false, "min-os cask parse") }

    // 3.6.0 — repository string -> GitHub slug
    check(repositoryStringToSlug("https://github.com/owner/repo") == "owner/repo", "slug from https url")
    check(repositoryStringToSlug("https://github.com/owner/repo.git") == "owner/repo", "slug strips .git")
    check(repositoryStringToSlug("git+https://github.com/owner/repo.git") == "owner/repo", "slug strips git+")
    check(repositoryStringToSlug("git@github.com:owner/repo.git") == "owner/repo", "slug from scp-like url")
    check(repositoryStringToSlug("github:owner/repo") == "owner/repo", "slug from github shorthand")
    check(repositoryStringToSlug("https://github.com/owner/repo/issues") == nil, "deep path rejected")
    check(repositoryStringToSlug("https://gitlab.com/owner/repo") == nil, "non-github host rejected")
    check(repositoryStringToSlug("https://github.com/owner") == nil, "missing repo component rejected")

    // 3.6.0 — Squirrel.Mac JSON feeds
    if let sq = parseSquirrelJSON(#"{"name":"2.0.1","url":"https://x.test/App.zip"}"#.data(using: .utf8)!) {
        check(sq.version == "2.0.1" && sq.url == "https://x.test/App.zip", "squirrel object feed parsed")
    } else { check(false, "squirrel object feed parsed") }
    check(parseSquirrelJSON(#"[{"name":"2.0.1","url":"https://x.test"}]"#.data(using: .utf8)!)?.version == "2.0.1",
          "squirrel array feed parsed")
    check(parseSquirrelJSON(#"{"foo":1}"#.data(using: .utf8)!) == nil, "squirrel feed without name rejected")

    // 3.6.0 — duplicateGroups ordering
    let dgBase = AppRow(name: "Waz", bundleID: "com.waz", installed: "1.0",
                        path: "/Applications/Waz.app", feedURL: nil, homepage: nil,
                        downloadURL: nil, releaseNotesURL: nil, latest: nil, source: "-",
                        note: "", status: .unknown)
    var dgA = dgBase; dgA.isDuplicate = true
    var dgB = dgBase; dgB.isDuplicate = true
    dgB.path = NSHomeDirectory() + "/Applications/Waz.app"; dgB.installed = "0.9"
    var dgC = dgBase; dgC.isDuplicate = true
    dgC.path = NSHomeDirectory() + "/Desktop/Waz.app"; dgC.installed = "1.1"
    let groups = duplicateGroups(in: [dgA, dgB, dgC])
    check(groups.count == 1, "one duplicate group (got \(groups.count))")
    if let grp = groups.first {
        check(grp.first?.path == "/Applications/Waz.app", "primary copy first by location")
        check(grp.count == 3, "all three copies present")
        check(grp.last?.path.hasSuffix("Desktop/Waz.app") == true, "low-rank copy last")
    }
    check(duplicateGroups(in: [dgBase]).isEmpty, "single copy yields no groups")

    // 3.6.0 — custom sources preference
    Prefs.customSources = ["com.waz": "https://example.test/feed.xml"]
    check(Prefs.customSources["com.waz"] == "https://example.test/feed.xml", "custom sources round trip")
    Prefs.customSources = [:]
    check(Prefs.customSources.isEmpty, "custom sources cleared")

    // 3.6.0 — UInt32 LE helper
    check(readUInt32LE(Data([0x39, 0x05, 0x00, 0x00]), 0) == 1337, "uint32 little-endian read")
    check(readUInt32LE(Data([0x39, 0x05]), 0) == nil, "short data yields nil")

    // 3.6.0 — asar header + package.json repository extraction (packed + unpacked)
    do {
        let tmp = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("mu-asar-\(UUID().uuidString)")
        func buildAsar(appName: String, unpacked: Bool, repository: String) throws {
            let pkg = try JSONSerialization.data(
                withJSONObject: ["repository": ["url": repository]])
            let fileEntry: [String: Any] = unpacked
                ? ["size": pkg.count, "unpacked": true]
                : ["size": pkg.count, "offset": "0"]
            let header = try JSONSerialization.data(
                withJSONObject: ["files": ["package.json": fileEntry]])
            let paddedLen = (header.count + 3) & ~3
            func le32(_ v: UInt32) -> Data {
                var x = v.littleEndian; return Data(bytes: &x, count: 4)
            }
            var bin = Data()
            bin.append(le32(4))
            bin.append(le32(UInt32(header.count) + 4))
            bin.append(le32(4))
            bin.append(le32(UInt32(header.count)))
            bin.append(header)
            bin.append(Data(count: paddedLen - header.count))
            if !unpacked { bin.append(pkg) }
            let res = tmp.appendingPathComponent("\(appName).app/Contents/Resources")
            try FileManager.default.createDirectory(at: res, withIntermediateDirectories: true)
            try bin.write(to: res.appendingPathComponent("app.asar"))
            if unpacked {
                let u = res.appendingPathComponent("app.asar.unpacked")
                try FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
                try pkg.write(to: u.appendingPathComponent("package.json"))
            }
        }
        try buildAsar(appName: "Packed", unpacked: false,
                      repository: "https://github.com/some/cool.git")
        try buildAsar(appName: "Unpacked", unpacked: true,
                      repository: "git+https://github.com/another/great.git")
        check(extractAsarRepository(at: tmp.appendingPathComponent("Packed.app").path) == "some/cool",
              "asar packed package.json repository extracted")
        check(extractAsarRepository(at: tmp.appendingPathComponent("Unpacked.app").path) == "another/great",
              "asar unpacked package.json repository extracted")
        try? FileManager.default.removeItem(at: tmp)
    } catch {
        check(false, "asar extraction test: \(error)")
    }

    // 3.6.0 — environment diagnostics
    do {
        let logs = supportDirectory().appendingPathComponent("Logs")
        try FileManager.default.createDirectory(at: logs, withIntermediateDirectories: true)
        let probe = logs.appendingPathComponent(".write-probe")
        try "x".write(to: probe, atomically: true, encoding: .utf8)
        try? FileManager.default.removeItem(at: probe)
        check(true, "data and Logs directories writable")
    } catch {
        check(false, "data and Logs directories writable: \(error.localizedDescription)")
    }
    for tool in ["/usr/bin/codesign", "/usr/bin/hdiutil", "/usr/sbin/installer", "/usr/bin/ditto"] {
        check(FileManager.default.isExecutableFile(atPath: tool), "tool present: \(tool)")
    }
    if let attrs = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()),
       let free = attrs[.systemFreeSize] as? NSNumber {
        let ok = free.int64Value > 1_073_741_824
        check(ok, "free disk space > 1 GB (got \(ByteCountFormatter.string(fromByteCount: free.int64Value, countStyle: .file)))")
    } else {
        check(false, "free disk space readable")
    }
    if let cached = FileManager.default.contents(atPath: caskCacheURL().path) {
        check((try? JSONSerialization.jsonObject(with: cached)) != nil, "cached cask index parses")
    } else {
        note("no cached cask index yet (downloaded on first check)")
    }
    func reachable(_ host: String) -> Bool {
        guard let u = URL(string: host) else { return false }
        let sem = DispatchSemaphore(value: 0)
        var ok = false
        var req = URLRequest(url: u); req.timeoutInterval = 3; req.httpMethod = "HEAD"
        URLSession.shared.dataTask(with: req) { _, resp, err in
            if err == nil, (resp as? HTTPURLResponse) != nil { ok = true }
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + 4)
        return ok
    }
    for h in ["https://formulae.brew.sh", "https://itunes.apple.com",
              "https://api.github.com", "https://github.com"] {
        if reachable(h) { note("network reachable: \(h)") } else { warn("network not reachable: \(h)") }
    }

    // 1.0 — GitHub tag version extraction (the "/" regex bug)
    check(extractTagVersion("v2.0.1") == "2.0.1", "tag v2.0.1 -> 2.0.1")
    check(extractTagVersion("release-1.2") == "1.2", "tag release-1.2 -> 1.2")
    check(extractTagVersion("v2") == "2", "tag v2 -> 2 (was broken by trailing-slash regex)")
    check(extractTagVersion("1.0") == "1.0", "plain tag unchanged")
    check(normalizeVersion("v2") == "2", "normalize v2 -> 2")

    // 1.0 — version constant sanity
    check(isPlausibleVersion(MacRefreshVersion), "app version constant plausible")

    // 1.0 — download jobs install by default; download-only is opt-in
    let djDefault = DownloadJob(title: "T", kind: "Update",
                                url: URL(string: "https://x.test/a.dmg")!, relaunch: false)
    check(djDefault.installAfterDownload, "new download jobs install after download by default")
    djDefault.installAfterDownload = false
    check(!djDefault.installAfterDownload, "download-only flag can be turned off")

    // 1.0 — SHA-256 digest of a known file ("abc")
    do {
        let tmp = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("mr-sha-\(UUID().uuidString).txt")
        try "abc".write(to: tmp, atomically: true, encoding: .utf8)
        check(Installer.sha256(of: tmp) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
              "sha256 digest of 'abc'")
        try? FileManager.default.removeItem(at: tmp)
    } catch { check(false, "sha256 test: \(error)") }

    // 1.0 — signature verification: valid ad-hoc app passes, broken app fails
    do {
        let tmp = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("mr-codesign-\(UUID().uuidString)")
        let signed = tmp.appendingPathComponent("Signed.app")
        try FileManager.default.createDirectory(
            at: signed.appendingPathComponent("Contents/MacOS"), withIntermediateDirectories: true)
        let plist = """
        <?xml version="1.0" encoding="UTF-8"?>
        <plist version="1.0"><dict><key>CFBundleIdentifier</key><string>com.test.signed</string>
        <key>CFBundleName</key><string>Signed</string><key>CFBundleExecutable</key><string>Signed</string>
        <key>CFBundleShortVersionString</key><string>1.0</string>
        <key>CFBundlePackageType</key><string>APPL</string></dict></plist>
        """
        try plist.write(to: signed.appendingPathComponent("Contents/Info.plist"),
                        atomically: true, encoding: .utf8)
        let exe = signed.appendingPathComponent("Contents/MacOS/Signed")
        try "#!/bin/sh\nexit 0\n".write(to: exe, atomically: true, encoding: .utf8)
        Installer.runProc("/bin/chmod", ["+x", exe.path])
        let cs = Installer.runProc("/usr/bin/codesign", ["-s", "-", "--force", signed.path])
        check(cs.code == 0, "ad-hoc sign test app (\(cs.output))")
        check(Installer.verifySignature(at: signed) == nil, "verifySignature passes a signed app")
        try FileManager.default.removeItem(at: signed.appendingPathComponent("Contents/Info.plist"))
        check(Installer.verifySignature(at: signed) != nil, "verifySignature fails a broken app")
        try? FileManager.default.removeItem(at: tmp)
    } catch { check(false, "signature test: \(error)") }

    // 1.0 — extra build-number-equivalent cases
    check(isBuildNumberEquivalent(installed: "1.2.3", latest: "1.2.3.4567"),
          "3-part version + build number equivalent")
    check(isBuildNumberEquivalent(installed: "10.0", latest: "10.0.12345"),
          "2-part version + 5-digit build equivalent")
    check(!isBuildNumberEquivalent(installed: "1.2.3", latest: "1.2.4.5678"),
          "changed component plus build not equivalent")
    check(!isBuildNumberEquivalent(installed: "1.0", latest: "1.0.12"),
          "short numeric tail is a patch, not a build number")

    // 1.0 — sortUpdates honors the persisted sort key/direction
    func mkUpdateRow(_ name: String, _ installed: String) -> AppRow {
        AppRow(name: name, bundleID: "b.\(name.lowercased())", installed: installed,
               path: "/Applications/\(name).app", feedURL: nil, homepage: nil,
               downloadURL: nil, releaseNotesURL: nil, latest: nil, source: "Test",
               note: "", status: .unknown)
    }
    UserDefaults.standard.set("app", forKey: Prefs.updatesSortKey)
    UserDefaults.standard.set(true, forKey: Prefs.updatesSortAsc)
    let suRows = [mkUpdateRow("Zebra", "1.0"), mkUpdateRow("Alpha", "2.0")]
    check(appDelegate.sortUpdates(suRows).first?.name == "Alpha",
          "sortUpdates by app, ascending")
    UserDefaults.standard.set(false, forKey: Prefs.updatesSortAsc)
    check(appDelegate.sortUpdates(suRows).first?.name == "Zebra",
          "sortUpdates by app, descending")
    UserDefaults.standard.set("change", forKey: Prefs.updatesSortKey)
    UserDefaults.standard.set(true, forKey: Prefs.updatesSortAsc)
    check(appDelegate.sortUpdates(suRows).first?.name == "Zebra",
          "sortUpdates by installed version ascending (1.0 first)")
    UserDefaults.standard.set("app", forKey: Prefs.updatesSortKey)
    UserDefaults.standard.set(true, forKey: Prefs.updatesSortAsc)

    // 1.0 — an extra scan folder is actually searched
    do {
        let tmp = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("mr-extra-\(UUID().uuidString)")
        let extraApp = tmp.appendingPathComponent("Extra.app")
        try FileManager.default.createDirectory(
            at: extraApp.appendingPathComponent("Contents/MacOS"), withIntermediateDirectories: true)
        let plist = """
        <?xml version="1.0" encoding="UTF-8"?>
        <plist version="1.0"><dict><key>CFBundleIdentifier</key><string>com.test.extra</string>
        <key>CFBundleName</key><string>Extra</string><key>CFBundleExecutable</key><string>Extra</string>
        <key>CFBundleShortVersionString</key><string>1.0</string>
        <key>CFBundlePackageType</key><string>APPL</string></dict></plist>
        """
        try plist.write(to: extraApp.appendingPathComponent("Contents/Info.plist"),
                        atomically: true, encoding: .utf8)
        let savedFolders = Prefs.extraFolders
        Prefs.extraFolders = [tmp.path]
        let scanned = scanForApps(includeHome: false)
        check(scanned.contains { $0.path == extraApp.path },
              "apps inside an extra scan folder are found")
        Prefs.extraFolders = savedFolders
        try? FileManager.default.removeItem(at: tmp)
    } catch { check(false, "extra folder test: \(error)") }

    return DiagnosticsResult(failed: fail, lines: lines)
}

func runSelfCheck() -> Bool {
    let r = runDiagnostics()
    r.lines.forEach { print($0) }
    let pass = r.lines.filter { $0.hasPrefix("PASS") }.count
    print("\(pass) passed, \(r.failed) failed")
    return r.failed == 0
}

func runHeadlessScan(asCSV: Bool = false) {
    if !asCSV { print("Scanning installed apps…") }
    let apps = scanForApps(includeHome: UserDefaults.standard.bool(forKey: Prefs.scanHome))
    if !asCSV { print("Found \(apps.count) apps\n") }

    var caskMap: [String: Cask]?
    let cacheURL = caskCacheURL()
    if let cached = loadCaskIndexFromDisk(at: cacheURL) {
        caskMap = cached.map
    } else {
        let sem = DispatchSemaphore(value: 0)
        loadCaskIndex { map, _ in caskMap = map; sem.signal() }
        sem.wait()
        if !asCSV { print(caskMap == nil ? "(cask index unavailable — offline?)" : "(using Homebrew cask index)") }
    }

    var resolved: [AppRow] = []
    let lock = NSLock()
    let sem = DispatchSemaphore(value: 0)
    checkUpdates(apps: apps, caskMap: caskMap, completionQueue: .global()) { n, total, app in
        lock.lock(); resolved.append(app); lock.unlock()
        if !asCSV {
            let inst = app.installed.isEmpty ? "—" : app.installed
            let latest = app.latest ?? "—"
            let flag = app.status == .update ? "  << UPDATE" : ""
            print("[\(n)/\(total)] \(app.name)  |  \(inst) → \(latest)  |  \(app.source)  |  \(statusText(app.status))\(flag)")
        }
    } done: { sem.signal() }
    sem.wait()
    if asCSV {
        resolved.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        print(csvRows(resolved))
    } else {
        print("\nDone.")
    }
}

func runInstallCask(_ token: String) {
    Installer.cleanupStaleArtifacts()
    var caskMap: [String: Cask]?
    if let cached = loadCaskIndexFromDisk(at: caskCacheURL()) {
        caskMap = cached.map
    } else {
        let sem = DispatchSemaphore(value: 0)
        loadCaskIndex { map, _ in caskMap = map; sem.signal() }
        sem.wait()
    }
    guard let cask = caskMap?[token] ?? caskMap?.values.first(where: { $0.token == token }) else {
        print("cask not found: \(token)"); exit(2)
    }
    let displayName = cask.names.first ?? cask.token
    print("Installing \(displayName) \(cask.version)")
    print("URL: \(cask.url)")
    guard let url = URL(string: cask.url) else { print("bad url"); exit(2) }

    let sem = DispatchSemaphore(value: 0)
    var tmp: URL?, dlErr: Error?, suggested: String?
    let task = URLSession.shared.downloadTask(with: url) { t, response, e in
        tmp = t; dlErr = e
        suggested = (response as? HTTPURLResponse)?.suggestedFilename
        sem.signal()
    }
    task.resume()
    sem.wait()
    if let e = dlErr { print("download failed: \(e)"); exit(3) }
    guard let downloaded = tmp else { print("download failed: no file"); exit(3) }

    let filename = suggested ?? url.lastPathComponent
    let dest = supportDirectory().appendingPathComponent("Downloads").appendingPathComponent(filename)
    try? FileManager.default.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
    try? FileManager.default.removeItem(at: dest)
    do { try FileManager.default.moveItem(at: downloaded, to: dest) } catch {
        print("could not stage download: \(error)"); exit(3)
    }
    print("downloaded \(dest.lastPathComponent)")

    let job = DownloadJob(title: displayName, kind: "Install", url: url, relaunch: false)
    job.expectedAppName = cask.appArtifacts.first
    job.expectedTarget = cask.appTargets.first
    job.quitIDs = cask.quitIDs

    let result = Installer.process(downloadedFile: dest, job: job)
    switch result {
    case .installed(let appURL, _):
        print("INSTALLED: \(appURL.path)")
        if !UserDefaults.standard.bool(forKey: Prefs.keepInstallers) {
            try? FileManager.default.removeItem(at: dest)
        }
        exit(0)
    case .installerOpened:
        print("PACKAGE INSTALLER OPENED: \(dest.path)"); exit(0)
    case .revealed:
        print("DOWNLOADED & REVEALED: \(dest.path)"); exit(0)
    case .failed(let msg):
        print("FAILED: \(msg)"); exit(4)
    }
}

// Hidden verification entry: run a local .pkg through the silent installer.
// The AppleScript password dialog runs on the main thread, so the install runs
// on a background queue while the main run loop keeps pumping.
func runInstallPKG(_ path: String) {
    let pkg = URL(fileURLWithPath: path)
    guard FileManager.default.fileExists(atPath: pkg.path) else { print("pkg not found: \(path)"); exit(2) }
    let job = DownloadJob(title: pkg.deletingPathExtension().lastPathComponent, kind: "Install",
                          url: pkg, relaunch: false)
    print("Installing package \(pkg.lastPathComponent) — a password dialog should appear…")
    var result: InstallResult?
    DispatchQueue.global(qos: .userInitiated).async {
        result = Installer.process(downloadedFile: pkg, job: job)
    }
    while result == nil {
        RunLoop.current.run(mode: .default, before: Date().addingTimeInterval(0.2))
    }
    switch result! {
    case .installed(let url, _): print("INSTALLED: \(url.path)"); exit(0)
    case .installerOpened(let u): print("INSTALLER OPENED: \(u.path)"); exit(0)
    case .revealed(let u): print("REVEALED: \(u.path)"); exit(0)
    case .failed(let msg): print("FAILED: \(msg)"); exit(4)
    }
}

func runResolveCask(_ token: String) {    var caskList: [Cask] = []
    if let cached = loadCaskIndexFromDisk(at: caskCacheURL()) {
        caskList = cached.list
    } else {
        let sem = DispatchSemaphore(value: 0)
        loadCaskIndex { _, list in caskList = list; sem.signal() }
        sem.wait()
    }
    guard let cask = caskList.first(where: { $0.token == token }) else {
        print("cask not found: \(token)"); exit(2)
    }
    let direct = isDirectInstallerURL(cask.url)
    print("token: \(cask.token)")
    print("name: \(cask.names.first ?? cask.token)")
    print("version: \(cask.version)")
    print("direct: \(direct)")
    print("artifacts: \(cask.appArtifacts.joined(separator: ", "))")
    print("url: \(cask.url)")
    exit(direct ? 0 : 1)
}

// Headless modes still touch AppKit (NSApp.activate during installs), so make
// sure the shared application exists before entering them.
func bootstrapHeadlessApp() {
    headlessMode = true
    // Isolate every data read/write into a fresh temp directory so the
    // self-check never contaminates the real MacRefresh Application Support
    // folder (history, downloads, caches, parked builds).
    headlessSupportDirectory = FileManager.default.temporaryDirectory
        .appendingPathComponent("MacRefreshSelfCheck-\(UUID().uuidString)", isDirectory: true)
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    Prefs.registerDefaults()
}

if CommandLine.arguments.contains("--selfcheck") {
    bootstrapHeadlessApp()
    exit(runSelfCheck() ? 0 : 1)
}
if CommandLine.arguments.contains("--scan") {
    bootstrapHeadlessApp()
    runHeadlessScan()
    exit(0)
}
if CommandLine.arguments.contains("--csv") {
    bootstrapHeadlessApp()
    runHeadlessScan(asCSV: true)
    exit(0)
}
if let i = CommandLine.arguments.firstIndex(of: "--resolve-cask"),
   i + 1 < CommandLine.arguments.count {
    bootstrapHeadlessApp()
    runResolveCask(CommandLine.arguments[i + 1])
    exit(0)
}
if let i = CommandLine.arguments.firstIndex(of: "--install-cask"),
   i + 1 < CommandLine.arguments.count {
    bootstrapHeadlessApp()
    runInstallCask(CommandLine.arguments[i + 1])
    exit(0)
}
if let i = CommandLine.arguments.firstIndex(of: "--install-pkg"),
   i + 1 < CommandLine.arguments.count {
    bootstrapHeadlessApp()
    runInstallPKG(CommandLine.arguments[i + 1])
    exit(0)
}

let app = NSApplication.shared
if let i = CommandLine.arguments.firstIndex(of: "--pane"),
   i + 1 < CommandLine.arguments.count {
    initialSectionName = CommandLine.arguments[i + 1]
}
app.delegate = appDelegate
Prefs.registerDefaults()
app.setActivationPolicy(UserDefaults.standard.bool(forKey: Prefs.showDockIcon) ? .regular : .accessory)
Installer.cleanupStaleArtifacts()
// Single-instance: hand focus to the running app instead of opening a second one
let myPID = ProcessInfo.processInfo.processIdentifier
if let existing = NSWorkspace.shared.runningApplications.first(where: {
    $0.bundleIdentifier == "com.macrefresh.fixed" && $0.processIdentifier != myPID && !$0.isTerminated
}) {
    existing.activate(options: NSApplication.ActivationOptions.activateAllWindows)
    exit(0)
}
// Never restore stale windows from a previous session (we build UI programmatically)
UserDefaults.standard.register(defaults: ["NSQuitAlwaysKeepsWindows": false])
if let saved = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask).first?
    .appendingPathComponent("Saved Application State/com.macrefresh.fixed.savedState") {
    try? FileManager.default.removeItem(at: saved)
}
app.run()
