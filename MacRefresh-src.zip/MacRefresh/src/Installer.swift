// Installer.swift — in-app downloads and one-click installation
import Cocoa
import UserNotifications

/// Set by CLI/self-test entry points; user-visible notifications are skipped
/// there (no GUI session).
var headlessMode = false

/// `UNUserNotificationCenter.current()` asserts ("could not find a bundle
/// identifier") when the binary runs outside an app bundle — e.g. the raw
/// binary during `--selfcheck`. Only ever touch it from a real bundled GUI
/// process.
func safeNotificationCenter() -> UNUserNotificationCenter? {
    guard !headlessMode, Bundle.main.bundleIdentifier != nil else { return nil }
    return UNUserNotificationCenter.current()
}

enum JobState: Int {
    case queued, downloading, paused, extracting, installing, openingInstaller, done, failed, canceled

    var text: String {
        switch self {
        case .queued: return "Queued"
        case .downloading: return "Downloading"
        case .paused: return "Paused"
        case .extracting: return "Extracting"
        case .installing: return "Installing"
        case .openingInstaller: return "Installer opened"
        case .done: return "Installed"
        case .failed: return "Failed"
        case .canceled: return "Canceled"
        }
    }
}

final class DownloadJob: NSObject {
    let id = UUID()
    let title: String
    let kind: String          // "Update" or "Install"
    let url: URL
    var expectedAppName: String?
    var expectedTarget: String?
    var existingPath: String?
    var bundleID: String?
    var quitIDs: [String] = []
    var expectedVersion: String?
    var relaunch: Bool
    /// When false the file is downloaded and kept (and revealed) but not
    /// installed — the "Download Only" action.
    var installAfterDownload = true

    dynamic var state: JobState = .queued
    dynamic var progress: Double = 0       // 0...1, -1 = indeterminate
    dynamic var message: String = ""
    var localURL: URL?
    var installedURL: URL?
    weak var task: URLSessionDownloadTask?
    var lastBytesDate = Date()
    var attempts = 0
    var resumeData: Data?
    var speedSamples: [(date: Date, bytes: Int64)] = []

    init(title: String, kind: String, url: URL, relaunch: Bool) {
        self.title = title
        self.kind = kind
        self.url = url
        self.relaunch = relaunch
    }
}

enum InstallResult {
    /// `rollback` holds the retained previous build (data/Parked) when available.
    case installed(URL, rollback: URL?)
    case installerOpened(URL)
    case revealed(URL)
    case failed(String)
}

enum Installer {
    // MARK: Process helper

    @discardableResult
    static func runProc(_ launchPath: String, _ args: [String], timeout seconds: TimeInterval = 120)
    -> (code: Int32, output: String) {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: launchPath)
        p.arguments = args
        let pipe = Pipe()
        p.standardOutput = pipe
        p.standardError = pipe
        // Drain output while the process runs. Reading only after exit let a
        // verbose child fill the 16KB pipe buffer, block on write and hang
        // until the timeout (a real "install stuck" cause).
        let dataLock = NSLock()
        var collected = Data()
        pipe.fileHandleForReading.readabilityHandler = { fh in
            let chunk = fh.availableData
            if chunk.isEmpty { return }
            dataLock.lock(); collected.append(chunk); dataLock.unlock()
        }
        do { try p.run() } catch {
            pipe.fileHandleForReading.readabilityHandler = nil
            return (-1, error.localizedDescription)
        }
        let deadline = Date().addingTimeInterval(seconds)
        while p.isRunning, Date() < deadline { Thread.sleep(forTimeInterval: 0.1) }
        if p.isRunning {
            p.terminate()
            Thread.sleep(forTimeInterval: 0.5)
            if p.isRunning {
                kill(p.processIdentifier, SIGKILL)   // second terminate() was a no-op
                Thread.sleep(forTimeInterval: 0.3)
            }
            pipe.fileHandleForReading.readabilityHandler = nil
            dataLock.lock(); let tail = collected; dataLock.unlock()
            return (-2, "Timed out after \(Int(seconds))s\n" + (String(data: tail, encoding: .utf8) ?? ""))
        }
        Thread.sleep(forTimeInterval: 0.1)
        pipe.fileHandleForReading.readabilityHandler = nil
        let end = pipe.fileHandleForReading.readDataToEndOfFile()
        dataLock.lock(); collected.append(end); let out = collected; dataLock.unlock()
        return (p.terminationStatus, String(data: out, encoding: .utf8) ?? "")
    }

    /// Bring MacRefresh to the front so macOS permission prompts (notably the
    /// App Management prompt when replacing another app) are actually visible.
    static func activateHostApp() {
        DispatchQueue.main.async { NSApp.activate(ignoringOtherApps: true) }
        Thread.sleep(forTimeInterval: 0.4)
    }

    /// Move an item to the Trash through NSWorkspace (the route that triggers
    /// macOS App Management authorization), blocking by polling on the calling
    /// background queue. Never call on the URLSession delegate queue.
    @discardableResult
    static func recycleSync(_ url: URL, timeout seconds: TimeInterval = 30) -> Bool {
        let fm = FileManager.default
        guard fm.fileExists(atPath: url.path) else { return true }
        DispatchQueue.main.async {
            NSWorkspace.shared.recycle([url]) { _, _ in }
        }
        let deadline = Date().addingTimeInterval(seconds)
        while Date() < deadline {
            if !fm.fileExists(atPath: url.path) { return true }
            Thread.sleep(forTimeInterval: 0.25)
        }
        return !fm.fileExists(atPath: url.path)
    }

    // MARK: Filesystem helpers

    static func uniqueDir(_ name: String) -> URL {
        let dir = supportDirectory().appendingPathComponent(name)
            .appendingPathComponent(UUID().uuidString)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func setQuarantine(_ url: URL) {
        // Only stamp files MacRefresh itself downloaded; never local files the
        // user handed us (--install-pkg / drag-and-drop).
        let downloads = downloadsDirectory().path
        guard url.path.hasPrefix(downloads) else { return }
        let stamp = String(format: "%08x", Int(Date().timeIntervalSince1970))
        runProc("/usr/bin/xattr", ["-w", "com.apple.quarantine",
                                   "00c1;\(stamp);MacRefresh;", url.path])
    }

    static func findApp(in root: URL, hint: String?) -> URL? {
        let fm = FileManager.default
        if let hint = hint {
            let direct = root.appendingPathComponent(hint)
            if fm.fileExists(atPath: direct.path) { return direct }
            if let enumerator = fm.enumerator(at: root,
                                              includingPropertiesForKeys: [.isSymbolicLinkKey, .isDirectoryKey]) {
                for case let url as URL in enumerator {
                    if url.lastPathComponent == hint { return url }
                    if enumerator.level > 4 { enumerator.skipDescendants() }
                }
            }
        }
        guard let enumerator = fm.enumerator(at: root,
                                             includingPropertiesForKeys: [.isSymbolicLinkKey, .isDirectoryKey])
        else { return nil }
        var best: URL?
        var bestLevel = Int.max
        for case let url as URL in enumerator {
            let vals = try? url.resourceValues(forKeys: [.isSymbolicLinkKey, .isDirectoryKey])
            if vals?.isSymbolicLink == true { enumerator.skipDescendants(); continue }
            if url.pathExtension == "app", vals?.isDirectory == true {
                // Never descend into an app bundle: a nested helper app must not
                // be mistaken for the product. Keep the shallowest top-level app.
                enumerator.skipDescendants()
                if enumerator.level < bestLevel { best = url; bestLevel = enumerator.level }
            }
            if enumerator.level > 4 { enumerator.skipDescendants() }
        }
        return best
    }

    /// Synchronously move an item into the user's Trash (~/.Trash), renaming
    /// uniquely on collision. Must NOT use NSWorkspace.recycle + a waiting
    /// semaphore: its completion handler is dispatched back onto the blocked
    /// caller queue (the URLSession delegate queue), deadlocking installs.
    @discardableResult
    static func trash(_ url: URL) -> Bool {
        let fm = FileManager.default
        guard fm.fileExists(atPath: url.path) else { return true }
        if let trash = try? fm.url(for: .trashDirectory, in: .userDomainMask,
                                  appropriateFor: nil, create: true) {
            try? fm.createDirectory(at: trash, withIntermediateDirectories: true)
            let name = url.lastPathComponent
            if !fm.fileExists(atPath: trash.appendingPathComponent(name).path) {
                do { try fm.moveItem(at: url, to: trash.appendingPathComponent(name)); return true } catch {}
            }
            let stem = (name as NSString).deletingPathExtension
            let ext = (name as NSString).pathExtension
            for i in 1...200 {
                let newName = ext.isEmpty ? "\(stem) \(i)" : "\(stem) \(i).\(ext)"
                let candidate = trash.appendingPathComponent(newName)
                if !fm.fileExists(atPath: candidate.path) {
                    do { try fm.moveItem(at: url, to: candidate); return true } catch { break }
                }
            }
        }
        // Fallback: park it beside itself so the destination path is free.
        let parked = url.deletingLastPathComponent()
            .appendingPathComponent(url.lastPathComponent + ".old-\(UUID().uuidString.prefix(8))")
        do { try fm.moveItem(at: url, to: parked); return true } catch { return false }
    }

    /// Folder where downloaded installers are staged — either MacRefresh's
    /// data/Downloads or a user-chosen folder. Custom folders are created but
    /// never auto-pruned (they may contain unrelated files).
    static func downloadsDirectory() -> URL {
        let custom = (UserDefaults.standard.string(forKey: Prefs.customDownloadsFolder) ?? "")
            .trimmingCharacters(in: .whitespaces)
        let dir: URL
        if !custom.isEmpty {
            dir = URL(fileURLWithPath: custom)
        } else {
            dir = supportDirectory().appendingPathComponent("Downloads")
        }
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// Detach stale mounts and remove leftovers from interrupted previous runs.
    static func cleanupStaleArtifacts() {
        let fm = FileManager.default
        let base = supportDirectory()
        let mounts = base.appendingPathComponent("Mounts")
        if let entries = try? fm.contentsOfDirectory(atPath: mounts.path) {
            for e in entries {
                let p = mounts.appendingPathComponent(e)
                _ = runProc("/usr/bin/hdiutil", ["detach", "-force", p.path])
                try? fm.removeItem(at: p)
            }
        }
        let extracts = base.appendingPathComponent("Extracts")
        if let entries = try? fm.contentsOfDirectory(atPath: extracts.path) {
            for e in entries { try? fm.removeItem(at: extracts.appendingPathComponent(e)) }
        }
        // Only the managed Downloads folder is pruned; a user-chosen folder is
        // never touched by automatic cleanup.
        let downloads = base.appendingPathComponent("Downloads")
        if let entries = try? fm.contentsOfDirectory(atPath: downloads.path) {
            let keep = UserDefaults.standard.bool(forKey: Prefs.keepInstallers)
            let cutoff = Date().addingTimeInterval(-7 * 24 * 3600)
            for e in entries {
                let p = downloads.appendingPathComponent(e)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: p.path, isDirectory: &isDir), !isDir.boolValue {
                    // Old behavior wiped every staged file on launch — including
                    // installers the user revealed/kept. Now only files older
                    // than 7 days are removed, and none while "keep installers".
                    let attrs = try? fm.attributesOfItem(atPath: p.path)
                    let mtime = attrs?[.modificationDate] as? Date ?? Date.distantPast
                    if !keep && mtime < cutoff { try? fm.removeItem(at: p) }
                }
            }
        }
        pruneRollbackBuilds()
        rotateLogsIfNeeded()
    }

    static func quitApp(bundleID: String, wait seconds: TimeInterval = 8) {
        // Terminate every process of the bundle — main app plus helpers — so a
        // lingering helper cannot keep files busy and block replacement.
        let apps = NSRunningApplication.runningApplications(withBundleIdentifier: bundleID)
        guard !apps.isEmpty else { return }
        for app in apps { app.terminate() }
        let deadline = Date().addingTimeInterval(seconds)
        while Date() < deadline {
            if NSRunningApplication.runningApplications(withBundleIdentifier: bundleID).isEmpty { return }
            Thread.sleep(forTimeInterval: 0.25)
        }
        for app in NSRunningApplication.runningApplications(withBundleIdentifier: bundleID) {
            app.forceTerminate()
        }
        let until = Date().addingTimeInterval(3)
        while Date() < until {
            if NSRunningApplication.runningApplications(withBundleIdentifier: bundleID).isEmpty { return }
            Thread.sleep(forTimeInterval: 0.25)
        }
    }

    /// Terminate the WHOLE process tree living inside an app bundle. Browsers
    /// such as Google Chrome run helper, renderer, GPU and Keystone processes
    /// under different bundle identifiers, so quitting the main bundle id alone
    /// left those processes holding the old bundle open ("old version could not
    /// be removed"). Path-prefix matching plus a pkill sweep catches them all.
    static func quitAppTree(destPath: String, bundleIDs: [String], wait seconds: TimeInterval = 8) {
        for bid in bundleIDs { quitApp(bundleID: bid, wait: seconds) }
        let prefix = destPath.hasSuffix("/") ? destPath : destPath + "/"
        func inside(_ p: String?) -> Bool {
            guard let p = p else { return false }
            return p.hasPrefix(prefix)
        }
        for app in NSWorkspace.shared.runningApplications {
            if inside(app.bundleURL?.path) || inside(app.executableURL?.path) { app.terminate() }
        }
        Thread.sleep(forTimeInterval: 2.0)
        for app in NSWorkspace.shared.runningApplications {
            if inside(app.bundleURL?.path) || inside(app.executableURL?.path) { app.forceTerminate() }
        }
        Thread.sleep(forTimeInterval: 1.0)
        // Kill anything still executing from inside the bundle (helpers that
        // hide their bundle URL). -f matches the full command line; the path
        // argument is passed verbatim and is safe with spaces.
        _ = runProc("/usr/bin/pkill", ["-9", "-f", destPath + "/Contents"], timeout: 10)
        Thread.sleep(forTimeInterval: 0.5)
    }

    /// Shell-escape a path for embedding inside an AppleScript `do shell script`
    /// double-quoted command.
    static func appleShellEscape(_ s: String) -> String {
        return "'" + s.replacingOccurrences(of: "'", with: "'\\''") + "'"
    }

    /// Last-resort removal when every unprivileged route is blocked (notably
    /// macOS Sequoia App Management protection): ask for administrator rights
    /// through the native password dialog and move the bundle into the USER's
    /// Trash. An admin shell's $HOME is root's home, so the trash path is
    /// absolute. Returns true only once the destination no longer exists.
    @discardableResult
    static func adminMoveToTrash(_ url: URL) -> Bool {
        let fm = FileManager.default
        guard fm.fileExists(atPath: url.path) else { return true }
        let trash = NSHomeDirectory() + "/.Trash"
        try? fm.createDirectory(atPath: trash, withIntermediateDirectories: true)
        let fname = url.lastPathComponent
        let stem = (fname as NSString).deletingPathExtension
        let ext = (fname as NSString).pathExtension
        var target = trash + "/" + fname
        var i = 1
        while fm.fileExists(atPath: target) {
            target = ext.isEmpty
                ? "\(trash)/\(stem) old \(i)"
                : "\(trash)/\(stem) old \(i).\(ext)"
            i += 1
        }
        activateHostApp()
        let script = "do shell script \"/bin/mv \(appleShellEscape(url.path)) \(appleShellEscape(target))\" with administrator privileges"
        var ok = false
        let sem = DispatchSemaphore(value: 0)
        DispatchQueue.main.async {
            let apple = NSAppleScript(source: script)
            var err: NSDictionary?
            if apple?.executeAndReturnError(&err) != nil { ok = true }
            sem.signal()
        }
        sem.wait()
        return ok && !fm.fileExists(atPath: url.path)
    }

    static func destinationURL(for foundApp: URL, existingPath: String?, targetHint: String?) -> URL {
        let fm = FileManager.default
        if let existing = existingPath {
            let parent = (existing as NSString).deletingLastPathComponent
            if fm.isWritableFile(atPath: parent) {
                return URL(fileURLWithPath: existing)
            }
        }
        if let target = targetHint {
            let parent = (target as NSString).deletingLastPathComponent
            if fm.isWritableFile(atPath: parent) { return URL(fileURLWithPath: target) }
        }
        let global = "/Applications/" + foundApp.lastPathComponent
        if fm.isWritableFile(atPath: "/Applications") { return URL(fileURLWithPath: global) }
        let homeApps = NSHomeDirectory() + "/Applications"
        try? fm.createDirectory(atPath: homeApps, withIntermediateDirectories: true)
        return URL(fileURLWithPath: homeApps + "/" + foundApp.lastPathComponent)
    }

    /// Copies the found app into place, reliably replacing the old build.
    /// Strategy: quit the app and every helper inside the bundle → instantly
    /// rename the old bundle aside (frees the destination even if Trash is
    /// slow/blocked) → ditto the new build → keep the old build in data/Parked
    /// for rollback (or restore it if the copy fails).
    static func copyIntoPlace(sourceApp: URL, existingPath: String?, targetHint: String?,
                              quitBundleIDs: [String]) -> (url: URL?, error: String?, rollback: URL?) {
        let dest = destinationURL(for: sourceApp, existingPath: existingPath, targetHint: targetHint)
        quitAppTree(destPath: dest.path, bundleIDs: quitBundleIDs)
        let fm = FileManager.default
        activateHostApp()

        // Remove an existing destination using every available route, in order
        // of preference: instant rename, a retry after the app finishes exiting,
        // the system Trash (which surfaces the App Management authorization),
        // a direct Trash move, and finally an administrator-authorized move.
        @discardableResult
        func park(_ url: URL) -> URL? {
            let fname = url.lastPathComponent
            let stem = (fname as NSString).deletingPathExtension
            let ext = (fname as NSString).pathExtension
            func tryRename() -> URL? {
                let parkedName = ext.isEmpty
                    ? "\(stem).old-\(UUID().uuidString.prefix(8))"
                    : "\(stem).old-\(UUID().uuidString.prefix(8)).\(ext)"
                let parked = url.deletingLastPathComponent().appendingPathComponent(parkedName)
                do { try fm.moveItem(at: url, to: parked); return parked } catch { return nil }
            }
            if let p = tryRename() { return p }
            Thread.sleep(forTimeInterval: 1.5)
            // The app may have been slow to exit: kill the whole tree once more.
            quitAppTree(destPath: url.path, bundleIDs: [], wait: 4)
            if let p = tryRename() { return p }
            if recycleSync(url) { return nil }
            if trash(url), !fm.fileExists(atPath: url.path) { return nil }
            Thread.sleep(forTimeInterval: 1.0)
            if let p = tryRename() { return p }
            // App Management TCC or ownership can block every unprivileged
            // route: request administrator rights via the native dialog.
            if adminMoveToTrash(url) { return nil }
            return nil
        }

        var parked: URL? = nil
        if fm.fileExists(atPath: dest.path) {
            let p = park(dest)
            if p != nil { parked = p }
            else if fm.fileExists(atPath: dest.path) {
                return (nil, "The old version could not be removed. Open System Settings → Privacy & Security → App Management and allow MacRefresh (or enter the administrator password when prompted), make sure the app is fully quit, then click Update again.", nil)
            }
        }

        let ditto = runProc("/usr/bin/ditto", [sourceApp.path, dest.path], timeout: 300)
        if ditto.code != 0 {
            // First-choice target failed; try ~/Applications.
            let homeApps = NSHomeDirectory() + "/Applications"
            try? fm.createDirectory(atPath: homeApps, withIntermediateDirectories: true)
            let alt = URL(fileURLWithPath: homeApps + "/" + sourceApp.lastPathComponent)
            var parkedAlt: URL? = nil
            if fm.fileExists(atPath: alt.path) { parkedAlt = park(alt) }
            let ditto2 = runProc("/usr/bin/ditto", [sourceApp.path, alt.path], timeout: 300)
            if ditto2.code != 0 {
                // Clear the partial alt copy, then restore the build it had
                // replaced (an earlier version dropped the alt's old build).
                try? fm.removeItem(at: alt)
                if let pa = parkedAlt, !fm.fileExists(atPath: alt.path) {
                    try? fm.moveItem(at: pa, to: alt)
                }
                // Restore the primary destination's original build so the user
                // is never left without the app.
                if let parked = parked {
                    if fm.fileExists(atPath: dest.path) { try? fm.removeItem(at: dest) }
                    try? fm.moveItem(at: parked, to: dest)
                }
                return (nil, "Could not copy the app: \(ditto2.output)", nil)
            }
            let rbAlt = parkedAlt.flatMap { retainForRollback($0, appName: alt.lastPathComponent) }
            if rbAlt == nil, let pa = parkedAlt { disposeParked(pa) }
            return (alt, nil, rbAlt)
        }

        // Verify the new bundle is real before declaring success.
        let infoPlist = dest.appendingPathComponent("Contents/Info.plist")
        guard fm.fileExists(atPath: infoPlist.path) else {
            if let parked = parked { try? fm.moveItem(at: parked, to: dest) }
            return (nil, "The downloaded app bundle looks incomplete.", nil)
        }
        let rollback = parked.flatMap { retainForRollback($0, appName: dest.lastPathComponent) }
        if rollback == nil, let p = parked { disposeParked(p) }
        return (dest, nil, rollback)
    }

    /// Keep a replaced build for rollback under data/Parked/<Name>-<ts>.app.
    /// Works across volumes (move, then copy+delete fallback). Returns the
    /// retained URL, or nil when it could not be kept.
    static func retainForRollback(_ parked: URL, appName: String) -> URL? {
        let fm = FileManager.default
        let dir = supportDirectory().appendingPathComponent("Parked")
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let stem = (appName as NSString).deletingPathExtension
        let ts = Int(Date().timeIntervalSince1970)
        let target = dir.appendingPathComponent("\(stem)-\(ts).app")
        do {
            try fm.moveItem(at: parked, to: target)
            return target
        } catch {
            if runProc("/usr/bin/ditto", [parked.path, target.path], timeout: 300).code == 0 {
                try? fm.removeItem(at: parked)
                return fm.fileExists(atPath: target.path) ? target : nil
            }
            return nil
        }
    }

    /// Prune rollback builds older than the configured retention period.
    static func pruneRollbackBuilds() {
        let fm = FileManager.default
        let days = UserDefaults.standard.integer(forKey: Prefs.rollbackRetentionDays)
        guard days > 0 else { return }
        let dir = supportDirectory().appendingPathComponent("Parked")
        guard let entries = try? fm.contentsOfDirectory(atPath: dir.path) else { return }
        let cutoff = Date().addingTimeInterval(TimeInterval(-days * 86400))
        for e in entries where e.hasSuffix(".app") {
            let p = dir.appendingPathComponent(e)
            if let date = (try? p.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate,
               date < cutoff {
                try? fm.removeItem(at: p)
            }
        }
    }

    /// Rotate log files larger than ~2 MB, keeping one rolled copy each.
    static func rotateLogsIfNeeded() {
        let fm = FileManager.default
        let dir = supportDirectory().appendingPathComponent("Logs")
        guard let entries = try? fm.contentsOfDirectory(atPath: dir.path) else { return }
        for e in entries where e.hasSuffix(".log") {
            let p = dir.appendingPathComponent(e)
            if let size = (try? p.resourceValues(forKeys: [.fileSizeKey]))?.fileSize, size > 2_000_000 {
                let rolled = dir.appendingPathComponent(e + ".old")
                try? fm.removeItem(at: rolled)
                try? fm.moveItem(at: p, to: rolled)
            }
        }
    }

    /// Delete a parked ".old-…" build for good: Trash first, hard delete as last resort.
    static func disposeParked(_ url: URL) {
        if trash(url) { return }
        try? FileManager.default.removeItem(at: url)
    }

    /// SHA-256 hex digest of a file (via the system `shasum` tool), nil on failure.
    static func sha256(of url: URL) -> String? {
        let r = runProc("/usr/bin/shasum", ["-a", "256", url.path], timeout: 180)
        guard r.code == 0 else { return nil }
        return r.output.split(separator: " ").first.map(String.init)
    }

    /// Verify a bundle's code signature. Nil when valid; otherwise the first
    /// line of the verification output.
    static func verifySignature(at url: URL) -> String? {
        let r = runProc("/usr/bin/codesign",
                        ["--verify", "--deep", "--strict", "--verbose=1", url.path], timeout: 180)
        if r.code == 0 { return nil }
        let first = r.output.split(separator: "\n").first.map(String.init) ?? r.output
        return first.isEmpty ? "code signature verification failed" : first
    }

    /// Find an installer package inside a mounted image (Karabiner-Elements,
    /// drivers and some Microsoft disks ship a .pkg instead of a .app).
    static func findPackage(in root: URL) -> URL? {
        let fm = FileManager.default
        guard let enumerator = fm.enumerator(at: root, includingPropertiesForKeys: [.isSymbolicLinkKey])
        else { return nil }
        for case let url as URL in enumerator {
            let ext = url.pathExtension.lowercased()
            let leaf = url.lastPathComponent.lowercased()
            if (ext == "pkg" || ext == "mpkg") && !leaf.contains("uninstall") { return url }
            if enumerator.level > 4 { enumerator.skipDescendants() }
        }
        return nil
    }

    // MARK: DMG

    static func installDMG(_ archive: URL, job: DownloadJob) -> InstallResult {
        let mp = uniqueDir("Mounts")
        let attach = runProc("/usr/bin/hdiutil",
                             ["attach", "-nobrowse", "-readonly", "-mountpoint", mp.path, archive.path])
        if attach.code != 0 { return .failed("Could not mount disk image: \(attach.output)") }
        defer {
            runProc("/usr/bin/hdiutil", ["detach", "-force", mp.path])
            try? FileManager.default.removeItem(at: mp)
        }
        if let foundApp = findApp(in: mp, hint: job.expectedAppName) {
            var quitIDs = job.quitIDs
            if let bid = job.bundleID { quitIDs.insert(bid, at: 0) }
            let placed = copyIntoPlace(sourceApp: foundApp, existingPath: job.existingPath,
                                       targetHint: job.expectedTarget, quitBundleIDs: quitIDs)
            if let url = placed.url { return .installed(url, rollback: placed.rollback) }
            return .failed(placed.error ?? "Install failed")
        }
        // No .app on the disk: install an embedded package silently in-app.
        if let pkg = findPackage(in: mp) {
            return installPKG(pkg, job: job)
        }
        return .failed("No application or installer package found inside the disk image")
    }

    // MARK: ZIP

    static func installZIP(_ archive: URL, job: DownloadJob) -> InstallResult {
        let out = uniqueDir("Extracts")
        defer { try? FileManager.default.removeItem(at: out) }
        let unzip = runProc("/usr/bin/ditto", ["-x", "-k", archive.path, out.path])
        if unzip.code != 0 { return .failed("Could not open archive: \(unzip.output)") }
        guard let foundApp = findApp(in: out, hint: job.expectedAppName) else {
            return .failed("No application found inside the archive")
        }
        var quitIDs = job.quitIDs
        if let bid = job.bundleID { quitIDs.insert(bid, at: 0) }
        let placed = copyIntoPlace(sourceApp: foundApp, existingPath: job.existingPath,
                                   targetHint: job.expectedTarget, quitBundleIDs: quitIDs)
        if let url = placed.url { return .installed(url, rollback: placed.rollback) }
        return .failed(placed.error ?? "Install failed")
    }

    // MARK: PKG / MPKG (silent install with native administrator prompt)

    /// AppleScript source that runs `/usr/sbin/installer` as administrator,
    /// showing the native macOS password dialog. Pure so it can be unit-tested.
    static func pkgAdminScript(path: String) -> String {
        let escaped = path.replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
        return "do shell script \"/usr/sbin/installer -pkg \\\"\(escaped)\\\" -target /\" with administrator privileges"
    }

    static func setJob(_ job: DownloadJob?, state: JobState, message: String) {
        guard let job = job else { return }
        DispatchQueue.main.async {
            job.state = state
            job.progress = -1
            job.message = message
            DownloadManager.shared.onChange?()
        }
    }

    /// Install a package silently in-app via the system `installer` tool and the
    /// native administrator-password dialog. If the user cancels or the silent
    /// route is disabled, fall back to opening Installer.app.
    static func installPKG(_ package: URL, job: DownloadJob?) -> InstallResult {
        let silent = UserDefaults.standard.object(forKey: Prefs.silentPKG)
            .map { $0 as? Bool ?? true } ?? true
        guard silent else {
            NSWorkspace.shared.open(package)
            return .installerOpened(package)
        }

        setJob(job, state: .installing, message: "Waiting for administrator authorization…")
        activateHostApp()

        // NSAppleScript presents the SecurityAgent password dialog itself; run
        // it on the main thread and wait from this background install queue.
        let script = pkgAdminScript(path: package.path)
        var success = false
        var errorLine = ""
        let sem = DispatchSemaphore(value: 0)
        DispatchQueue.main.async {
            let apple = NSAppleScript(source: script)
            var err: NSDictionary?
            let output = apple?.executeAndReturnError(&err)
            if let err = err {
                errorLine = (err[NSAppleScript.errorMessage] as? String) ?? "Authorization failed"
            } else {
                _ = output
                success = true
            }
            sem.signal()
        }
        sem.wait()

        if success {
            // Prefer the app this package was expected to install.
            if let target = job?.expectedTarget, FileManager.default.fileExists(atPath: target) {
                // Mere existence is not proof the package upgraded the app:
                // verify the bundle's version reached what was expected.
                if let want = job?.expectedVersion,
                   let got = installedVersion(at: URL(fileURLWithPath: target)),
                   !got.isEmpty, isUpdateAvailable(installed: got, latest: want) {
                    return .failed("Package reported success but the app is still \(got) (expected \(want)). Try installing again or open the package manually.")
                }
                return .installed(URL(fileURLWithPath: target), rollback: nil)
            }
            if let hint = job?.expectedAppName {
                let candidate = URL(fileURLWithPath: "/Applications").appendingPathComponent(hint)
                if FileManager.default.fileExists(atPath: candidate.path) { return .installed(candidate, rollback: nil) }
                let homeCandidate = URL(fileURLWithPath: NSHomeDirectory() + "/Applications")
                    .appendingPathComponent(hint)
                if FileManager.default.fileExists(atPath: homeCandidate.path) { return .installed(homeCandidate, rollback: nil) }
            }
            return .installed(package, rollback: nil)
        }

        // User cancelled the password dialog (error -128) or authorization failed.
        if errorLine.contains("-128") || errorLine.lowercased().contains("cancel") {
            NSWorkspace.shared.open(package)
            return .installerOpened(package)
        }
        // Some other failure — still give the user the manual installer route.
        NSWorkspace.shared.open(package)
        return .failed("Automatic package install could not start (\(errorLine)); the Installer was opened instead.")
    }

    // MARK: Entry point (blocking — call on a background queue)

    static func process(downloadedFile: URL, job: DownloadJob) -> InstallResult {
        setQuarantine(downloadedFile)
        let ext = downloadedFile.pathExtension.lowercased()
        switch ext {
        case "dmg":
            return installDMG(downloadedFile, job: job)
        case "zip":
            return installZIP(downloadedFile, job: job)
        case "pkg", "mpkg":
            return installPKG(downloadedFile, job: job)
        default:
            NSWorkspace.shared.activateFileViewerSelecting([downloadedFile])
            return .revealed(downloadedFile)
        }
    }
}

// MARK: - Download manager

final class DownloadManager: NSObject, URLSessionDownloadDelegate {
    static let shared = DownloadManager()

    private(set) var jobs: [DownloadJob] = []
    /// Bytes downloaded in this launch (live aggregate speed source).
    private(set) var sessionBytes: Int64 = 0
    /// Current aggregate throughput across all active jobs, bytes/sec.
    private(set) var aggregateSpeed: Double = 0
    private var aggregateTimer: Timer?
    private var lastAggregateBytes: Int64 = 0
    private var queue: URLSession!
    private var queued: [DownloadJob] = []
    private var activeJobs: [DownloadJob] = []
    // Two installs may run at once; per-job unique Mounts/Extracts directories
    // keep DMG/ZIP work isolated from each other.
    private let installQueue = DispatchQueue(label: "com.macrefresh.fixed.install", attributes: .concurrent)
    private let installSlots = DispatchSemaphore(value: 2)
    private let mapLock = NSLock()
    private var taskMap: [Int: DownloadJob] = [:]
    private var stallTimer: Timer?
    var onChange: (() -> Void)?

    private var maxConcurrent: Int {
        let n = UserDefaults.standard.integer(forKey: Prefs.maxConcurrent)
        return max(1, min(6, n == 0 ? 3 : n))
    }

    override init() {
        super.init()
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 60
        cfg.timeoutIntervalForResource = 900
        cfg.httpMaximumConnectionsPerHost = 8
        let dq = OperationQueue()
        dq.maxConcurrentOperationCount = 8
        queue = URLSession(configuration: cfg, delegate: self, delegateQueue: dq)
        DispatchQueue.main.async { [weak self] in
            self?.startStallWatchdog()
            self?.startAggregateMeter()
        }
    }

    /// One-second aggregate throughput meter across every active download.
    private func startAggregateMeter() {
        aggregateTimer?.invalidate()
        aggregateTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            let now = self.sessionBytes
            self.aggregateSpeed = Double(now - self.lastAggregateBytes)
            self.lastAggregateBytes = now
        }
    }

    /// Fails downloads that make no progress for 75 seconds, so a dead
    /// connection can never leave a job stuck forever.
    private func startStallWatchdog() {
        stallTimer?.invalidate()
        stallTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            for job in self.jobs where job.state == .downloading {
                if Date().timeIntervalSince(job.lastBytesDate) > 75 {
                    job.lastBytesDate = Date()
                    job.task?.cancel()
                    self.handleFailure(job: job,
                                       message: "Download stalled (no data for 75s).")
                }
            }
        }
    }

    // MARK: Queue control

    func enqueue(_ job: DownloadJob) {
        DispatchQueue.main.async {
            let activeStates: [JobState] = [.queued, .downloading, .extracting, .installing, .openingInstaller]
            if !self.jobs.contains(where: { $0.url == job.url && activeStates.contains($0.state) }) {
                job.attempts += 1
                job.lastBytesDate = Date()
                job.message = "Queued"
                self.jobs.insert(job, at: 0)
                self.queued.append(job)
                self.pump()
                self.onChange?()
            }
        }
    }

    func retry(_ job: DownloadJob) {
        DispatchQueue.main.async {
            guard job.state == .failed || job.state == .canceled else { return }
            job.state = .queued
            job.progress = 0
            job.message = "Waiting to retry…"
            job.localURL = nil
            job.installedURL = nil
            job.task = nil
            job.attempts += 1
            job.lastBytesDate = Date()
            job.speedSamples.removeAll()
            if !self.jobs.contains(where: { $0 === job }) { self.jobs.insert(job, at: 0) }
            if !self.queued.contains(where: { $0 === job }) { self.queued.append(job) }
            self.onChange?()
            // Exponential backoff (2s, 4s, … capped at 20s) so an immediate
            // retry against a failing server doesn't burn attempts instantly.
            let delay = min(Double(job.attempts) * 2.0, 20.0)
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                guard job.state == .queued else { return }
                self.pump()
            }
        }
    }

    func pause(_ job: DownloadJob) {
        DispatchQueue.main.async {
            guard job.state == .downloading, let task = job.task else { return }
            job.state = .paused
            job.message = "Paused"
            task.cancel(byProducingResumeData: { data in job.resumeData = data })
            // Free the slot immediately; the cancel completion is ignored for
            // paused jobs in didCompleteWithError.
            self.activeJobs.removeAll { $0 === job }
            self.onChange?()
            self.pump()
        }
    }

    func resumeDownload(_ job: DownloadJob) {
        DispatchQueue.main.async {
            guard job.state == .paused else { return }
            job.state = .downloading
            job.message = "Resuming…"
            job.progress = max(job.progress, 0)
            job.lastBytesDate = Date()
            let task: URLSessionDownloadTask
            if let data = job.resumeData {
                task = self.queue.downloadTask(withResumeData: data)
            } else {
                task = self.queue.downloadTask(with: job.url)
            }
            job.resumeData = nil
            job.task = task
            self.activeJobs.append(job)
            self.mapLock.lock(); self.taskMap[task.taskIdentifier] = job; self.mapLock.unlock()
            task.resume()
            self.onChange?()
        }
    }

    func cancel(_ job: DownloadJob) {
        DispatchQueue.main.async {
            switch job.state {
            case .queued:
                self.queued.removeAll { $0 === job }
                self.activeJobs.removeAll { $0 === job }
                job.state = .canceled
                job.message = ""
                self.onChange?()
                self.pump()
            case .paused:
                // Nothing is transferring; cancel outright and free the slot.
                self.activeJobs.removeAll { $0 === job }
                job.resumeData = nil
                job.state = .canceled
                job.message = ""
                self.onChange?()
                self.pump()
            case .downloading:
                // Let the cancel completion move the job out of activeJobs so
                // the slot count can't briefly go negative.
                job.task?.cancel()
            default:
                job.task?.cancel()
            }
        }
    }

    func remove(_ job: DownloadJob) {
        DispatchQueue.main.async {
            self.jobs.removeAll { $0 === job }
            self.onChange?()
        }
    }

    /// Delete the downloaded installer file and drop the job from the list.
    func deleteInstaller(_ job: DownloadJob) {
        DispatchQueue.main.async {
            if let u = job.localURL, FileManager.default.fileExists(atPath: u.path) {
                try? FileManager.default.removeItem(at: u)
            }
            self.jobs.removeAll { $0 === job }
            self.onChange?()
        }
    }

    func clearFinished() {
        DispatchQueue.main.async {
            self.jobs.removeAll { $0.state == .done || $0.state == .canceled || $0.state == .failed }
            self.onChange?()
        }
    }

    /// Pause every in-progress download.
    func pauseAll() {
        DispatchQueue.main.async {
            for job in self.jobs where job.state == .downloading { self.pause(job) }
        }
    }

    /// Resume every paused download.
    func resumeAll() {
        DispatchQueue.main.async {
            for job in self.jobs where job.state == .paused { self.resumeDownload(job) }
        }
    }

    /// Cancel every queued, downloading or paused job (finished work is kept).
    func cancelAll() {
        DispatchQueue.main.async {
            for job in self.jobs where [.queued, .downloading, .paused].contains(job.state) {
                self.cancel(job)
            }
        }
    }

    /// Retry every failed job.
    func retryAllFailed() {
        DispatchQueue.main.async {
            for job in self.jobs where job.state == .failed { self.retry(job) }
        }
    }

    /// Decide whether a failed/stuck job should be retried automatically
    /// (respecting the configured attempt cap) or marked failed. A resumed
    /// download whose resume data is stale restarts from scratch.
    func handleFailure(job: DownloadJob, message: String) {
        DispatchQueue.main.async {
            let cap = max(1, UserDefaults.standard.integer(forKey: Prefs.maxDownloadAttempts))
            let auto = UserDefaults.standard.bool(forKey: Prefs.autoRetryDownloads)
            self.mapLock.lock()
            if let t = job.task { self.taskMap[t.taskIdentifier] = nil }
            job.task = nil
            self.mapLock.unlock()
            self.activeJobs.removeAll { $0 === job }
            if auto, job.attempts < cap {
                job.attempts += 1
                job.resumeData = nil
                job.state = .queued
                job.progress = 0
                job.message = "Retrying automatically (\(job.attempts)/\(cap))…"
                if !self.jobs.contains(where: { $0 === job }) { self.jobs.insert(job, at: 0) }
                if !self.queued.contains(where: { $0 === job }) { self.queued.append(job) }
                self.onChange?()
                let delay = min(Double(job.attempts) * 2.0, 20.0)
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    guard job.state == .queued else { return }
                    self.pump()
                }
            } else {
                job.state = .failed
                job.message = message
                self.onChange?()
                self.pump()
                self.notify(title: "\(job.kind) failed", body: job.title)
            }
        }
    }

    private func pump() {
        // Only actively-downloading jobs occupy download slots; installs run on
        // their own queue so they never block the next file from downloading.
        let downloadingCount = activeJobs.filter { $0.state == .downloading }.count
        var slots = maxConcurrent - downloadingCount
        while slots > 0, let job = queued.first {
            queued.removeFirst()
            activeJobs.append(job)
            slots -= 1
            job.state = .downloading
            job.message = "Connecting…"
            job.progress = 0
            job.lastBytesDate = Date()
            let task = queue.downloadTask(with: job.url)
            job.task = task
            mapLock.lock(); taskMap[task.taskIdentifier] = job; mapLock.unlock()
            task.resume()
        }
        onChange?()
    }

    private func job(for task: URLSessionTask) -> DownloadJob? {
        mapLock.lock(); defer { mapLock.unlock() }
        return taskMap[task.taskIdentifier]
    }

    // MARK: URLSession delegate

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        guard let job = job(for: downloadTask) else { return }
        let pct = totalBytesExpectedToWrite > 0
            ? Double(totalBytesWritten) / Double(totalBytesExpectedToWrite) : 0
        sessionBytes += bytesWritten
        let d = UserDefaults.standard
        let previous = (d.object(forKey: Prefs.sessionBytesKey) as? NSNumber)?.int64Value ?? 0
        d.set(previous + Int64(bytesWritten), forKey: Prefs.sessionBytesKey)
        DispatchQueue.main.async {
            job.progress = pct
            job.lastBytesDate = Date()
            // Keep a rolling 10-second sample window for speed / ETA.
            job.speedSamples.append((Date(), totalBytesWritten))
            job.speedSamples = job.speedSamples.filter { Date().timeIntervalSince($0.date) < 10 }
            var speed: Double = 0
            if let first = job.speedSamples.first, let last = job.speedSamples.last,
               last.date.timeIntervalSince(first.date) > 0.3 {
                speed = Double(last.bytes - first.bytes) / last.date.timeIntervalSince(first.date)
            }
            let done = ByteCountFormatter.string(fromByteCount: totalBytesWritten, countStyle: .file)
            var msg: String
            if totalBytesExpectedToWrite > 0 {
                let total = ByteCountFormatter.string(fromByteCount: totalBytesExpectedToWrite, countStyle: .file)
                msg = "\(done) / \(total)"
                if speed > 1 {
                    let speedText = ByteCountFormatter.string(fromByteCount: Int64(speed), countStyle: .binary) + "/s"
                    let remaining = Double(totalBytesExpectedToWrite - totalBytesWritten) / speed
                    if remaining > 1, remaining < 60 * 60 {
                        let eta = Int(remaining)
                        msg += " · \(speedText) · ETA \(eta / 60)m \(eta % 60)s"
                    } else {
                        msg += " · \(speedText)"
                    }
                }
            } else {
                msg = done
            }
            job.message = msg
            self.onChange?()
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        guard let job = self.job(for: downloadTask) else { return }
        mapLock.lock(); taskMap[downloadTask.taskIdentifier] = nil; mapLock.unlock()
        let suggested = downloadTask.response?.suggestedFilename ?? job.url.lastPathComponent
        let dest = Installer.downloadsDirectory().appendingPathComponent(suggested)
        try? FileManager.default.removeItem(at: dest)
        do {
            try FileManager.default.moveItem(at: location, to: dest)
        } catch {
            finishDownload(job: job, state: .failed, message: "Could not save download: \(error.localizedDescription)")
            return
        }
        job.localURL = dest

        if !job.installAfterDownload {
            // Download-only: keep the file and reveal it; no install and no
            // automatic cleanup.
            DispatchQueue.main.async {
                self.activeJobs.removeAll { $0 === job }
                NSWorkspace.shared.activateFileViewerSelecting([dest])
                HistoryStore.shared.record(HistoryEvent(
                    kind: .downloaded, appName: job.title, bundleID: job.bundleID ?? "",
                    fromVersion: "", toVersion: job.expectedVersion ?? "",
                    detail: dest.path, rollbackPath: nil))
                self.finishDownload(job: job, state: .done,
                                    message: "Downloaded \(suggested) (not installed)")
                self.pump()
            }
            return
        }

        DispatchQueue.main.async {
            // The download itself is finished — free its download slot right
            // away so the next file can start while this one installs.
            self.activeJobs.removeAll { $0 === job }
            job.state = .installing
            job.progress = -1
            job.message = "Waiting for install slot…"
            self.onChange?()
            self.pump()
        }

        // Installs run on a concurrent queue with two slots; per-job unique
        // Mounts/Extracts directories keep work isolated.
        installFromFile(job: job, file: dest, removeAfter: true)
    }

    /// Install a user-dropped local file (dmg/zip/pkg) directly, no download.
    func enqueueLocal(_ file: URL) {
        let job = DownloadJob(title: file.lastPathComponent, kind: "Install",
                              url: file, relaunch: false)
        job.attempts = 1
        job.localURL = file
        DispatchQueue.main.async {
            job.state = .installing
            job.progress = -1
            job.message = "Waiting for install slot…"
            self.jobs.insert(job, at: 0)
            self.onChange?()
        }
        // The dropped file stays where it is; never delete or quarantine it.
        installFromFile(job: job, file: file, removeAfter: false)
    }

    private func installFromFile(job: DownloadJob, file dest: URL, removeAfter: Bool) {
        let ext = dest.pathExtension.lowercased()
        let oldVersion = job.existingPath
            .flatMap { installedVersion(at: URL(fileURLWithPath: $0)) }
        installQueue.async {
            self.installSlots.wait()
            defer { self.installSlots.signal() }
            Installer.setJob(job, state: .installing,
                             message: (ext == "pkg" || ext == "mpkg") ? "Preparing package…" : "Installing…")
            let result = Installer.process(downloadedFile: dest, job: job)
            switch result {
            case .installed(let appURL, let rollback):
                let isApp = appURL.pathExtension.lowercased() == "app"
                job.installedURL = isApp ? appURL : nil
                if removeAfter, !UserDefaults.standard.bool(forKey: Prefs.keepInstallers) {
                    try? FileManager.default.removeItem(at: dest)
                    job.localURL = nil
                }
                var message = isApp ? "Installed \(appURL.lastPathComponent)" : "Package installed successfully"
                if isApp, let want = job.expectedVersion, !want.isEmpty {
                    let got = installedVersion(at: appURL) ?? ""
                    if !got.isEmpty, isUpdateAvailable(installed: got, latest: want) {
                        message = "Installed \(appURL.lastPathComponent) (\(got)); source listed \(want)"
                    }
                }
                if isApp,
                   UserDefaults.standard.object(forKey: Prefs.verifySignatures)
                    .map({ $0 as? Bool ?? true }) ?? true,
                   let problem = Installer.verifySignature(at: appURL) {
                    message += " · signature warning: \(problem)"
                }
                let newVersion = isApp ? (installedVersion(at: appURL) ?? job.expectedVersion ?? "") : ""
                HistoryStore.shared.record(HistoryEvent(
                    kind: job.kind == "Update" ? .updated : .installed,
                    appName: job.title, bundleID: job.bundleID ?? "",
                    fromVersion: oldVersion ?? "", toVersion: newVersion,
                    detail: appURL.path, rollbackPath: rollback?.path))
                self.finishDownload(job: job, state: .done, message: message) {
                    if job.relaunch, isApp {
                        DispatchQueue.main.async {
                            NSWorkspace.shared.openApplication(at: appURL, configuration: NSWorkspace.OpenConfiguration())
                        }
                    }
                    AppDelegate.shared?.postInstallRefresh()
                }
                self.notify(title: "\(job.kind) complete",
                            body: isApp ? "\(job.title) is up to date." : "\(job.title) package installed.")
            case .installerOpened:
                HistoryStore.shared.record(HistoryEvent(
                    kind: .installerOpened, appName: job.title, bundleID: job.bundleID ?? "",
                    fromVersion: "", toVersion: job.expectedVersion ?? "",
                    detail: dest.path, rollbackPath: nil))
                self.finishDownload(job: job, state: .openingInstaller,
                                    message: "Follow the Installer window to finish")
            case .revealed:
                HistoryStore.shared.record(HistoryEvent(
                    kind: .downloaded, appName: job.title, bundleID: job.bundleID ?? "",
                    fromVersion: "", toVersion: "", detail: dest.path, rollbackPath: nil))
                self.finishDownload(job: job, state: .done, message: "Downloaded (opened in Finder)")
            case .failed(let msg):
                HistoryStore.shared.record(HistoryEvent(
                    kind: .failed, appName: job.title, bundleID: job.bundleID ?? "",
                    fromVersion: oldVersion ?? "", toVersion: job.expectedVersion ?? "",
                    detail: msg, rollbackPath: nil))
                self.handleFailure(job: job, message: msg)
            }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let job = job(for: task), let error = error else { return }
        mapLock.lock(); taskMap[task.taskIdentifier] = nil; mapLock.unlock()
        // Pause intentionally cancels the task while keeping the job alive.
        if job.state == .paused { return }
        // The stall watchdog may have already classified this job.
        if [.failed, .canceled, .done].contains(job.state) { return }
        if (error as NSError).code == NSURLErrorCancelled {
            finishDownload(job: job, state: .canceled, message: "")
        } else {
            // Resume data can expire (server/file moved); handleFailure clears
            // it and restarts the download from scratch on retry.
            handleFailure(job: job, message: error.localizedDescription)
        }
    }

    private func finishDownload(job: DownloadJob, state: JobState, message: String, extra: (() -> Void)? = nil) {
        DispatchQueue.main.async {
            job.state = state
            job.message = message
            job.progress = state == .done ? 1 : job.progress
            self.activeJobs.removeAll { $0 === job }
            self.onChange?()
            extra?()
            self.pump()
        }
    }

    // MARK: Notifications

    /// True during the user's configured quiet hours (notifications suppressed).
    func inQuietHours(date: Date = Date()) -> Bool {
        let d = UserDefaults.standard
        let s = d.integer(forKey: Prefs.quietHoursStart)
        let e = d.integer(forKey: Prefs.quietHoursEnd)
        guard s >= 0, e >= 0, (0...23).contains(s), (0...23).contains(e) else { return false }
        let h = Calendar.current.component(.hour, from: date)
        if s == e { return h == s }
        if s < e { return h >= s && h < e }
        return h >= s || h < e   // overnight range, e.g. 22 → 7
    }

    private func notify(title: String, body: String) {
        guard UserDefaults.standard.bool(forKey: Prefs.notifications) else { return }
        guard !inQuietHours() else { return }
        guard let center = safeNotificationCenter() else { return }
        center.getNotificationSettings { settings in
            if settings.authorizationStatus == .notDetermined,
               !UserDefaults.standard.bool(forKey: Prefs.notifRequested) {
                UserDefaults.standard.set(true, forKey: Prefs.notifRequested)
                center.requestAuthorization(options: [.alert, .sound]) { _, _ in }
            }
            guard settings.authorizationStatus == .authorized ||
                    settings.authorizationStatus == .provisional else { return }
            let content = UNMutableNotificationContent()
            content.title = title
            content.body = body
            center.add(UNNotificationRequest(identifier: UUID().uuidString, content: content,
                                             trigger: nil), withCompletionHandler: nil)
        }
    }
}

/// Read CFBundleShortVersionString from an installed app bundle.
func installedVersion(at url: URL) -> String? {
    let plist = url.appendingPathComponent("Contents/Info.plist")
    guard let data = try? Data(contentsOf: plist),
          let obj = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any]
    else { return nil }
    return (obj["CFBundleShortVersionString"] as? String) ?? (obj["CFBundleVersion"] as? String)
}
