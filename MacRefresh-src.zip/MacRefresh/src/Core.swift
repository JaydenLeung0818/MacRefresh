// Core.swift — models, scanning, update sources (Sparkle + Homebrew), version compare
import Cocoa

/// App version, kept in sync with the Info.plist written by build.sh.
let MacRefreshVersion = "1.0.0"

// MARK: - Machine architecture

enum Arch {
    static let isIntel: Bool = machine() == "x86_64"

    static func machine() -> String {
        var size = 0
        sysctlbyname("hw.machine", nil, &size, nil, 0)
        var machine = [CChar](repeating: 0, count: size)
        sysctlbyname("hw.machine", &machine, &size, nil, 0)
        return String(cString: machine)
    }
}

// MARK: - Version normalization & comparison

/// Canonicalize a raw version string before any comparison. Benign wrappers
/// must never make two identical releases look different — in particular a
/// leading "v" ("v1.63" vs "1.63").
/// Steps: trim; strip surrounding brackets/quotes; strip a leading "version"
/// word; strip one leading v/V followed by a digit; underscores → dots;
/// remove internal whitespace; collapse/trim stray dots.
func normalizeVersion(_ s: String) -> String {
    var t = s.trimmingCharacters(in: .whitespacesAndNewlines)

    // Peel off matched surrounding wrappers: (…), […], {…}, <…>, "…", '…'
    let wrappers: [(Character, Character)] =
        [("(", ")"), ("[", "]"), ("{", "}"), ("<", ">"), ("\"", "\""), ("'", "'")]
    var changed = true
    while changed, t.count >= 2 {
        changed = false
        for (open, close) in wrappers where t.first == open && t.last == close {
            t = String(t.dropFirst().dropLast())
                .trimmingCharacters(in: .whitespacesAndNewlines)
            changed = true
        }
    }

    // Leading word "version" ("Version 1.2", "version: 1.2", "version-1.2")
    if let r = t.range(of: #"^version[\s:._-]*"#,
                        options: [.regularExpression, .caseInsensitive]) {
        t = String(t[r.upperBound...])
    }

    // A single leading v/V immediately followed by a digit ("v1.63" → "1.63")
    if let f = t.first, f == "v" || f == "V", t.count >= 2 {
        let next = t.index(after: t.startIndex)
        if t[next].isNumber { t = String(t.dropFirst()) }
    }

    // Underscores separating version parts ("1_0_0" → "1.0.0")
    t = t.replacingOccurrences(of: "_", with: ".")
    // Spaces inside a version ("1.0 beta 2" → "1.0beta2")
    t = t.replacingOccurrences(of: " ", with: "")
    // Collapse repeated dots and trim stray leading/trailing dots
    while t.contains("..") { t = t.replacingOccurrences(of: "..", with: ".") }
    t = t.trimmingCharacters(in: CharacterSet(charactersIn: "."))
    return t
}

/// Strict plausibility gate: a usable version must, after normalization, start
/// with a digit, contain at least one digit, be short, and not be a URL. Junk
/// strings are ignored instead of being offered as updates.
func isPlausibleVersion(_ s: String) -> Bool {
    let t = normalizeVersion(s)
    guard !t.isEmpty, t.count <= 32 else { return false }
    guard t.first?.isNumber == true else { return false }
    guard t.contains(where: { $0.isNumber }) else { return false }
    if t.lowercased().contains("://") { return false }
    return true
}

/// Rank common pre-release keywords, oldest first:
/// dev/snapshot < alpha/a < beta/b < preview/pre < rc/cr < release/rel/stable/final
func prereleaseRank(_ suffix: String) -> Int? {
    let s = suffix.lowercased()
    let keys: [(String, Int)] = [
        ("dev", 0), ("snapshot", 0),
        ("alpha", 1), ("a", 1),
        ("beta", 2), ("b", 2),
        ("preview", 3), ("pre", 3),
        ("rc", 4), ("cr", 4),
        ("release", 5), ("rel", 5), ("stable", 5), ("final", 5)
    ]
    for (k, v) in keys where s.hasPrefix(k) {
        if s.count == k.count { return v }
        let next = s[s.index(s.startIndex, offsetBy: k.count)]
        if !next.isLetter { return v }   // keyword must end at a non-letter
    }
    return nil
}

func parseVersionComponent(_ s: String) -> (num: Int, suffix: String) {
    var numStr = ""
    var suffix = ""
    for ch in s {
        if ch.isNumber && suffix.isEmpty { numStr.append(ch) }
        else { suffix.append(ch) }
    }
    return (Int(numStr) ?? 0, suffix)
}

/// Natural-order comparison for pre-release suffixes: embedded numbers compare
/// numerically ("beta10" > "beta9") instead of lexicographically. Letters are
/// case-insensitive ("Beta10" == "beta10").
func naturalCompare(_ a: String, _ b: String) -> ComparisonResult {
    func pieces(_ s: String) -> [String] {
        var out: [String] = []
        var cur = ""
        var curDigits = false
        for ch in s {
            let d = ch.isNumber
            if cur.isEmpty || d == curDigits {
                cur.append(ch)
            } else {
                out.append(cur)
                cur = String(ch)
            }
            curDigits = d
        }
        if !cur.isEmpty { out.append(cur) }
        return out
    }
    let pa = pieces(a.lowercased()), pb = pieces(b.lowercased())
    for i in 0..<max(pa.count, pb.count) {
        let x = i < pa.count ? pa[i] : ""
        let y = i < pb.count ? pb[i] : ""
        let xNum = !x.isEmpty && x.allSatisfy { $0.isNumber }
        let yNum = !y.isEmpty && y.allSatisfy { $0.isNumber }
        if xNum && yNum {
            let nx = Int(x) ?? 0, ny = Int(y) ?? 0
            if nx != ny { return nx < ny ? .orderedAscending : .orderedDescending }
        } else {
            if x != y { return x < y ? .orderedAscending : .orderedDescending }
        }
    }
    return .orderedSame
}

func compareVersions(_ a: String, _ b: String) -> ComparisonResult {
    let ca = normalizeVersion(a)
    let cb = normalizeVersion(b)
    if ca.isEmpty && cb.isEmpty { return .orderedSame }
    if ca.isEmpty { return .orderedAscending }
    if cb.isEmpty { return .orderedDescending }
    let sa = ca.split(separator: ".").map(String.init)
    let sb = cb.split(separator: ".").map(String.init)
    let count = max(sa.count, sb.count)
    for i in 0..<count {
        let pa: (num: Int, suffix: String) = i < sa.count ? parseVersionComponent(sa[i]) : (num: 0, suffix: "")
        let pb: (num: Int, suffix: String) = i < sb.count ? parseVersionComponent(sb[i]) : (num: 0, suffix: "")
        if pa.num != pb.num { return pa.num < pb.num ? .orderedAscending : .orderedDescending }
        if pa.suffix != pb.suffix {
            if pa.suffix.isEmpty { return .orderedDescending }
            if pb.suffix.isEmpty { return .orderedAscending }
            // Keyword-aware ordering (alpha < beta < rc < release)
            let ra = prereleaseRank(pa.suffix), rb = prereleaseRank(pb.suffix)
            if let ra = ra, let rb = rb, ra != rb {
                return ra < rb ? .orderedAscending : .orderedDescending
            }
            let nat = naturalCompare(pa.suffix, pb.suffix)
            if nat != .orderedSame { return nat }
        }
    }
    return .orderedSame
}

/// Some sources append build numbers to a marketing version, e.g. CapCut
/// `9.4.1.4574`, Microsoft Office `16.113.26091433`, or `9.5.1.2.4`. When the
/// installed version is a strict numeric prefix of the latest one, the two
/// describe the same release and must not be flagged as an update forever.
/// Real patch updates (1.0 → 1.0.1) keep their short-tail shape and are still
/// detected.
func isBuildNumberEquivalent(installed: String, latest: String) -> Bool {
    let a = normalizeVersion(installed).split(separator: ".").map(String.init)
    let b = normalizeVersion(latest).split(separator: ".").map(String.init)
    guard a.count >= 2, b.count > a.count else { return false }
    for i in 0..<a.count {
        let pa = parseVersionComponent(a[i])
        let pb = parseVersionComponent(b[i])
        if pa.num != pb.num || pa.suffix != pb.suffix { return false }
    }
    let extras = b[a.count...]
    let allNumeric = extras.allSatisfy {
        $0.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil
    }
    guard allNumeric else { return false }
    if a.count >= 3 {
        // 3+-component marketing version: a numeric-only tail is a build number.
        return true
    }
    // 2-component versions (e.g. Office "16.113" + build "26091433"): only a
    // long (4+ digit) numeric tail is a build number, so genuine patches such
    // as 1.0 -> 1.0.1 continue to be reported as updates.
    return extras.joined().filter { $0.isNumber }.count >= 4
}

/// True when a version string carries a pre-release marker
/// (alpha/beta/rc/pre/preview/dev/snapshot/nightly/canary). "2.8-rc.2" and
/// "1.2b3" are detected; the leading "-" / "." separators are stripped.
func isPrereleaseVersion(_ s: String) -> Bool {
    let t = normalizeVersion(s).lowercased()
    let parts = t.components(separatedBy: CharacterSet(charactersIn: ".-"))
    for part in parts {
        var idx = part.startIndex
        while idx < part.endIndex, part[idx].isNumber { idx = part.index(after: idx) }
        var suf = String(part[idx..<part.endIndex])
        suf = suf.trimmingCharacters(in: CharacterSet(charactersIn: " _-"))
        if !suf.isEmpty, prereleaseRank(suf) != nil { return true }
        if suf.hasPrefix("nightly") || suf.hasPrefix("canary") { return true }
    }
    return false
}

/// True for placeholder versions self-updating apps put in their Info.plist
/// (Roblox, some Electron apps ship "0.0.0" or "0.0.0.1"). Such versions do
/// not describe a real release and cannot be compared, so they never produce
/// an update offer.
func isPlaceholderInstalledVersion(_ s: String) -> Bool {
    let t = normalizeVersion(s)
    let nums = t.split(separator: ".").map { parseVersionComponent(String($0)).num }
    guard nums.count >= 3 else { return false }
    // major, minor and patch all zero (any trailing build number is ignored).
    return nums[0] == 0 && nums[1] == 0 && nums[2] == 0
}

/// True when `latest` is a genuinely newer version than `installed` —
/// comparison-aware of the build-number suffix rule above and the strict
/// normalization (so "v1.63" → "1.63" is never an update).
/// Stable users are never pushed a pre-release build (beta/rc), and apps with
/// placeholder versions (0.0.0.x) are not compared at all.
func isUpdateAvailable(installed: String, latest: String) -> Bool {
    guard isPlausibleVersion(latest) else { return false }
    guard !isPlaceholderInstalledVersion(installed) else { return false }
    if isPrereleaseVersion(latest) && !isPrereleaseVersion(installed) { return false }
    guard compareVersions(installed, latest) == .orderedAscending else { return false }
    return !isBuildNumberEquivalent(installed: installed, latest: latest)
}

// MARK: - macOS compatibility gating

/// Parse "18.0", "10.15.7", "14" into a 3-tuple; nil when no leading number.
func parseOSVersion(_ str: String) -> (Int, Int, Int)? {
    let comps = str.split(separator: ".", omittingEmptySubsequences: false).map { comp -> Int? in
        Int(comp.prefix(while: { $0.isNumber }))
    }
    let nums = comps.compactMap { $0 }
    guard !nums.isEmpty, let first = comps[0] else { return nil }
    _ = first
    var p = nums
    while p.count < 3 { p.append(0) }
    return (p[0], p[1], p[2])
}

/// True when the running macOS is at least the given version. Unknown/garbage
/// requirements are treated as satisfied so they never hide a real update.
func isOSVersionAtLeast(_ minimum: String) -> Bool {
    guard let m = parseOSVersion(minimum) else { return true }
    let c = ProcessInfo.processInfo.operatingSystemVersion
    let cur = (c.majorVersion, c.minorVersion, c.patchVersion)
    if cur.0 != m.0 { return cur.0 > m.0 }
    if cur.1 != m.1 { return cur.1 > m.1 }
    return cur.2 >= m.2
}

/// Homebrew cask macOS release symbols -> version numbers.
let macOSSymbolVersions: [String: String] = [
    "cheetah": "10.0", "puma": "10.1", "jaguar": "10.2", "panther": "10.3",
    "tiger": "10.4", "leopard": "10.5", "snow_leopard": "10.6", "lion": "10.7",
    "mountain_lion": "10.8", "mavericks": "10.9", "yosemite": "10.10",
    "el_capitan": "10.11", "sierra": "10.12", "high_sierra": "10.13",
    "mojave": "10.14", "catalina": "10.15", "big_sur": "11",
    "monterey": "12", "ventura": "13", "sonoma": "14", "sequoia": "15",
    "tahoe": "26"
]

/// Resolve cask `depends_on "macos" => [">= :ventura"]` into the strongest
/// minimum macOS version string, or nil when no lower-bound requirement exists.
func caskMacOSRequirement(_ dependsOn: Any?) -> String? {
    guard let d = dependsOn as? [String: Any],
          let arr = d["macos"] as? [String] else { return nil }
    var best: (Int, Int, Int)? = nil
    for raw in arr {
        let str = raw.trimmingCharacters(in: .whitespaces)
        var r = str
        if let rng = str.range(of: ">=") { r = String(str[rng.upperBound...]) }
        else if let rng = str.range(of: ">") { r = String(str[rng.upperBound...]) }
        else { continue }
        r = r.trimmingCharacters(in: .whitespaces)
        if r.hasPrefix(":") { r = String(r.dropFirst()) }
        let resolved = macOSSymbolVersions[r] ?? r
        guard let t = parseOSVersion(resolved) else { continue }
        if let b = best {
            if (t.0, t.1, t.2) > (b.0, b.1, b.2) { best = t }
        } else { best = t }
    }
    guard let b = best else { return nil }
    return "\(b.0).\(b.1).\(b.2)"
}

// MARK: - Preferences

enum Prefs {
    static let autoCheck = "autoCheckOnLaunch"
    static let scanHome = "scanHomeApplications"
    static let keepInstallers = "keepInstallers"
    static let showIgnored = "showIgnored"
    static let ignored = "ignoredBundleIDs"
    static let lastCheck = "lastCheckDate"
    static let showStatusItem = "showStatusItem"
    static let showDockIcon = "showDockIcon"
    static let notifications = "finishNotifications"
    static let maxConcurrent = "maxConcurrentDownloads"
    static let silentPKG = "silentPackageInstalls"
    static let checkInterval = "scheduledCheckIntervalHours"
    static let relaunchAfterUpdate = "relaunchAppsAfterUpdate"
    static let notifRequested = "notificationPermissionRequested"
    static let seenVersion = "lastSeenAppVersion"
    static let rememberSection = "rememberLastSection"
    static let lastSection = "lastOpenSection"
    static let rememberWindowSize = "rememberWindowSize"
    static let windowWidth = "windowWidth"
    static let windowHeight = "windowHeight"
    static let scanDesktop = "scanDesktopFolder"
    static let scanDownloads = "scanDownloadsFolder"
    static let customSourcesKey = "customUpdateSources"
    static let extraFoldersKey = "extraScanFolders"
    static let launchAtLogin = "launchAtLogin"
    static let updatesDirectOnly = "updatesDirectOnly"
    static let updatesSortKey = "updatesSortKey"
    static let updatesSortAsc = "updatesSortAsc"
    static let verifySignatures = "verifySignatures"
    static let legacyMigrationDone = "legacyMigrationDone"

    // v1.0.1 additions
    static let appearanceMode = "appearanceMode"                 // system | light | dark
    static let confirmUninstall = "confirmUninstall"
    static let confirmDuplicateTrash = "confirmDuplicateTrash"
    static let autoRetryDownloads = "autoRetryDownloads"
    static let maxDownloadAttempts = "maxDownloadAttempts"
    static let customDownloadsFolder = "customDownloadsFolder"
    static let showDockBadge = "showDockBadge"
    static let statusItemClickOpens = "statusItemClickOpensWindow"
    static let quietHoursStart = "quietHoursStart"               // hour 0...23, -1 = off
    static let quietHoursEnd = "quietHoursEnd"
    static let buildEquivalence = "buildNumberEquivalence"
    static let skippedVersionsKey = "skippedVersions"            // [bundleID: version]
    static let shopFavoritesKey = "shopFavorites"                // [caskToken]
    static let extraScanAppsKey = "extraScanApps"                // [path to a single .app]
    static let rollbackRetentionDays = "rollbackRetentionDays"
    static let onboardingDoneV1 = "onboardingDoneV1"
    static let snoozeUntil = "snoozeUntil"                       // ISO date, empty = none
    static let installedSortKey = "installedSortKey"
    static let installedSortAsc = "installedSortAsc"
    static let updatesSourceFilter = "updatesSourceFilter"
    static let installedKindFilter = "installedKindFilter"
    static let sessionBytesKey = "sessionDownloadedBytes"

    static func registerDefaults() {
        UserDefaults.standard.register(defaults: [
            autoCheck: true,
            scanHome: true,
            keepInstallers: false,
            showIgnored: false,
            ignored: [String](),
            showStatusItem: true,
            showDockIcon: true,
            notifications: true,
            maxConcurrent: 3,
            silentPKG: true,
            checkInterval: 24,
            relaunchAfterUpdate: true,
            notifRequested: false,
            seenVersion: "",
            rememberSection: true,
            lastSection: "overview",
            rememberWindowSize: true,
            windowWidth: 1120,
            windowHeight: 740,
            scanDesktop: true,
            scanDownloads: false,
            customSourcesKey: [String: String](),
            extraFoldersKey: [String](),
            launchAtLogin: false,
            updatesDirectOnly: false,
            updatesSortKey: "app",
            updatesSortAsc: true,
            verifySignatures: true,
            // v1.0.1 defaults
            appearanceMode: "system",
            confirmUninstall: true,
            confirmDuplicateTrash: true,
            autoRetryDownloads: true,
            maxDownloadAttempts: 3,
            customDownloadsFolder: "",
            showDockBadge: true,
            statusItemClickOpens: false,
            quietHoursStart: -1,
            quietHoursEnd: -1,
            buildEquivalence: true,
            skippedVersionsKey: [String: String](),
            shopFavoritesKey: [String](),
            extraScanAppsKey: [String](),
            rollbackRetentionDays: 7,
            onboardingDoneV1: false,
            snoozeUntil: "",
            installedSortKey: "app",
            installedSortAsc: true,
            updatesSourceFilter: "all",
            installedKindFilter: "all",
            sessionBytesKey: 0
        ])
    }
    static var ignoredIDs: [String] {
        get { UserDefaults.standard.stringArray(forKey: ignored) ?? [] }
        set { UserDefaults.standard.set(newValue, forKey: ignored) }
    }
    static var customSources: [String: String] {
        get { UserDefaults.standard.dictionary(forKey: customSourcesKey) as? [String: String] ?? [:] }
        set { UserDefaults.standard.set(newValue, forKey: customSourcesKey) }
    }
    static var extraFolders: [String] {
        get { UserDefaults.standard.stringArray(forKey: extraFoldersKey) ?? [] }
        set { UserDefaults.standard.set(newValue, forKey: extraFoldersKey) }
    }
    static var extraScanApps: [String] {
        get { UserDefaults.standard.stringArray(forKey: extraScanAppsKey) ?? [] }
        set { UserDefaults.standard.set(newValue, forKey: extraScanAppsKey) }
    }
    static var skippedVersions: [String: String] {
        get { UserDefaults.standard.dictionary(forKey: skippedVersionsKey) as? [String: String] ?? [:] }
        set { UserDefaults.standard.set(newValue, forKey: skippedVersionsKey) }
    }
    static var shopFavorites: [String] {
        get { UserDefaults.standard.stringArray(forKey: shopFavoritesKey) ?? [] }
        set { UserDefaults.standard.set(newValue, forKey: shopFavoritesKey) }
    }
}

// MARK: - Models

enum AppStatus: Int {
    case pending, upToDate, update, unknown
}

struct AppRow {
    var name: String
    var bundleID: String
    var installed: String
    var path: String
    var feedURL: String?
    var homepage: String?
    var downloadURL: String?
    var releaseNotesURL: String?
    var latest: String?
    var source: String
    var note: String
    var status: AppStatus
    var caskToken: String?
    var ignored: Bool = false
    var isAppStore: Bool = false
    var appStoreURL: String?
    var githubRepo: String?
    /// True when another installed copy of the same bundle id exists.
    var isDuplicate: Bool = false
    /// Minimum macOS required by the latest version, when this Mac can't run it.
    var requiresOS: String? = nil
    /// v1.0.1: last modification date of the bundle on disk.
    var modifiedDate: Date? = nil
    /// v1.0.1: carries a com.apple.quarantine attribute (downloaded, never launched).
    var quarantined: Bool = false
    /// v1.0.1: "signed", "adhoc" or "unsigned"; filled lazily by SignatureCache.
    var signatureSummary: String = ""
    /// v1.0.1: signing team identifier, when available.
    var teamID: String? = nil

    func bestPageURL() -> URL? {
        for candidate in [appStoreURL, homepage, feedURL] {
            if let s = candidate, let u = URL(string: s), u.scheme != nil { return u }
        }
        return nil
    }
}

func statusText(_ s: AppStatus) -> String {
    switch s {
    case .pending: return "…"
    case .upToDate: return "Up to date"
    case .update: return "Update available"
    case .unknown: return "No source"
    }
}

struct Cask {
    let token: String
    let names: [String]
    let version: String
    /// Marketing version with any comma-separated build part removed
    /// ("4.2.1,20260531.1" → "4.2.1"); used for version comparison.
    let marketingVersion: String
    let homepage: String
    let desc: String
    let url: String
    let appArtifacts: [String]
    let appTargets: [String]
    let quitIDs: [String]
    /// Minimum macOS required, when the cask declares one (depends_on macos).
    let minOS: String?
}

// MARK: - Scanning installed apps

func scanForApps(includeHome: Bool = true) -> [AppRow] {
    var result: [AppRow] = []
    let home = NSHomeDirectory()
    var dirs = ["/Applications"]
    if includeHome { dirs.append(home + "/Applications") }
    if UserDefaults.standard.bool(forKey: Prefs.scanDesktop) { dirs.append(home + "/Desktop") }
    if UserDefaults.standard.bool(forKey: Prefs.scanDownloads) { dirs.append(home + "/Downloads") }
    for extra in Prefs.extraFolders {
        if FileManager.default.fileExists(atPath: extra) { dirs.append(extra) }
    }
    for dir in dirs {
        scanDirectory(dir, depth: 0, into: &result)
    }
    // Individually-added apps (even if their folder is not scanned).
    let knownPaths = Set(result.map { $0.path })
    for single in Prefs.extraScanApps {
        if (single as NSString).pathExtension.lowercased() == "app",
           FileManager.default.fileExists(atPath: single),
           !knownPaths.contains(single),
           let row = readAppBundle(at: single) {
            result.append(row)
        }
    }
    let ignoredSet = Set(Prefs.ignoredIDs)
    let dupes = duplicateBundleIDs(result)
    for i in result.indices {
        result[i].ignored = ignoredSet.contains(result[i].bundleID)
        result[i].isDuplicate = dupes.contains(result[i].bundleID)
    }
    // Sort by name, then path, so duplicate copies sit adjacent.
    result.sort {
        let c = $0.name.localizedCaseInsensitiveCompare($1.name)
        if c == .orderedSame {
            return $0.path.localizedStandardCompare($1.path) == .orderedAscending
        }
        return c == .orderedAscending
    }
    return result
}

/// The public 1.0.0 release uses a single bundle identifier and data domain.
/// Earlier private builds are not migrated in the public release.
func migrateLegacyPreferences() {
    let d = UserDefaults.standard
    guard !d.bool(forKey: Prefs.legacyMigrationDone) else { return }
    d.set(true, forKey: Prefs.legacyMigrationDone)
}

/// Bundle identifiers present at two or more distinct paths.
func duplicateBundleIDs(_ rows: [AppRow]) -> Set<String> {
    var paths: [String: Set<String>] = [:]
    for r in rows { paths[r.bundleID, default: []].insert(r.path) }
    return Set(paths.filter { $0.value.count > 1 }.keys)
}

/// Rank install locations: /Applications preferred, then ~/Applications.
func copyLocationRank(_ path: String) -> Int {
    if path.hasPrefix("/Applications/") { return 2 }
    if path.hasPrefix(NSHomeDirectory() + "/Applications/") { return 1 }
    return 0
}

/// Group duplicate copies by bundle id; each group is sorted with the primary
/// copy first (preferred location, then highest version). Pure and testable.
func duplicateGroups(in rows: [AppRow]) -> [[AppRow]] {
    var dict: [String: [AppRow]] = [:]
    for r in rows where r.isDuplicate { dict[r.bundleID, default: []].append(r) }
    return dict.values.map { group in
        group.sorted { a, b in
            let ra = copyLocationRank(a.path), rb = copyLocationRank(b.path)
            if ra != rb { return ra > rb }
            return compareVersions(a.installed, b.installed) == .orderedDescending
        }
    }
}

func scanDirectory(_ dir: String, depth: Int, into result: inout [AppRow]) {
    guard depth <= 2 else { return }
    let fm = FileManager.default
    guard let items = try? fm.contentsOfDirectory(atPath: dir) else { return }
    for item in items {
        if item.hasPrefix(".") { continue }
        let full = (dir as NSString).appendingPathComponent(item)
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: full, isDirectory: &isDir) else { continue }
        if item.hasSuffix(".app") && isDir.boolValue {
            // Keep every copy; duplicates are flagged after the scan instead
            // of silently dropped (the old seen-set hid the second WhatsApp).
            if let row = readAppBundle(at: full), !row.bundleID.hasPrefix("com.apple.") {
                result.append(row)
            }
        } else if isDir.boolValue && !item.hasSuffix(".app") {
            if depth == 0 {
                let low = item.lowercased()
                if ["node_modules", "library", "system volume information",
                    "$recycle.bin", ".trash", "trash"].contains(low) { continue }
            }
            scanDirectory(full, depth: depth + 1, into: &result)
        }
    }
}

/// Returns true when the file/bundle carries a named extended attribute (e.g.
/// `com.apple.quarantine`). Uses the xattr C API directly because
/// `URLResourceKey.extendedAttributesKey` does not exist on macOS.
func hasExtendedAttribute(_ name: String, at path: String) -> Bool {
    let size = getxattr(path, name, nil, 0, 0, 0)
    return size >= 0
}

func readAppBundle(at path: String) -> AppRow? {
    let plistPath = (path as NSString).appendingPathComponent("Contents/Info.plist")
    guard let data = FileManager.default.contents(atPath: plistPath),
          let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
          let bundleID = plist["CFBundleIdentifier"] as? String, !bundleID.isEmpty else { return nil }
    let name = (plist["CFBundleDisplayName"] as? String)
        ?? (plist["CFBundleName"] as? String)
        ?? (path as NSString).lastPathComponent.replacingOccurrences(of: ".app", with: "")
    let version = (plist["CFBundleShortVersionString"] as? String)
        ?? (plist["CFBundleVersion"] as? String) ?? ""
    let feedURL = plist["SUFeedURL"] as? String
    // App Store apps carry a receipt bundle; they can only update through the App Store.
    let receipt = (path as NSString).appendingPathComponent("Contents/_MASReceipt/receipt")
    let isAppStore = FileManager.default.fileExists(atPath: receipt)
    // Electron-builder apps ship app-update.yml describing a GitHub/generic feed.
    let yml = (path as NSString).appendingPathComponent("Contents/Resources/app-update.yml")
    var githubRepo = FileManager.default.fileExists(atPath: yml)
        ? parseElectronUpdateYML(FileManager.default.contents(atPath: yml) ?? Data()) : nil
    // Fallback: discover the repository from app.asar's package.json.
    if githubRepo == nil { githubRepo = extractAsarRepository(at: path) }
    // Modification date and quarantine flag (cheap metadata; no spawning).
    let appURL = URL(fileURLWithPath: path)
    let modified = (try? appURL.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate
    let quarantined = hasExtendedAttribute("com.apple.quarantine", at: path)
    return AppRow(
        name: name, bundleID: bundleID, installed: version, path: path,
        feedURL: feedURL, homepage: nil, downloadURL: nil, releaseNotesURL: nil,
        latest: nil, source: isAppStore ? "App Store" : (feedURL != nil ? "Sparkle feed" : "—"),
        note: "", status: .pending, caskToken: nil, ignored: false,
        isAppStore: isAppStore, appStoreURL: nil, githubRepo: githubRepo,
        modifiedDate: modified, quarantined: quarantined
    )
}

/// Minimal parser for Electron-builder's `app-update.yml` — extracts a
/// `provider: github` owner/repo pair. No YAML library needed for this subset.
func parseElectronUpdateYML(_ data: Data) -> String? {
    guard let s = String(data: data, encoding: .utf8) else { return nil }
    var provider = "", owner = "", repo = ""
    func unquote(_ v: String) -> String {
        var v = v.trimmingCharacters(in: .whitespaces)
        if let f = v.first, f == "'" || f == "\"" {
            v = String(v.dropFirst())
            if let q = v.firstIndex(where: { $0 == "'" || $0 == "\"" }) { v = String(v[..<q]) }
        }
        return v
    }
    for raw in s.split(separator: "\n") {
        let line = raw.trimmingCharacters(in: .whitespaces)
        if line.isEmpty || line.hasPrefix("#") { continue }
        guard let ci = line.firstIndex(of: ":") else { continue }
        let key = String(line[..<ci]).trimmingCharacters(in: .whitespaces).lowercased()
        let val = unquote(String(line[line.index(after: ci)...]))
        if key == "provider" { provider = val.lowercased() }
        if key == "owner" { owner = val }
        if key == "repo" { repo = val }
    }
    if provider == "github", !owner.isEmpty, !repo.isEmpty { return "\(owner)/\(repo)" }
    return nil
}

// MARK: - Electron app.asar repository source

/// Read a little-endian UInt32 from Data at `offset`, or nil out of range.
func readUInt32LE(_ data: Data, _ offset: Int) -> UInt32? {
    guard offset >= 0, offset + 4 <= data.count else { return nil }
    var v: UInt32 = 0
    let copied = data.withUnsafeBytes { raw -> Int in
        guard let base = raw.bindMemory(to: UInt8.self).baseAddress else { return 0 }
        memcpy(&v, base.advanced(by: offset), 4)
        return 4
    }
    _ = copied
    return UInt32(littleEndian: v)
}

/// Normalize the many package.json repository shapes into an "owner/repo"
/// GitHub slug, or nil (including non-GitHub hosts). Pure and testable.
func repositoryStringToSlug(_ raw: String) -> String? {
    let original = raw.trimmingCharacters(in: .whitespacesAndNewlines)
    guard original.lowercased().contains("github") else { return nil }
    var s = original
    if let r = s.range(of: "github:") { s = String(s[r.upperBound...]) }
    if s.hasPrefix("git+") { s = String(s.dropFirst(4)) }
    if s.hasPrefix("git@github.com:") {
        s = String(s.dropFirst("git@github.com:".count))
    } else if let r = s.range(of: "github.com/") {
        s = String(s[r.upperBound...])
        if s.hasPrefix(":") { s = String(s.dropFirst()) }
    }
    if s.hasSuffix(".git") { s = String(s.dropLast(4)) }
    if let r = s.firstIndex(of: "#") { s = String(s[..<r]) }
    if let r = s.firstIndex(of: "?") { s = String(s[..<r]) }
    let parts = s.split(separator: "/", maxSplits: 1, omittingEmptySubsequences: false)
    guard parts.count == 2 else { return nil }
    let user = String(parts[0]), repo = String(parts[1])
    guard !user.isEmpty, !repo.isEmpty, !repo.contains(" "), !repo.contains("/") else { return nil }
    return "\(user)/\(repo)"
}

/// Fallback GitHub discovery for Electron apps that ship no app-update.yml:
/// parse the asar header, read package.json, and extract its repository.
/// Bounded reads only; returns nil for anything unexpected.
func extractAsarRepository(at appPath: String) -> String? {
    let asarPath = appPath + "/Contents/Resources/app.asar"
    guard let fh = try? FileHandle(forReadingFrom: URL(fileURLWithPath: asarPath)) else { return nil }
    defer { try? fh.close() }
    let preamble = fh.readData(ofLength: 16)
    guard let jsonLen32 = readUInt32LE(preamble, 12) else { return nil }
    let jsonLen = Int(jsonLen32)
    guard jsonLen > 0, jsonLen < 16_000_000 else { return nil }
    let padded = (jsonLen + 3) & ~3
    let headerRest = fh.readData(ofLength: padded)
    guard headerRest.count >= jsonLen else { return nil }
    let jsonData = headerRest.subdata(in: 0..<jsonLen)
    guard let header = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any],
          let files = header["files"] as? [String: Any],
          let pkg = files["package.json"] as? [String: Any],
          let size = pkg["size"] as? Int, size < 2_000_000 else { return nil }
    var pkgData: Data?
    if let off = pkg["offset"] as? String, let offI = Int(off), offI < 8_000_000 {
        // File handle sits at the data area start (16 + padded header).
        if offI > 0 { _ = fh.readData(ofLength: offI) }
        pkgData = fh.readData(ofLength: size)
    } else if (pkg["unpacked"] as? Bool) == true {
        let u = appPath + "/Contents/Resources/app.asar.unpacked/package.json"
        pkgData = FileManager.default.contents(atPath: u)
    }
    guard let d = pkgData,
          let obj = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return nil }
    let raw: String?
    if let r = obj["repository"] as? String { raw = r }
    else if let r = obj["repository"] as? [String: Any], let u = r["url"] as? String { raw = u }
    else { raw = nil }
    guard let found = raw else { return nil }
    return repositoryStringToSlug(found)
}

// MARK: - Squirrel.Mac JSON update feeds

/// Parse a Squirrel.Mac-style JSON feed — an object or array of objects with
/// "name" (version) and optional "url". Pure and testable.
func parseSquirrelJSON(_ data: Data) -> (version: String, url: String?)? {
    guard let o = try? JSONSerialization.jsonObject(with: data) else { return nil }
    var candidates: [[String: Any]] = []
    if let arr = o as? [[String: Any]] { candidates = arr }
    else if let dict = o as? [String: Any] { candidates = [dict] }
    guard let first = candidates.first, let name = first["name"] as? String else { return nil }
    return (name, first["url"] as? String)
}

// MARK: - Homebrew cask index

func normalizeName(_ s: String) -> String {
    // Fold accents ("Café" → "Cafe") before stripping non-alphanumerics.
    let folded = s.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: nil)
    let allowed = CharacterSet.alphanumerics
    return String(folded.unicodeScalars.filter { allowed.contains($0) }).lowercased()
}

/// When set (e.g. by the headless `--selfcheck` runner), every data read or
/// write is redirected into this isolated directory so tests can never
/// pollute the user's real Application Support data.
var headlessSupportDirectory: URL?

func supportDirectory() -> URL {
    let dir: URL
    if let h = headlessSupportDirectory {
        dir = h
    } else {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.homeDirectoryForCurrentUser
        dir = base.appendingPathComponent("MacRefresh", isDirectory: true)
    }
    try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    for sub in ["Downloads", "Mounts", "Extracts", "Icons", "Logs", "Parked"] {
        try? FileManager.default.createDirectory(at: dir.appendingPathComponent(sub), withIntermediateDirectories: true)
    }
    return dir
}

func logsDirectory() -> URL {
    let dir = supportDirectory().appendingPathComponent("Logs")
    try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    return dir
}

func caskCacheURL() -> URL { supportDirectory().appendingPathComponent("cask.json") }

private func renderCaskURL(_ template: String, version: String) -> String {
    guard template.contains("#{") else { return template }
    let parts = version.split(separator: ",").map(String.init)
    var out = template
    let csv: [(String, String?)] = [
        ("#{version.csv.first}", parts.first),
        ("#{version.csv.second}", parts.count > 1 ? parts[1] : nil),
        ("#{version.csv.third}", parts.count > 2 ? parts[2] : nil),
        ("#{version.csv.last}", parts.last)
    ]
    for (token, value) in csv {
        if let v = value { out = out.replacingOccurrences(of: token, with: v) }
    }
    out = out.replacingOccurrences(of: "#{version}", with: version)
    out = out.replacingOccurrences(of: "#{arch}", with: Arch.isIntel ? "x86_64" : "arm64")
    return out
}

private func looksArm(_ url: String) -> Bool {
    let l = url.lowercased()
    if l.contains("aarch64") || l.contains("arm64") || l.contains("apple-silicon") { return true }
    if l.contains("darwin-arm") || l.contains("mac-arm") || l.contains("macos-arm") { return true }
    // Bare "arm" only with separators (avoid "linearmouse", "charm", …)
    if l.contains("-arm-") || l.contains("_arm_") || l.contains("/arm/") || l.hasSuffix("-arm") { return true }
    return false
}
private func looksIntel(_ url: String) -> Bool {
    let l = url.lowercased()
    if l.contains("x86") || l.contains("amd64") || l.contains("intel") { return true }
    if l.contains("x64") { return true }            // osx64, mac-x64, x86_64
    if l.contains("/darwin") || l.contains("-darwin") { return true }  // VS Code intel path
    return false
}

/// macOS codenames, newest first, used to pick the best cask `variations` entry.
private let codenamesNewToOld = ["golden_gate", "tahoe", "sequoia", "sonoma", "ventura",
                                 "monterey", "big_sur", "catalina", "mojave", "high_sierra"]

private func orderedVariationKeys(_ keys: [String], intel: Bool) -> [String] {
    var filtered = keys.filter { !$0.contains("linux") }
    if intel { filtered = filtered.filter { !$0.hasPrefix("arm64") } }
    return filtered.sorted { a, b in
        (codenamesNewToOld.firstIndex(of: a) ?? 99) < (codenamesNewToOld.firstIndex(of: b) ?? 99)
    }
}

private func resolveCaskURL(_ obj: [String: Any]) -> String {
    guard let defaultURL = obj["url"] as? String else { return "" }
    let version = (obj["version"] as? String) ?? ""
    guard let vars = obj["variations"] as? [String: [String: Any]] else {
        return renderCaskURL(defaultURL, version: version)
    }
    let ordered = orderedVariationKeys(Array(vars.keys), intel: Arch.isIntel)
    var variantURLs: [String] = []
    for key in ordered {
        if let u = vars[key]?["url"] as? String { variantURLs.append(u) }
    }
    if Arch.isIntel {
        if !looksArm(defaultURL) { return renderCaskURL(defaultURL, version: version) }
        if let pick = variantURLs.first(where: { looksIntel($0) && !looksArm($0) }) {
            return renderCaskURL(pick, version: version)
        }
        // Unmarked variant (Spotify.dmg, Zoom.pkg, Notion-x.dmg) = universal build
        if let pick = variantURLs.first(where: { !looksArm($0) }) {
            return renderCaskURL(pick, version: version)
        }
    } else {
        if looksArm(defaultURL) || !variantURLs.contains(where: { looksArm($0) }) {
            return renderCaskURL(defaultURL, version: version)
        }
        if let pick = variantURLs.first(where: { looksArm($0) }) {
            return renderCaskURL(pick, version: version)
        }
        if let pick = variantURLs.first(where: { !looksIntel($0) }) {
            return renderCaskURL(pick, version: version)
        }
    }
    return renderCaskURL(defaultURL, version: version)
}

func parseCask(_ obj: [String: Any]) -> Cask? {
    guard let token = obj["token"] as? String else { return nil }
    let names = (obj["name"] as? [String]) ?? []
    let version = (obj["version"] as? String) ?? ""
    let homepage = (obj["homepage"] as? String) ?? ""
    let desc = (obj["desc"] as? String) ?? ""
    let url = resolveCaskURL(obj)

    var appArtifacts: [String] = []
    var appTargets: [String] = []
    var quitIDs: [String] = []
    if let artifacts = obj["artifacts"] as? [[String: Any]] {
        for art in artifacts {
            if let apps = art["app"] as? [String] {
                appArtifacts.append(contentsOf: apps)
                if let target = art["target"] as? String { appTargets.append(target) }
                else { for a in apps { appTargets.append("/Applications/" + a) } }
            }
            if let uninstall = art["uninstall"] {
                func addQuit(_ value: Any?) {
                    if let s = value as? String { quitIDs.append(s) }
                    if let arr = value as? [String] { quitIDs.append(contentsOf: arr) }
                }
                if let dict = uninstall as? [String: Any] { addQuit(dict["quit"]) }
                if let arr = uninstall as? [[String: Any]] { for d in arr { addQuit(d["quit"]) } }
            }
        }
    }
    let minOS = caskMacOSRequirement(obj["depends_on"])
    return Cask(token: token, names: names, version: version,
                marketingVersion: version.split(separator: ",").first.map(String.init) ?? version,
                homepage: homepage,
                desc: desc, url: url, appArtifacts: appArtifacts, appTargets: appTargets,
                quitIDs: quitIDs, minOS: minOS)
}

func parseCaskPayload(_ data: Data) -> (map: [String: Cask], list: [Cask])? {
    guard let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return nil }
    var map: [String: Cask] = [:]
    var list: [Cask] = []
    list.reserveCapacity(arr.count)
    for obj in arr {
        guard let cask = parseCask(obj) else { continue }
        list.append(cask)
    }
    // Exact cask tokens are authoritative and must never be shadowed by
    // normalized-name collisions (e.g. "app-cleaner" vs "appcleaner").
    for cask in list where map[cask.token] == nil { map[cask.token] = cask }
    for cask in list {
        for n in cask.names {
            let k = normalizeName(n)
            if !k.isEmpty && map[k] == nil { map[k] = cask }
        }
        let nk = normalizeName(cask.token)
        if !nk.isEmpty && map[nk] == nil { map[nk] = cask }
    }
    return (map, list)
}

func loadCaskIndexFromDisk(at url: URL) -> (map: [String: Cask], list: [Cask], date: Date)? {
    guard let data = try? Data(contentsOf: url), let parsed = parseCaskPayload(data) else { return nil }
    let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
    let date = (attrs?[.modificationDate] as? Date) ?? Date.distantPast
    return (parsed.map, parsed.list, date)
}

func loadCaskIndex(forceRefresh: Bool = false, completion: @escaping ([String: Cask]?, [Cask]) -> Void) {
    let url = caskCacheURL()
    if !forceRefresh,
       let cached = loadCaskIndexFromDisk(at: url),
       Date().timeIntervalSince(cached.date) < 24 * 3600 {
        completion(cached.map, cached.list)
        return
    }
    guard let remote = URL(string: "https://formulae.brew.sh/api/cask.json") else {
        if let cached = loadCaskIndexFromDisk(at: url) { completion(cached.map, cached.list) }
        else { completion(nil, []) }
        return
    }
    var req = URLRequest(url: remote)
    req.timeoutInterval = 60
    req.cachePolicy = .reloadIgnoringLocalCacheData
    // One automatic retry when there is no usable cache at all, so a single
    // transient network failure doesn't leave every app at "No source".
    var attempts = 0
    func attempt() {
        attempts += 1
        URLSession.shared.dataTask(with: req) { data, _, _ in
            if let data = data, let parsed = parseCaskPayload(data) {
                try? data.write(to: url)
                completion(parsed.map, parsed.list)
            } else if let cached = loadCaskIndexFromDisk(at: url) {
                completion(cached.map, cached.list)
            } else if attempts < 2 {
                DispatchQueue.global().asyncAfter(deadline: .now() + 3) { attempt() }
            } else {
                completion(nil, [])
            }
        }.resume()
    }
    attempt()
}

func lookupCask(name: String, in map: [String: Cask]?) -> Cask? {
    guard let map = map else { return nil }
    if let exact = map[name] { return exact }
    return map[normalizeName(name)]
}

/// Whether a URL points at a downloadable DMG/ZIP/PKG, including redirect
/// endpoints that encode the package type (WhatsApp, Warp, VS Code, Postman,
/// HandBrake's rotation.php, …).
func isDirectInstallerURL(_ s: String) -> Bool {
    guard let u = URL(string: s), u.host != nil else { return false }
    let path = u.path.lowercased()
    let q = (u.query ?? "").lowercased()
    let okExts = ["dmg", "zip", "pkg", "mpkg"]
    if okExts.contains(where: { path.hasSuffix("." + $0) }) { return true }
    if q.contains("extension=zip") || q.contains("extension=pkg") || q.contains("extension=dmg") { return true }
    if q.contains("package=dmg") || q.contains("package=zip") || q.contains("package=pkg") { return true }
    // PortSwigger-style CDN endpoints: ?type=MacOsx serves a versioned .dmg
    if q.contains("type=macos") || q.contains("type=macosx") || q.contains("type=macos-x64") { return true }
    if let r = q.range(of: "file=") {
        let rest = q[r.upperBound...]
        let fname = rest.split(separator: "&").first.map(String.init) ?? String(rest)
        if okExts.contains(where: { fname.hasSuffix("." + $0) }) { return true }
    }
    if path.hasSuffix("/osx64") || path.hasSuffix("/osx_x64") || path.hasSuffix("/osx-x64") { return true }
    if path.contains("/darwin/") || path.hasSuffix("/darwin") { return true }
    return false
}

// MARK: - Sparkle feed parsing

final class SparkleFeedParser: NSObject, XMLParserDelegate {
    private var channelLink: String?
    private var itemLink: String?
    private var itemTitle: String?
    private var itemEnclosureURL: String?
    private var itemMinSystem: String?
    private var itemShortVersion: String?
    private var itemVersion: String?
    private var itemReleaseNotes: String?
    private var currentElement = ""
    private var currentText = ""
    private var inItem = false
    private var gotFirstItem = false
    private var firstTitle = ""
    private var inChannel = false
    private var haveChannelLink = false

    struct FeedResult {
        var version: String?
        var download: String?
        var homepage: String?
        var releaseNotes: String?
        var minOS: String?
    }

    func parse(data: Data) -> FeedResult {
        let parser = XMLParser(data: data)
        parser.delegate = self
        parser.parse()
        var version = itemShortVersion ?? itemVersion
        if version == nil || version!.isEmpty { version = extractVersionFromTitle(firstTitle) }
        return FeedResult(version: version,
                          download: itemEnclosureURL ?? itemLink,
                          homepage: channelLink ?? itemLink,
                          releaseNotes: itemReleaseNotes,
                          minOS: itemMinSystem)
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String,
                namespaceURI: String?, qualifiedName qName: String?,
                attributes attributeDict: [String: String] = [:]) {
        currentText = ""
        currentElement = elementName
        if elementName == "channel" { inChannel = true }
        if elementName == "item" {
            inItem = true
            itemLink = nil; itemTitle = nil; itemEnclosureURL = nil
            itemMinSystem = nil
            itemShortVersion = nil; itemVersion = nil; itemReleaseNotes = nil
        }
        if elementName == "enclosure" {
            itemEnclosureURL = attributeDict["url"] ?? attributeDict["URL"]
            itemMinSystem = attributeDict["sparkle:minimumSystemVersion"]
                ?? attributeDict["minimumSystemVersion"] ?? itemMinSystem
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        currentText += string
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String,
                namespaceURI: String?, qualifiedName qName: String?) {
        let text = currentText.trimmingCharacters(in: .whitespacesAndNewlines)
        switch elementName {
        case "link":
            if inItem { itemLink = text }
            else if inChannel && !haveChannelLink { channelLink = text; haveChannelLink = true }
        case "title":
            if inItem { itemTitle = text }
        case "shortVersionString", "sparkle:shortVersionString":
            if inItem && !text.isEmpty { itemShortVersion = text }
        case "version", "sparkle:version":
            if inItem && !text.isEmpty { itemVersion = text }
        case "releaseNotesLink", "sparkle:releaseNotesLink":
            if inItem && !text.isEmpty { itemReleaseNotes = text }
        default: break
        }
        if elementName == "item" {
            if !gotFirstItem {
                gotFirstItem = true
                firstTitle = itemTitle ?? ""
                if itemEnclosureURL == nil && itemShortVersion == nil && itemVersion == nil && itemLink == nil {
                    gotFirstItem = false
                } else {
                    parser.abortParsing()
                }
            }
            inItem = false
        }
    }
}

func extractVersionFromTitle(_ title: String) -> String? {
    guard !title.isEmpty else { return nil }
    let ns = title as NSString
    // Prefer a version explicitly introduced by the word "version"
    // ("Build 2024.1 — Version 2.3" → 2.3, not 2024.1).
    let labeled = try? NSRegularExpression(pattern: "(?i:version)\\s*(\\d+(?:\\.\\d+)+)")
    if let m = labeled?.firstMatch(in: title, range: NSRange(location: 0, length: ns.length)) {
        return ns.substring(with: m.range(at: 1))
    }
    let pattern = "(\\d+(?:\\.\\d+)+)"
    guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
    if let match = regex.firstMatch(in: title, range: NSRange(location: 0, length: ns.length)) {
        return ns.substring(with: match.range(at: 1))
    }
    return nil
}

// MARK: - Small JSON file cache (App Store / GitHub lookups)

func loadJSONCache(_ url: URL) -> [String: Any] {
    guard let d = try? Data(contentsOf: url),
          let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return [:] }
    return o
}

func saveJSONCache(_ obj: Any, url: URL) {
    if let d = try? JSONSerialization.data(withJSONObject: obj) { try? d.write(to: url) }
}

// MARK: - App Store source (iTunes lookup)

struct AppStoreInfo {
    let version: String
    let trackID: Int
    let viewURL: String
    /// Minimum macOS declared by the store result (nil when absent).
    let minimumOS: String?
}

func macAppStoreURL(trackID: Int) -> String {
    return "macappstore://apps.apple.com/app/id\(trackID)?mt=12"
}

private func appStoreCacheURL() -> URL { supportDirectory().appendingPathComponent("appstore.json") }

func lookupAppStore(bundleID: String, completion: @escaping (AppStoreInfo?) -> Void) {
    let cacheURL = appStoreCacheURL()
    var cache = loadJSONCache(cacheURL)
    if let e = cache[bundleID] as? [String: Any],
       let date = e["date"] as? Double,
       Date().timeIntervalSince1970 - date < 6 * 3600,
       let v = e["version"] as? String, let id = e["trackID"] as? Int,
       e["minOS"] != nil {
        let minOS = (e["minOS"] as? String).flatMap { $0.isEmpty ? nil : $0 }
        completion(AppStoreInfo(version: v, trackID: id,
                                viewURL: macAppStoreURL(trackID: id), minimumOS: minOS))
        return
    }
    let region: String
    if #available(macOS 13, *) {
        region = (Locale.current.region?.identifier ?? "US").lowercased()
    } else {
        region = (Locale.current.regionCode ?? "US").lowercased()
    }
    // Only ever query the user's own storefront. Falling back to the US store
    // returned versions not yet released in the user's region — rows that
    // opened the App Store and showed no update ("fake updates").
    let s = "https://itunes.apple.com/lookup?bundleId=\(bundleID)&country=\(region)&entity=macSoftware"
    guard let u = URL(string: s) else { completion(nil); return }
    var req = URLRequest(url: u)
    req.timeoutInterval = 12
    URLSession.shared.dataTask(with: req) { data, _, _ in
        if let data = data,
           let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let results = json["results"] as? [[String: Any]],
           let first = results.first,
           // Confirm the lookup really is this exact app; bundleId collisions
           // in the API would otherwise flag a different product.
           (first["bundleId"] as? String) == bundleID,
           let version = first["version"] as? String,
           let trackID = first["trackId"] as? Int {
            let minOS = first["minimumOsVersion"] as? String
            cache[bundleID] = ["date": Date().timeIntervalSince1970,
                               "version": version, "trackID": trackID,
                               "minOS": minOS ?? ""]
            saveJSONCache(cache, url: cacheURL)
            completion(AppStoreInfo(version: version, trackID: trackID,
                                    viewURL: macAppStoreURL(trackID: trackID),
                                    minimumOS: minOS))
        } else {
            completion(nil)
        }
    }.resume()
}

// MARK: - GitHub releases source (Electron-builder / GitHub-hosted apps)

struct GitHubRelease {
    let version: String
    let url: String
    let page: String
}

/// Pure asset picker (unit-tested): choose the best Intel/universal mac installer.
func pickGitHubAssetName(_ assets: [(name: String, url: String)]) -> String? {
    let blockedSuffixes = ["blockmap", "yml", "yaml", "sig", "json", "txt", "sha256", "rtf", "pdb"]
    func blocked(_ n: String) -> Bool {
        let l = n.lowercased()
        if blockedSuffixes.contains(where: { l.hasSuffix("." + $0) }) { return true }
        if l.contains("linux") || l.contains("win") || l.contains("windows")
            || l.hasSuffix(".deb") || l.hasSuffix(".rpm") || l.contains(".appimage") { return true }
        if l.contains("armv7") { return true }
        return false
    }
    let mac = assets.filter { n in
        let l = n.name.lowercased()
        return (l.hasSuffix(".dmg") || l.hasSuffix(".zip")) && !blocked(l)
    }
    guard !mac.isEmpty else { return nil }
    let candidates: [(name: String, url: String)]
    if Arch.isIntel {
        let intel = mac.filter { !looksArm($0.name) || looksIntel($0.name) }
        candidates = intel.isEmpty ? mac : intel
    } else {
        candidates = mac
    }
    func score(_ name: String) -> Int {
        let l = name.lowercased()
        var s = 0
        if l.hasSuffix(".dmg") { s += 10 }
        else if l.hasSuffix(".zip") { s += 6 }
        if Arch.isIntel {
            if looksIntel(l) { s += 5 }
            if !looksArm(l) { s += 2 }
        } else if looksArm(l) { s += 5 }
        if l.contains("universal") || l.contains("fat") { s += 4 }
        if l.contains("mac") || l.contains("darwin") || l.contains("osx") { s += 3 }
        if l.contains("setup") || l.contains("installer") { s += 1 }
        return s
    }
    return candidates.max { score($0.name) < score($1.name) }?.url
}

func githubCacheURL() -> URL { supportDirectory().appendingPathComponent("github.json") }

func fetchGitHubRelease(repo: String, force: Bool = false,
                        completion: @escaping (GitHubRelease?) -> Void) {
    let cacheURL = githubCacheURL()
    let cache0 = loadJSONCache(cacheURL)
    if !force, let e = cache0[repo] as? [String: Any],
       let date = e["date"] as? Double, Date().timeIntervalSince1970 - date < 6 * 3600 {
        // Short-lived negative entry while rate-limited (403/429): stop
        // hammering the API. Manual checks (force) bypass it.
        if let negative = e["negative"] as? Bool, negative,
           Date().timeIntervalSince1970 - date < 3 * 60 {
            completion(nil); return
        }
        if let v = e["version"] as? String, let u = e["url"] as? String, let p = e["page"] as? String {
            completion(GitHubRelease(version: v, url: u, page: p))
            return
        }
    }
    guard let u = URL(string: "https://api.github.com/repos/\(repo)/releases/latest") else {
        completion(nil); return
    }
    var req = URLRequest(url: u)
    req.timeoutInterval = 15
    req.setValue("MacRefresh/1.0", forHTTPHeaderField: "User-Agent")
    req.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
    URLSession.shared.dataTask(with: req) { data, response, _ in
        let http = response as? HTTPURLResponse
        if let status = http?.statusCode, status == 403 || status == 429 {
            var cache = loadJSONCache(cacheURL)
            cache[repo] = ["date": Date().timeIntervalSince1970, "negative": true]
            saveJSONCache(cache, url: cacheURL)
            completion(nil); return
        }
        guard let data = data,
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let tag = json["tag_name"] as? String,
              let page = json["html_url"] as? String,
              let assetsRaw = json["assets"] as? [[String: Any]] else { completion(nil); return }
        let assets: [(name: String, url: String)] = assetsRaw.compactMap {
            guard let n = $0["name"] as? String, let d = $0["browser_download_url"] as? String else { return nil }
            return (n, d)
        }
        guard let url = pickGitHubAssetName(assets) else { completion(nil); return }
        let version = extractTagVersion(tag)
        var cache = loadJSONCache(cacheURL)
        cache[repo] = ["date": Date().timeIntervalSince1970, "version": version,
                       "url": url, "page": page]
        saveJSONCache(cache, url: cacheURL)
        completion(GitHubRelease(version: version, url: url, page: page))
    }.resume()
}

/// Pull the version out of a release tag: "v2.0.1" → "2.0.1", "release-1.2" →
/// "1.2", "v2" → "2". Pure and unit-tested. (An earlier pattern accidentally
/// required a literal trailing "/" and never matched ordinary tags.)
func extractTagVersion(_ tag: String) -> String {
    if let r = tag.range(of: #"\d+(?:\.\d+)*"#, options: .regularExpression) {
        return String(tag[r])
    }
    return tag
}

// MARK: - CSV export

func csvEscape(_ s: String) -> String {
    if s.contains(",") || s.contains("\"") || s.contains("\n") {
        return "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\""
    }
    return s
}

func csvRows(_ rows: [AppRow]) -> String {
    var lines = ["Name,Bundle ID,Installed Version,Latest Version,Source,Status,Duplicate,Path,Homepage"]
    for r in rows {
        let cols = [r.name, r.bundleID, r.installed, r.latest ?? "", r.source,
                    statusText(r.status), r.isDuplicate ? "Yes" : "No", r.path, r.homepage ?? ""]
        lines.append(cols.map(csvEscape).joined(separator: ","))
    }
    return lines.joined(separator: "\n") + "\n"
}

// MARK: - Update checking

/// Whether an app should be shown as updatable, honoring the user's
/// "skip this version" choices and the build-number-equivalence toggle.
func updateIsAvailable(_ app: AppRow) -> Bool {
    guard let latest = app.latest, !latest.isEmpty, !app.installed.isEmpty else { return false }
    if let skipped = Prefs.skippedVersions[app.bundleID],
       normalizeVersion(skipped) == normalizeVersion(latest) { return false }
    guard isPlausibleVersion(latest) else { return false }
    // Self-updating apps that only carry a placeholder version (e.g.
    // "0.0.0.1") can't be compared and must never be offered an update.
    guard !isPlaceholderInstalledVersion(app.installed) else { return false }
    // Stable users must never be pushed a pre-release (alpha/beta/rc) build.
    if isPrereleaseVersion(latest) && !isPrereleaseVersion(app.installed) { return false }
    guard compareVersions(app.installed, latest) == .orderedAscending else { return false }
    let equivalenceOn = UserDefaults.standard.object(forKey: Prefs.buildEquivalence)
        .map { $0 as? Bool ?? true } ?? true
    if equivalenceOn, isBuildNumberEquivalent(installed: app.installed, latest: latest) {
        return false
    }
    return true
}

func finalizeStatus(_ app: inout AppRow) {
    guard let latest = app.latest, !latest.isEmpty else { app.status = .unknown; return }
    if app.installed.isEmpty { app.status = .unknown; return }
    // The newest version needs a newer macOS than this machine: the App Store
    // itself won't offer it, so this copy is current for this OS.
    if let req = app.requiresOS, !isOSVersionAtLeast(req) {
        app.status = .upToDate
        if app.note.isEmpty { app.note = "Latest \(latest) needs macOS \(req)" }
        return
    }
    // Explicitly skipped version: reported as up to date with an explanation.
    if let skipped = Prefs.skippedVersions[app.bundleID],
       normalizeVersion(skipped) == normalizeVersion(latest) {
        app.status = .upToDate
        if app.note.isEmpty { app.note = "Version \(latest) skipped" }
        return
    }
    app.status = updateIsAvailable(app) ? .update : .upToDate
}

func fetchLatest(for app: AppRow, caskMap: [String: Cask]?, force: Bool = false,
                 completion: @escaping (AppRow) -> Void) {
    var mutable = app
    let stateLock = NSLock()
    var finished = false
    func safeFinish() {
        stateLock.lock()
        guard !finished else { stateLock.unlock(); return }
        finished = true
        if mutable.latest == nil, mutable.note.isEmpty { mutable.note = "No update source found" }
        finalizeStatus(&mutable)
        let result = mutable
        stateLock.unlock()
        completion(result)
    }
    // Hard per-app timeout: a lost network callback must never leave a row
    // stuck on "…" forever.
    DispatchQueue.global().asyncAfter(deadline: .now() + 30) {
        stateLock.lock()
        guard !finished else { stateLock.unlock(); return }
        if mutable.latest == nil { mutable.note = "Timed out checking for updates" }
        stateLock.unlock()
        safeFinish()
    }

    func attachCask() {
        if let cask = lookupCask(name: app.name, in: caskMap) {
            mutable.caskToken = cask.token
            let v = normalizeVersion(cask.marketingVersion)
            if mutable.latest == nil, isPlausibleVersion(v), v != "latest", v != "0" {
                mutable.latest = v
                mutable.source = "Homebrew"
            }
            if !cask.homepage.isEmpty { mutable.homepage = cask.homepage }
            if mutable.downloadURL == nil && !cask.url.isEmpty { mutable.downloadURL = cask.url }
            if mutable.requiresOS == nil { mutable.requiresOS = cask.minOS }
        }
    }

    func tryGitHub(_ next: @escaping () -> Void) {
        guard let repo = app.githubRepo else { next(); return }
        fetchGitHubRelease(repo: repo, force: force) { rel in
            if let rel = rel {
                let v = normalizeVersion(rel.version)
                if mutable.latest == nil, isPlausibleVersion(v) {
                    mutable.latest = v; mutable.source = "GitHub"
                }
                if mutable.downloadURL == nil { mutable.downloadURL = rel.url }
                if mutable.homepage == nil { mutable.homepage = rel.page }
            }
            next()
        }
    }

    // 1) App Store apps can only update through the App Store itself.
    if app.isAppStore {
        lookupAppStore(bundleID: app.bundleID) { info in
            if let info = info {
                let v = normalizeVersion(info.version)
                if isPlausibleVersion(v) {
                    mutable.latest = v
                    mutable.source = "App Store"
                    mutable.requiresOS = info.minimumOS
                }
                mutable.appStoreURL = info.viewURL
                mutable.downloadURL = nil
            } else {
                mutable.note = "App Store info unavailable"
            }
            safeFinish()
        }
        return
    }

    // Standard chain: bundled Sparkle feed, then Homebrew cask, then GitHub.
    func runStandardSources() {
        if let feed = app.feedURL, let url = URL(string: feed), url.scheme != nil {
            var req = URLRequest(url: url)
            req.timeoutInterval = 15
            req.cachePolicy = .reloadIgnoringLocalCacheData
            URLSession.shared.dataTask(with: req) { data, _, error in
                if let data = data, error == nil {
                    let result = SparkleFeedParser().parse(data: data)
                    if let version = result.version, isPlausibleVersion(version) {
                        mutable.latest = normalizeVersion(version)
                        mutable.source = "Sparkle feed"
                        if let dl = result.download, !dl.isEmpty { mutable.downloadURL = dl }
                        if let hp = result.homepage, !hp.isEmpty { mutable.homepage = hp }
                        if let rn = result.releaseNotes, !rn.isEmpty { mutable.releaseNotesURL = rn }
                        if mutable.requiresOS == nil { mutable.requiresOS = result.minOS }
                    } else {
                        mutable.note = "Feed had no usable version"
                    }
                } else {
                    mutable.note = "Feed unavailable"
                }
                attachCask()
                if mutable.latest != nil { safeFinish(); return }
                tryGitHub { safeFinish() }
            }.resume()
        } else {
            attachCask()
            if mutable.latest != nil { safeFinish(); return }
            tryGitHub { safeFinish() }
        }
    }

    // 1b) User-provided custom update source (non App Store apps).
    if let customURLString = Prefs.customSources[app.bundleID] {
        if let slug = repositoryStringToSlug(customURLString) {
            fetchGitHubRelease(repo: slug, force: true) { rel in
                if let rel = rel {
                    let v = normalizeVersion(rel.version)
                    if mutable.latest == nil, isPlausibleVersion(v) {
                        mutable.latest = v; mutable.source = "Custom (GitHub)"
                    }
                    if mutable.downloadURL == nil { mutable.downloadURL = rel.url }
                    if mutable.homepage == nil { mutable.homepage = rel.page }
                }
                runStandardSources()
            }
            return
        }
        if let customURL = URL(string: customURLString), customURL.scheme != nil {
            var req = URLRequest(url: customURL)
            req.timeoutInterval = 15
            req.cachePolicy = .reloadIgnoringLocalCacheData
            URLSession.shared.dataTask(with: req) { data, _, _ in
                if let data = data {
                    let xml = SparkleFeedParser().parse(data: data)
                    if let version = xml.version, isPlausibleVersion(version) {
                        if mutable.latest == nil {
                            mutable.latest = normalizeVersion(version)
                            mutable.source = "Custom feed"
                        }
                        if mutable.downloadURL == nil, let dl = xml.download, !dl.isEmpty {
                            mutable.downloadURL = dl
                        }
                        if mutable.homepage == nil, let hp = xml.homepage, !hp.isEmpty {
                            mutable.homepage = hp
                        }
                        if mutable.releaseNotesURL == nil, let rn = xml.releaseNotes, !rn.isEmpty {
                            mutable.releaseNotesURL = rn
                        }
                        if mutable.requiresOS == nil { mutable.requiresOS = xml.minOS }
                    } else if let sq = parseSquirrelJSON(data) {
                        let v = normalizeVersion(sq.version)
                        if mutable.latest == nil, isPlausibleVersion(v) {
                            mutable.latest = v; mutable.source = "Custom feed"
                            if let u = sq.url, !u.isEmpty { mutable.downloadURL = u }
                        }
                    } else {
                        mutable.note = "Custom source had no usable version"
                    }
                } else {
                    mutable.note = "Custom source unavailable"
                }
                runStandardSources()
            }.resume()
            return
        }
    }
    runStandardSources()
}

func checkUpdates(apps: [AppRow], caskMap: [String: Cask]?, force: Bool = false,
                  completionQueue: DispatchQueue,
                  progress: @escaping (Int, Int, AppRow) -> Void,
                  done: @escaping () -> Void) {
    let group = DispatchGroup()
    let total = apps.count
    let lock = NSLock()
    var doneCount = 0
    // Bound the number of in-flight per-app checks. Without this a 200-app
    // scan fired ~200 simultaneous network paths, causing the lag, delays and
    // spurious failures users reported.
    let slots = DispatchSemaphore(value: 10)
    let work = DispatchQueue(label: "com.macrefresh.fixed.checkfan", attributes: .concurrent)
    for app in apps {
        group.enter()
        work.async {
            slots.wait()
            fetchLatest(for: app, caskMap: caskMap, force: force) { updated in
                slots.signal()
                lock.lock()
                doneCount += 1
                let n = doneCount
                lock.unlock()
                completionQueue.async { progress(n, total, updated) }
                group.leave()
            }
        }
    }
    group.notify(queue: completionQueue) { done() }
}

// MARK: - Shop app icons (iTunes artwork with disk cache + monogram fallback)

final class ShopIconCache {
    static let shared = ShopIconCache()
    private let mem = NSCache<NSString, NSImage>()
    private let lock = NSLock()
    private var inflight = Set<String>()
    private var missing = Set<String>()
    // Concurrent queue: an earlier serial queue made artwork downloads run one
    // at a time even though the throttle semaphore allowed several (a real
    // cause of the slow Shop). The semaphore now bounds real concurrency.
    private let fetchQueue = DispatchQueue(label: "com.macrefresh.fixed.shopicons",
                                           attributes: .concurrent)
    private let throttle = DispatchSemaphore(value: 6)

    private init() { mem.countLimit = 400 }

    private func diskURL(_ token: String) -> URL {
        supportDirectory().appendingPathComponent("Icons").appendingPathComponent(token + ".png")
    }

    private static func regionCode() -> String {
        if #available(macOS 13, *) {
            return (Locale.current.region?.identifier ?? "US").lowercased()
        } else {
            return (Locale.current.regionCode ?? "US").lowercased()
        }
    }

    /// Deterministic rounded-rect letter monogram, shown instantly until (or
    /// unless) real artwork is available.
    func monogram(name: String, token: String) -> NSImage {
        if let m = mem.object(forKey: "mono:\(token)" as NSString) { return m }
        let side = 64
        let img = NSImage(size: NSSize(width: side, height: side))
        img.lockFocus()
        let palette: [NSColor] = [.systemBlue, .systemIndigo, .systemPurple, .systemPink,
                                  .systemRed, .systemOrange, .systemYellow, .systemGreen,
                                  .systemTeal, .systemBrown]
        var h: UInt64 = 1469598103934665603
        for b in token.utf8 { h ^= UInt64(b); h = h &* 1099511628211 }
        let bg = palette[Int(h % UInt64(palette.count))]
        let path = NSBezierPath(roundedRect: NSRect(x: 3, y: 3, width: side - 6, height: side - 6),
                                xRadius: 15, yRadius: 15)
        bg.setFill(); path.fill()
        var letter = String(name.prefix(1)).uppercased()
        if letter.isEmpty || letter.rangeOfCharacter(from: .letters) == nil { letter = "#" }
        let style = NSMutableParagraphStyle(); style.alignment = .center
        let attrs: [NSAttributedString.Key: Any] = [
            .font: NSFont.systemFont(ofSize: 34, weight: .semibold),
            .foregroundColor: NSColor.white, .paragraphStyle: style
        ]
        let text = NSAttributedString(string: letter, attributes: attrs)
        let th = text.size().height
        text.draw(in: NSRect(x: 0, y: CGFloat(side) / 2 - th / 2, width: CGFloat(side), height: th))
        img.unlockFocus()
        mem.setObject(img, forKey: "mono:\(token)" as NSString)
        return img
    }

    /// Returns an image immediately (cached artwork or a monogram) and invokes
    /// `loaded` on the main thread when real artwork finishes downloading.
    @discardableResult
    func image(token: String, displayName: String, loaded: ((NSImage) -> Void)? = nil) -> NSImage {
        if let img = mem.object(forKey: token as NSString) { return img }
        let disk = diskURL(token)
        if let data = try? Data(contentsOf: disk), let img = NSImage(data: data), img.isValid {
            mem.setObject(img, forKey: token as NSString)
            return img
        }
        lock.lock()
        let knownMissing = missing.contains(token)
        let already = inflight.contains(token)
        if !already && !knownMissing { inflight.insert(token) }
        lock.unlock()
        if !already && !knownMissing {
            fetchQueue.async { [weak self] in
                self?.fetchArtwork(token: token, displayName: displayName, loaded: loaded)
            }
        }
        return monogram(name: displayName, token: token)
    }

    private func giveUp(_ token: String) {
        lock.lock(); inflight.remove(token); missing.insert(token); lock.unlock()
    }

    /// Forget "no artwork" decisions so a catalog refresh can retry lookups.
    func resetMissing() {
        lock.lock(); missing.removeAll(); inflight.removeAll(); lock.unlock()
    }

    /// Downscale artwork to a compact 128px PNG (shop cells render 30px);
    /// keeps memory and disk use small instead of caching 512px images.
    private func compactPNG(_ img: NSImage, side: CGFloat = 128) -> Data? {
        let out = NSImage(size: NSSize(width: side, height: side))
        out.lockFocus()
        NSGraphicsContext.current?.imageInterpolation = .high
        img.draw(in: NSRect(x: 0, y: 0, width: side, height: side),
                 from: .zero, operation: .copy, fraction: 1)
        out.unlockFocus()
        guard let tiff = out.tiffRepresentation,
              let rep = NSBitmapImageRep(data: tiff) else { return nil }
        return rep.representation(using: .png, properties: [:])
    }

    private func fetchArtwork(token: String, displayName: String, loaded: ((NSImage) -> Void)?) {
        throttle.wait()
        defer { throttle.signal() }
        let term = displayName.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? token
        let endpoint = "https://itunes.apple.com/search?term=\(term)&country=\(ShopIconCache.regionCode())&entity=macSoftware&limit=5"
        guard let url = URL(string: endpoint) else { giveUp(token); return }
        var req = URLRequest(url: url)
        req.timeoutInterval = 12
        var searchData: Data?
        let sem = DispatchSemaphore(value: 0)
        URLSession.shared.dataTask(with: req) { d, _, _ in searchData = d; sem.signal() }.resume()
        sem.wait()
        guard let d = searchData,
              let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
              let results = json["results"] as? [[String: Any]], !results.isEmpty else {
            giveUp(token); return
        }
        let want = normalizeName(displayName)
        let wantToken = normalizeName(token)
        // Rank candidates: exact token > exact name > containment with a
        // length-ratio guard so a short query ("pro") cannot bind to anything.
        func rank(_ r: [String: Any]) -> Int {
            let tn = normalizeName((r["trackName"] as? String) ?? "")
            let tb = normalizeName((r["bundleId"] as? String) ?? "")
            if !tn.isEmpty {
                if tb == wantToken || tn == wantToken { return 5 }
                if tn == want { return 4 }
                let ratio = Double(min(tn.count, want.count)) / Double(max(tn.count, want.count))
                if ratio >= 0.6 && (tn.contains(want) || want.contains(tn)) { return 3 }
            }
            return 0
        }
        let ranked = results.map { ($0, rank($0)) }.filter { $0.1 > 0 }
            .sorted { $0.1 > $1.1 }
        guard let match = ranked.first?.0,
              let art = (match["artworkUrl512"] as? String) ?? (match["artworkUrl100"] as? String),
              let artURL = URL(string: art) else { giveUp(token); return }
        var imgData: Data?
        let sem2 = DispatchSemaphore(value: 0)
        URLSession.shared.dataTask(with: artURL) { d, _, _ in imgData = d; sem2.signal() }.resume()
        sem2.wait()
        guard let imgData = imgData, let img = NSImage(data: imgData), img.isValid, img.size.width > 20 else {
            giveUp(token); return
        }
        let compact = compactPNG(img) ?? imgData
        try? compact.write(to: diskURL(token))
        let small = NSImage(data: compact) ?? img
        mem.setObject(small, forKey: token as NSString)
        lock.lock(); inflight.remove(token); lock.unlock()
        DispatchQueue.main.async { loaded?(small) }
    }
}

// MARK: - Bundle size & architecture inspection

final class BundleMetaCache {
    static let shared = BundleMetaCache()
    private var sizes: [String: Int64] = [:]
    private var archs: [String: String] = [:]
    private var pendingSizes = Set<String>()
    private var pendingArchs = Set<String>()
    private let lock = NSLock()
    private let metaQueue = DispatchQueue(label: "com.macrefresh.fixed.meta",
                                          qos: .utility, attributes: .concurrent)

    // MARK: Synchronous cached reads (never block; nil while unknown)
    func cachedSize(for path: String) -> Int64? {
        lock.lock(); defer { lock.unlock() }; return sizes[path]
    }
    func cachedArchitecture(for path: String) -> String? {
        lock.lock(); defer { lock.unlock() }; return archs[path]
    }

    // MARK: Asynchronous reads (completion always on main)
    func size(for path: String, completion: @escaping (Int64) -> Void) {
        lock.lock()
        if let v = sizes[path] {
            lock.unlock(); DispatchQueue.main.async { completion(v) }; return
        }
        let queued = pendingSizes.contains(path)
        if !queued { pendingSizes.insert(path) }
        lock.unlock()
        guard !queued else { return }
        metaQueue.async {
            let v = self.computeSize(path)
            self.lock.lock(); self.sizes[path] = v; self.pendingSizes.remove(path); self.lock.unlock()
            DispatchQueue.main.async { completion(v) }
        }
    }

    func architecture(for path: String, completion: @escaping (String) -> Void) {
        lock.lock()
        if let v = archs[path] {
            lock.unlock(); DispatchQueue.main.async { completion(v) }; return
        }
        let queued = pendingArchs.contains(path)
        if !queued { pendingArchs.insert(path) }
        lock.unlock()
        guard !queued else { return }
        metaQueue.async {
            let v = self.computeArchitecture(path)
            self.lock.lock(); self.archs[path] = v; self.pendingArchs.remove(path); self.lock.unlock()
            DispatchQueue.main.async { completion(v) }
        }
    }

    /// Warm the cache for a batch of paths. `changed` fires as values land so
    /// the caller can coalesce a single table refresh instead of a reload per
    /// cell.
    func prefetch(paths: [String], changed: (() -> Void)? = nil) {
        for p in paths {
            size(for: p) { _ in changed?() }
            architecture(for: p) { _ in changed?() }
        }
    }

    private func computeSize(_ path: String) -> Int64 {
        let fm = FileManager.default
        var total: Int64 = 0
        if let en = fm.enumerator(at: URL(fileURLWithPath: path),
                                  includingPropertiesForKeys: [.totalFileAllocatedSizeKey, .isRegularFileKey]) {
            for case let u as URL in en {
                if let v = try? u.resourceValues(forKeys: [.totalFileAllocatedSizeKey, .isRegularFileKey]),
                   v.isRegularFile == true { total += Int64(v.totalFileAllocatedSize ?? 0) }
            }
        }
        return total
    }

    private func computeArchitecture(_ path: String) -> String {
        var result = "—"
        if let exe = bundleExecutablePath(path) {
            let r = Installer.runProc("/usr/bin/lipo", ["-archs", exe], timeout: 15)
            if r.code == 0 {
                let out = r.output.lowercased()
                let hasArm = out.contains("arm64")
                let hasIntel = out.contains("x86_64")
                if hasArm && hasIntel { result = "Universal" }
                else if hasArm { result = "Apple Silicon" }
                else if hasIntel { result = "Intel" }
                else {
                    let t = out.trimmingCharacters(in: .whitespacesAndNewlines)
                    result = t.isEmpty ? "—" : t
                }
            }
        }
        return result
    }

    private func bundleExecutablePath(_ appPath: String) -> String? {
        let plist = appPath + "/Contents/Info.plist"
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: plist)),
              let o = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
              let exe = o["CFBundleExecutable"] as? String else { return nil }
        return appPath + "/Contents/MacOS/" + exe
    }

    func reset() {
        lock.lock(); sizes.removeAll(); archs.removeAll()
        pendingSizes.removeAll(); pendingArchs.removeAll(); lock.unlock()
    }
}

// MARK: - Crash / exception logging

func logLine(_ text: String, file: String = "app.log") {
    let line = "\(Date())  \(text)\n"
    let url = logsDirectory().appendingPathComponent(file)
    if let h = try? FileHandle(forWritingTo: url) {
        h.seekToEndOfFile()
        h.write(line.data(using: .utf8) ?? Data())
        h.closeFile()
    } else {
        try? line.write(to: url, atomically: true, encoding: .utf8)
    }
}

func installCrashLogging() {
    NSSetUncaughtExceptionHandler { ex in
        let line = "=== \(Date()) UNCAUGHT \(ex.name.rawValue)\n\(ex.reason ?? "")\n"
            + ex.callStackSymbols.joined(separator: "\n") + "\n"
        let url = logsDirectory().appendingPathComponent("crash.log")
        if let h = try? FileHandle(forWritingTo: url) {
            h.seekToEndOfFile()
            h.write(line.data(using: .utf8) ?? Data())
            h.closeFile()
        } else {
            try? line.write(to: url, atomically: true, encoding: .utf8)
        }
    }
}
