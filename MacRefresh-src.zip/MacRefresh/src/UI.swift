// UI.swift — sidebar, panes and tables
import Cocoa
import UserNotifications
import WebKit

// MARK: - Small UI helpers

final class SearchBox: NSObject, NSSearchFieldDelegate {
    let onChange: (String) -> Void
    init(onChange: @escaping (String) -> Void) { self.onChange = onChange }
    func controlTextDidChange(_ obj: Notification) {
        if let sf = obj.object as? NSSearchField { onChange(sf.stringValue) }
    }
}

final class SidebarButton: NSButton {
    let badge = NSTextField(labelWithString: "")

    init(title: String, symbol: String) {
        super.init(frame: .zero)
        isBordered = false
        bezelStyle = .inline
        let img = NSImage(systemSymbolName: symbol, accessibilityDescription: nil)
        let cfg = NSImage.SymbolConfiguration(pointSize: 15, weight: .medium)
        image = img?.withSymbolConfiguration(cfg)
        imagePosition = .imageLeading
        self.title = "  " + title
        font = .systemFont(ofSize: 14, weight: .medium)
        contentTintColor = .labelColor
        alignment = .left
        wantsLayer = true
        layer?.cornerRadius = 7
        translatesAutoresizingMaskIntoConstraints = false
        badge.font = .systemFont(ofSize: 11, weight: .semibold)
        badge.textColor = .secondaryLabelColor
        badge.alignment = .right
        badge.translatesAutoresizingMaskIntoConstraints = false
        addSubview(badge)
        NSLayoutConstraint.activate([
            badge.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            badge.centerYAnchor.constraint(equalTo: centerYAnchor),
            badge.widthAnchor.constraint(lessThanOrEqualToConstant: 90)
        ])
    }
    required init?(coder: NSCoder) { fatalError() }

    var selected: Bool = false {
        didSet {
            layer?.backgroundColor = selected
                ? NSColor.controlAccentColor.withAlphaComponent(0.16).cgColor : NSColor.clear.cgColor
            contentTintColor = selected ? .controlAccentColor : .labelColor
        }
    }
}

final class StatCard: NSButton {
    init(title: String) {
        super.init(frame: .zero)
        isBordered = false
        wantsLayer = true
        layer?.backgroundColor = NSColor.controlBackgroundColor.cgColor
        layer?.cornerRadius = 12
        layer?.borderWidth = 1
        layer?.borderColor = NSColor.separatorColor.cgColor
        bezelStyle = .inline
        setButtonType(.momentaryChange)
        self.title = ""
        translatesAutoresizingMaskIntoConstraints = false
        self.cardTitle = title
    }
    required init?(coder: NSCoder) { fatalError() }
    var cardTitle: String = ""
    func setValue(_ value: String, color: NSColor) {
        let attr = NSMutableAttributedString(string: value + "\n",
            attributes: [.font: NSFont.systemFont(ofSize: 30, weight: .bold), .foregroundColor: color])
        attr.append(NSAttributedString(string: cardTitle,
            attributes: [.font: NSFont.systemFont(ofSize: 12, weight: .medium),
                         .foregroundColor: NSColor.secondaryLabelColor]))
        let style = NSMutableParagraphStyle()
        style.alignment = .center
        attr.addAttribute(.paragraphStyle, value: style, range: NSRange(location: 0, length: attr.length))
        attributedTitle = attr
    }
}

func makeLabel(_ text: String, size: CGFloat = 13, bold: Bool = false,
               color: NSColor = .labelColor) -> NSTextField {
    let tf = NSTextField(labelWithString: text)
    tf.font = bold ? .boldSystemFont(ofSize: size) : .systemFont(ofSize: size)
    tf.textColor = color
    tf.lineBreakMode = .byTruncatingTail
    return tf
}

func makeTable(columns: [(id: String, title: String, width: CGFloat)]) -> NSTableView {
    let tv = NSTableView()
    tv.usesAlternatingRowBackgroundColors = true
    tv.rowHeight = 28
    tv.allowsMultipleSelection = false
    tv.style = .inset
    for c in columns {
        let col = NSTableColumn(identifier: NSUserInterfaceItemIdentifier(c.id))
        col.title = c.title
        col.width = c.width
        col.minWidth = 60
        tv.addTableColumn(col)
    }
    return tv
}

func container(for tv: NSTableView) -> NSScrollView {
    let sv = NSScrollView()
    sv.hasVerticalScroller = true
    sv.hasHorizontalScroller = false
    sv.autohidesScrollers = true
    sv.documentView = tv
    sv.translatesAutoresizingMaskIntoConstraints = false
    return sv
}

/// View that accepts dragged files: apps are checked on drop, installers
/// (dmg/zip/pkg) are installed directly.
final class DropTargetView: NSView {
    var onDrop: (([URL]) -> Void)?
    init() {
        super.init(frame: .zero)
        registerForDraggedTypes([.fileURL])
    }
    required init?(coder: NSCoder) { fatalError() }
    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { .copy }
    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        guard let urls = sender.draggingPasteboard.readObjects(
            forClasses: [NSURL.self],
            options: [.urlReadingFileURLsOnly: true]) as? [URL], !urls.isEmpty else { return false }
        onDrop?(urls)
        return true
    }
}

// MARK: - Section

enum Section: Int {
    case overview, updates, installed, shop, downloads, tools, settings
    var title: String {
        switch self {
        case .overview: return "Overview"
        case .updates: return "Updates"
        case .installed: return "Installed Apps"
        case .shop: return "Free App Shop"
        case .downloads: return "Downloads"
        case .tools: return "Tools"
        case .settings: return "Settings"
        }
    }
}

// Set from CLI (`--pane shop`) to open a specific section at launch
var initialSectionName: String?
var initialSection: Section {
    switch initialSectionName {
    case "updates": return .updates
    case "installed": return .installed
    case "shop": return .shop
    case "downloads": return .downloads
    case "tools": return .tools
    case "settings": return .settings
    default: return .overview
    }
}

// MARK: - Shop catalog (all free apps)

struct ShopItem { let cask: Cask; let category: String; let installedPath: String? }

let shopCatalog: [(category: String, tokens: [String])] = [
    ("Browsers", ["google-chrome", "firefox", "brave-browser", "opera", "opera-gx", "librewolf",
                  "microsoft-edge", "tor-browser", "orion", "waterfox", "floorp", "zen",
                  "ungoogled-chromium"]),
    ("Communication", ["discord", "slack", "zoom", "signal", "telegram", "whatsapp", "skype",
                       "element", "mattermost", "thunderbird", "microsoft-teams", "jami", "mumble",
                       "anydesk", "teamviewer", "viber", "franz", "rambox", "caprine",
                       "session", "lark"]),
    ("Media", ["vlc", "iina", "spotify", "handbrake-app", "audacity", "obs", "losslesscut",
               "kodi", "plex", "freetube", "mediainfo", "subler",
               "musicbrainz-picard", "kdenlive", "shotcut", "olive", "jellyfin-media-player",
               "stremio"]),
    ("Productivity", ["libreoffice", "obsidian", "notion", "joplin", "logseq", "standard-notes",
                      "simplenote", "zotero", "calibre", "macdown", "anki", "freeplane",
                      "koodo-reader", "onlyoffice", "mark-text", "zettlr", "xournal++",
                      "drawio", "appflowy", "siyuan", "anytype"]),
    ("Developer", ["iterm2", "visual-studio-code", "sublime-text", "github", "dbeaver-community",
                   "warp", "ghostty", "tableplus", "postman", "docker-desktop", "zed",
                   "vscodium", "intellij-idea-ce", "android-studio", "android-platform-tools",
                   "alacritty", "kitty", "wezterm", "hyper", "orbstack", "utm",
                   "mongodb-compass", "coteditor", "macvim-app", "imhex", "boop",
                   "sourcetree", "fork", "hex-fiend", "insomnia", "bruno", "azure-data-studio"]),
    ("Utilities", ["the-unarchiver", "appcleaner", "rectangle", "stats", "linearmouse", "itsycal",
                   "maccy", "alt-tab", "hiddenbar", "monitorcontrol", "coconutbattery",
                   "grandperspective", "numi", "devtoys", "jordanbaird-ice", "pearcleaner",
                   "omnidisksweeper", "disk-inventory-x", "onyx", "knockknock", "taskexplorer",
                   "blockblock", "oversight", "suspicious-package", "latest", "easyfind",
                   "find-any-file", "karabiner-elements", "mos", "smcfancontrol", "shottr",
                   "aldente", "balenaetcher", "raspberry-pi-imager", "flameshot"]),
    ("Internet", ["transmission", "qbittorrent", "tailscale-app", "mullvad-vpn", "protonvpn",
                  "wireshark-app", "proton-drive", "cyberduck", "tunnelblick", "motrix",
                  "zerotier-one", "free-download-manager", "burp-suite"]),
    ("Graphics", ["gimp", "inkscape", "krita", "blender", "darktable", "paintbrush", "rawtherapee",
                  "hugin", "kap", "licecap", "xnviewmp", "freecad", "pixelorama"]),
    ("Audio", ["blackhole-2ch", "blackhole-16ch", "eqmac", "ocenaudio", "midi-monitor", "freac"]),
    ("Security", ["keepassxc", "bitwarden", "cryptomator", "proton-pass", "lulu", "veracrypt",
                  "buttercup", "netiquette"]),
    ("Games", ["steam", "epic-games", "openemu", "prismlauncher", "heroic",
               "moonlight", "retroarch", "gog-galaxy", "playcover-community",
               "godot", "melonds", "dolphin", "xemu"])
]

// MARK: - AppDelegate

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    static weak var shared: AppDelegate?

    var window: NSWindow!
    var mainContainer: NSView!
    var navButtons: [SidebarButton] = []
    var paneViews: [Section: NSView] = [:]
    var statusItem: NSStatusItem?

    // data
    var rows: [AppRow] = []
    var caskMap: [String: Cask]?
    var caskList: [Cask] = []
    var caskByToken: [String: Cask] = [:]
    var shopItems: [ShopItem] = []
    var isChecking = false
    var checkStopped = false
    var wasOnline = true
    var metadataReloadWork: DispatchWorkItem?
    var checkProgressWork: DispatchWorkItem?
    var lastCheck: Date?
    /// The section currently displayed (used by pane-agnostic actions like
    /// focusing the visible search field).
    var currentSection: Section = .overview

    // overview
    var checkButton: NSButton!
    var checkSpinner: NSProgressIndicator!
    var lastCheckLabel: NSTextField!
    var cards: [StatCard] = []

    // updates
    var updatesTable: NSTableView!
    var updatesSearch = NSSearchField()
    var updatesSearchBox: SearchBox!
    var updatesOnly = true
    var updatesFilter = ""
    var updatesSourceFilter = NSPopUpButton()

    // installed
    var installedTable: NSTableView!
    var installedSearch = NSSearchField()
    var installedSearchBox: SearchBox!
    var installedFilter = ""
    var installedKindFilter = NSPopUpButton()

    // shop
    var shopTable: NSTableView!
    var shopSearch = NSSearchField()
    var shopSearchBox: SearchBox!
    var shopCategory = NSPopUpButton()
    var shopFilter = ""

    // downloads
    var downloadsTable: NSTableView!
    var downloadsReloadWork: DispatchWorkItem?
    var downloadsAggregateLabel: NSTextField!
    var downloadsEmptyLabel: NSTextField!

    // tools
    var historyTable: NSTableView!
    var storageStack: NSStackView!
    var storageRefreshGen = 0
    var systemStatusLabel: NSTextField!
    var downloadsFolderLabel: NSTextField!
    var skippedStack: NSStackView!
    var extraAppsStack: NSStackView!

    // overview
    var overviewInfoLabel: NSTextField!

    // settings
    var catalogDateLabel: NSTextField!

    // scheduling / extras
    var scheduleTimer: Timer?
    var ignoreAppPopup = NSPopUpButton()
    var ignoredStack = NSStackView()
    var customAppPopup = NSPopUpButton()
    var customStack = NSStackView()
    var extraFoldersStack = NSStackView()
    var shopFilterSegment = NSSegmentedControl()
    var diskUsageLabel: NSTextField!
    var releaseNotesPopover: NSPopover?
    var installedSortKey = "app"; var installedSortAsc = true
    var shopSortKey = "app"; var shopSortAsc = true

    // MARK: Lifecycle

    func applicationDidFinishLaunching(_ notification: Notification) {
        AppDelegate.shared = self
        Prefs.registerDefaults()
        migrateLegacyPreferences()
        applyAppearance()
        NetworkMonitor.shared.start()
        NetworkMonitor.shared.onChange = { [weak self] in
            guard let self = self else { return }
            let nowOnline = NetworkMonitor.shared.online
            if nowOnline && !self.wasOnline {
                // Network restored: auto-resume failed downloads once, then
                // re-run the check if it never completed.
                if UserDefaults.standard.bool(forKey: Prefs.autoRetryDownloads) {
                    DownloadManager.shared.retryAllFailed()
                }
                if !self.isChecking && self.lastCheck == nil {
                    self.startCheck()
                }
            }
            self.wasOnline = nowOnline
            self.refreshSystemStatus()
            self.updateOverviewInfo()
        }
        wasOnline = NetworkMonitor.shared.online
        installCrashLogging()
        DownloadManager.shared.onChange = { [weak self] in self?.downloadsChanged() }
        buildMenu()
        buildWindow()
        setupStatusItem()
        // Remember the last section unless a CLI pane was explicitly requested.
        if initialSectionName == nil, UserDefaults.standard.bool(forKey: Prefs.rememberSection) {
            initialSectionName = UserDefaults.standard.string(forKey: Prefs.lastSection)
        }
        switchTo(initialSection)
        rescan(initial: true)
        applySchedule()
        maybeShowOnboarding()
        maybeShowChangelog()
        NSApp.activate(ignoringOtherApps: true)
        if UserDefaults.standard.bool(forKey: Prefs.autoCheck) {
            perform(#selector(startCheck), with: nil, afterDelay: 0.8)
        }
        NotificationCenter.default.addObserver(
            self, selector: #selector(windowDidResize),
            name: NSWindow.didResizeNotification, object: window)
        if CommandLine.arguments.contains("--show-status-menu") {
            perform(#selector(openStatusMenuForVerification), with: nil, afterDelay: 1.4)
        }
    }

    @objc func windowDidResize() {
        guard UserDefaults.standard.bool(forKey: Prefs.rememberWindowSize) else { return }
        let f = window.frame
        UserDefaults.standard.set(Int(f.size.width), forKey: Prefs.windowWidth)
        UserDefaults.standard.set(Int(f.size.height), forKey: Prefs.windowHeight)
    }

    @objc func openStatusMenuForVerification() {
        FileHandle.standardError.write("status-menu hook fired\n".data(using: .utf8)!)
        NSApp.activate(ignoringOtherApps: true)
        if let button = statusItem?.button {
            FileHandle.standardError.write("button frame=\(button.bounds)\n".data(using: .utf8)!)
            // Explicit modal tracking: reliable even when the app is not
            // frontmost (performClick can be a no-op without user focus).
            if let menu = statusItem?.menu {
                menu.popUp(positioning: nil,
                           at: NSPoint(x: button.bounds.minX, y: button.bounds.minY - 2),
                           in: button)
            } else {
                button.performClick(nil as Any?)
            }
        }
    }

    // Never let a "reopen" event spawn a second window; rebuild a closed/released
    // window instead of messaging a stale pointer (a v3.6.2 crash source).
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if window == nil {
            buildWindow()
            if paneViews.isEmpty { switchTo(initialSection) }
        }
        if !flag {
            window?.makeKeyAndOrderFront(nil)
        }
        NSApp.activate(ignoringOtherApps: true)
        return true
    }

    // With a menu-bar icon the app can stay alive after the window closes.
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return statusItem == nil
    }

    // MARK: Menu

    private func buildMenu() {
        let mainMenu = NSMenu()
        let appItem = NSMenuItem()
        mainMenu.addItem(appItem)
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "About MacRefresh", action: #selector(showAbout), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Check for Updates", action: #selector(startCheck), keyEquivalent: "r")
        appMenu.addItem(withTitle: "Rescan Apps", action: #selector(rescanAction), keyEquivalent: "R")
        appMenu.addItem(withTitle: "Stop Checking", action: #selector(stopCheck), keyEquivalent: ".")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Quit MacRefresh", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu

        let editItem = NSMenuItem()
        mainMenu.addItem(editItem)
        let editMenu = NSMenu(title: "Edit")
        editMenu.addItem(withTitle: "Cut", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "Copy", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "Paste", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "Select All", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        editItem.submenu = editMenu

        let fileItem = NSMenuItem()
        mainMenu.addItem(fileItem)
        let fileMenu = NSMenu(title: "File")
        fileMenu.addItem(withTitle: "Export App List as CSV…", action: #selector(exportCSVClicked), keyEquivalent: "e")
        fileMenu.addItem(withTitle: "Export App List as JSON…", action: #selector(exportJSONClicked), keyEquivalent: "j")
        fileMenu.addItem(withTitle: "Export App List as HTML…", action: #selector(exportHTMLClicked), keyEquivalent: "h")
        fileMenu.addItem(.separator())
        fileMenu.addItem(withTitle: "Close Window", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        fileItem.submenu = fileMenu

        let viewItem = NSMenuItem()
        mainMenu.addItem(viewItem)
        let viewMenu = NSMenu(title: "View")
        let paneLabels = ["Overview", "Updates", "Installed", "Shop", "Downloads", "Tools", "Settings"]
        for (i, t) in paneLabels.enumerated() {
            let it = NSMenuItem(title: t, action: #selector(gotoSection(_:)), keyEquivalent: "\(i + 1)")
            it.tag = i
            viewMenu.addItem(it)
        }
        viewMenu.addItem(.separator())
        viewMenu.addItem(withTitle: "Focus Search", action: #selector(focusSearch), keyEquivalent: "l")
        viewMenu.addItem(withTitle: "What's New…", action: #selector(showChangelog), keyEquivalent: "")
        viewItem.submenu = viewMenu
        NSApp.mainMenu = mainMenu
    }

    @objc func showAbout() { NSApp.orderFrontStandardAboutPanel(nil) }

    // Menu item validation: "Stop Checking" is only actionable mid-check.
    func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
        if menuItem.action == #selector(stopCheck) { return isChecking }
        return true
    }

    /// ⌘L: focus the search field of the currently visible pane.
    @objc func focusSearch() {
        guard let w = window else { return }
        let field: NSSearchField?
        switch currentSection {
        case .updates: field = updatesSearch
        case .installed: field = installedSearch
        case .shop: field = shopSearch
        default: field = nil
        }
        if let field = field { w.makeFirstResponder(field) }
    }

    /// ⌘.: stop a running update check immediately.
    @objc func stopCheck() {
        guard isChecking else { return }
        checkStopped = true
        finishCheck(reason: "stopped")
    }

    // MARK: Menu-bar status item

    func setupStatusItem() {
        NSApp.setActivationPolicy(UserDefaults.standard.bool(forKey: Prefs.showDockIcon) ? .regular : .accessory)
        applyStatusItemVisibility()
    }

    func applyStatusItemVisibility() {
        let show = UserDefaults.standard.bool(forKey: Prefs.showStatusItem)
        if show && statusItem == nil {
            let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
            if let button = item.button {
                button.image = NSImage(systemSymbolName: "arrow.triangle.2.circlepath",
                                       accessibilityDescription: "MacRefresh")
                button.image?.isTemplate = true
            }
            statusItem = item
            configureStatusItemInteraction(item)
        } else if !show, let item = statusItem {
            item.menu?.delegate = nil
            item.menu = nil
            NSStatusBar.system.removeStatusItem(item)
            statusItem = nil
        }
    }

    /// Left-click either opens the menu (default) or the window (preference);
    /// right/control-click always opens the menu.
    func configureStatusItemInteraction(_ item: NSStatusItem) {
        let clickOpens = UserDefaults.standard.bool(forKey: Prefs.statusItemClickOpens)
        item.menu?.delegate = nil
        item.menu = nil
        if let button = item.button {
            button.target = self
            button.action = #selector(statusItemClicked(_:))
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        }
        if !clickOpens {
            // Standard menu behavior; the menu refreshes lazily via delegate.
            let menu = NSMenu()
            menu.delegate = self
            item.menu = menu
            rebuildStatusMenuItems(menu)
        }
    }

    @objc func statusItemClicked(_ sender: NSStatusBarButton) {
        let event = NSApp.currentEvent
        let isRight = event?.type == .rightMouseUp
            || (event?.type == .leftMouseUp
                && event?.modifierFlags.contains(.control) == true)
        if isRight {
            let menu = NSMenu()
            menu.delegate = self
            rebuildStatusMenuItems(menu)
            statusItem?.menu = menu
            sender.performClick(nil)
        } else {
            statusOpen()
        }
    }

    func menuNeedsUpdate(_ menu: NSMenu) {
        rebuildStatusMenuItems(menu)
    }

    func menuDidClose(_ menu: NSMenu) {
        // In click-opens-window mode, re-arm the button after a right-click menu.
        if UserDefaults.standard.bool(forKey: Prefs.statusItemClickOpens), let item = statusItem {
            item.menu = nil
            if let button = item.button {
                button.target = self
                button.action = #selector(statusItemClicked(_:))
                button.sendAction(on: [.leftMouseUp, .rightMouseUp])
            }
        }
    }

    func rebuildStatusMenuItems(_ menu: NSMenu) {
        menu.removeAllItems()
        func item(_ title: String, _ action: Selector, key: String = "", target: AnyObject? = nil) -> NSMenuItem {
            let i = NSMenuItem(title: title, action: action, keyEquivalent: key)
            i.target = target ?? self
            return i
        }
        let header = NSMenuItem(title: "MacRefresh \(MacRefreshVersion)", action: nil, keyEquivalent: "")
        header.isEnabled = false
        menu.addItem(header)

        let updates = rows.filter { !$0.ignored && $0.status == .update }.count
        let activeDownloads = DownloadManager.shared.jobs.filter {
            [.queued, .downloading, .extracting, .installing].contains($0.state)
        }.count
        let failedJobs = DownloadManager.shared.jobs.filter { $0.state == .failed }
        let pausedJobs = DownloadManager.shared.jobs.filter { $0.state == .paused }
        let summary: String
        if isSnoozing() { summary = "Scheduled checks snoozed" }
        else if isChecking { summary = "Checking for updates…" }
        else if activeDownloads > 0 { summary = "\(activeDownloads) download\(activeDownloads == 1 ? "" : "s") running" }
        else if updates > 0 { summary = "\(updates) update\(updates == 1 ? "" : "s") available" }
        else { summary = rows.isEmpty ? "Not scanned yet" : "All apps up to date" }
        let summaryItem = NSMenuItem(title: summary, action: nil, keyEquivalent: "")
        summaryItem.isEnabled = false
        menu.addItem(summaryItem)
        if let last = lastCheck {
            let f = DateFormatter(); f.dateStyle = .none; f.timeStyle = .short
            let lastItem = NSMenuItem(title: "Last check: \(f.string(from: last))", action: nil, keyEquivalent: "")
            lastItem.isEnabled = false
            menu.addItem(lastItem)
        }
        menu.addItem(.separator())
        menu.addItem(item("Check for Updates Now", #selector(statusCheckNow)))
        if isChecking {
            menu.addItem(item("Stop Checking", #selector(stopCheck)))
        }
        if isSnoozing() {
            menu.addItem(item("Cancel snooze", #selector(cancelSnoozeClicked)))
        } else {
            let snoozeItem = NSMenuItem(title: "Snooze scheduled checks", action: nil, keyEquivalent: "")
            let sub = NSMenu()
            sub.addItem(item("For 1 hour", #selector(snooze1hClicked)))
            sub.addItem(item("For 4 hours", #selector(snooze4hClicked)))
            sub.addItem(item("For 24 hours", #selector(snooze24Clicked)))
            sub.addItem(item("For 1 week", #selector(snoozeWeekClicked)))
            snoozeItem.submenu = sub
            menu.addItem(snoozeItem)
        }
        if !failedJobs.isEmpty {
            menu.addItem(item("Retry \(failedJobs.count) failed download\(failedJobs.count == 1 ? "" : "s")",
                             #selector(statusRetryFailed)))
        }
        if activeDownloads > 0 {
            menu.addItem(item("Pause all downloads", #selector(statusPauseAll)))
        }
        if !pausedJobs.isEmpty {
            menu.addItem(item("Resume all downloads", #selector(statusResumeAll)))
        }
        menu.addItem(item("Open MacRefresh", #selector(statusOpen)))
        if updates > 0 {
            menu.addItem(item("Go to Updates", #selector(statusUpdates)))
        }
        let duplicateCount = rows.filter { $0.isDuplicate }.count
        if duplicateCount > 0 {
            let dupItem = item("Duplicate apps found", #selector(statusDuplicates))
            menu.addItem(dupItem)
        }
        if activeDownloads > 0 {
            menu.addItem(item("Show Downloads", #selector(statusDownloads)))
        }
        menu.addItem(.separator())
        let updateRows = rows.filter { !$0.ignored && $0.status == .update }
        if !updateRows.isEmpty {
            let updatesSub = NSMenu()
            for r in updateRows.prefix(15) {
                // Duplicate copies share a bundle id, so label the location and
                // key the item by its full path.
                let location = r.isDuplicate
                    ? "  (\((r.path as NSString).deletingLastPathComponent as NSString).abbreviatingWithTildeInPath)"
                    : ""
                let mi = NSMenuItem(title: "\(r.name)  \(r.installed) → \(r.latest ?? "?")\(location)",
                                    action: #selector(statusUpdateRow(_:)), keyEquivalent: "")
                mi.target = self
                mi.representedObject = r.path
                updatesSub.addItem(mi)
            }
            if updateRows.count > 15 {
                let more = NSMenuItem(title: "\(updateRows.count - 15) more…", action: nil, keyEquivalent: "")
                more.isEnabled = false
                updatesSub.addItem(more)
            }
            let updatesItem = NSMenuItem(title: "Available updates", action: nil, keyEquivalent: "")
            updatesItem.submenu = updatesSub
            menu.addItem(updatesItem)
        }
        let runningJobs = DownloadManager.shared.jobs.filter {
            [.queued, .downloading, .extracting, .installing].contains($0.state)
        }
        if !runningJobs.isEmpty {
            let jobsSub = NSMenu()
            for j in runningJobs.prefix(12) {
                let label = j.state == .downloading && !j.message.isEmpty
                    ? "\(j.title) — \(j.message)" : "\(j.title) — \(j.state.text)"
                let mi = NSMenuItem(title: label, action: nil, keyEquivalent: "")
                mi.isEnabled = false
                jobsSub.addItem(mi)
            }
            let jobsItem = NSMenuItem(title: "Running downloads", action: nil, keyEquivalent: "")
            jobsItem.submenu = jobsSub
            menu.addItem(jobsItem)
        }
        let recent = HistoryStore.shared.displayed.filter {
            [.updated, .installed, .rolledBack].contains($0.kind)
        }.prefix(10)
        if !recent.isEmpty {
            let recentSub = NSMenu()
            for e in recent {
                let mi = NSMenuItem(title: "\(e.appName)  \(e.kind.text)", action: nil, keyEquivalent: "")
                mi.isEnabled = false
                recentSub.addItem(mi)
            }
            let recentItem = NSMenuItem(title: "Recent activity", action: nil, keyEquivalent: "")
            recentItem.submenu = recentSub
            menu.addItem(recentItem)
        }
        menu.addItem(item("Free App Shop", #selector(statusShop)))
        menu.addItem(item("Downloads", #selector(statusDownloads)))
        menu.addItem(item("Tools", #selector(statusTools)))
        menu.addItem(item("Settings…", #selector(statusSettings)))
        menu.addItem(.separator())
        menu.addItem(item("Quit MacRefresh", #selector(NSApplication.terminate(_:)), key: "q", target: NSApp))
        statusItem?.button?.title = updates > 0 ? " \(updates)" : ""
    }

    @objc func statusUpdateRow(_ sender: NSMenuItem) {
        guard let path = sender.representedObject as? String else { return }
        bringWindowForward(.updates)
        if let row = rows.first(where: { $0.path == path }) { startDownloadOrOpen(row) }
    }

    /// Safe to call any number of times from any state change: only updates the
    /// menu-bar badge; the menu items refresh themselves on next open.
    func refreshStatusMenu() {
        let updates = rows.filter { !$0.ignored && $0.status == .update }.count
        statusItem?.button?.title = updates > 0 ? " \(updates)" : ""
    }

    func bringWindowForward(_ section: Section?) {
        NSApp.activate(ignoringOtherApps: true)
        window?.makeKeyAndOrderFront(nil)
        if let section = section { switchTo(section) }
    }

    @objc func statusCheckNow() { bringWindowForward(.overview); startCheck() }
    @objc func statusOpen() { bringWindowForward(nil) }
    @objc func statusUpdates() { bringWindowForward(.updates) }
    @objc func statusShop() { bringWindowForward(.shop) }
    @objc func statusDownloads() { bringWindowForward(.downloads) }
    @objc func statusSettings() { bringWindowForward(.settings) }
    @objc func statusTools() { bringWindowForward(.tools) }
    @objc func statusRetryFailed() { DownloadManager.shared.retryAllFailed() }
    @objc func statusPauseAll() { DownloadManager.shared.pauseAll() }
    @objc func statusResumeAll() { DownloadManager.shared.resumeAll() }
    @objc func snooze24Clicked() {
        setSnooze(until: Date().addingTimeInterval(24 * 3600))
        refreshStatusMenu()
    }
    @objc func snooze1hClicked() {
        setSnooze(until: Date().addingTimeInterval(3600))
        refreshStatusMenu()
    }
    @objc func snooze4hClicked() {
        setSnooze(until: Date().addingTimeInterval(4 * 3600))
        refreshStatusMenu()
    }
    @objc func snoozeWeekClicked() {
        setSnooze(until: Date().addingTimeInterval(7 * 24 * 3600))
        refreshStatusMenu()
    }
    @objc func cancelSnoozeClicked() {
        setSnooze(until: nil)
        applySchedule()
        refreshStatusMenu()
    }
    @objc func statusDuplicates() {
        bringWindowForward(.installed)
        installedSearch.stringValue = "duplicate"
        installedFilter = "duplicate"
        installedTable?.reloadData()
    }

    // MARK: Window shell

    private func buildWindow() {
        // A recreated window gets a brand-new mainContainer and nav stack:
        // drop cached pane views and nav buttons from the old window, or the
        // reopen path would attach views bound to a destroyed container (blank
        // window) and accumulate stale sidebar buttons.
        navButtons.removeAll()
        paneViews.removeAll()
        var w = 1120, h = 740
        if UserDefaults.standard.bool(forKey: Prefs.rememberWindowSize) {
            w = UserDefaults.standard.integer(forKey: Prefs.windowWidth)
            h = UserDefaults.standard.integer(forKey: Prefs.windowHeight)
            w = max(w, 920); h = max(h, 580)
        }
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: w, height: h),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "MacRefresh \(MacRefreshVersion)"
        window.isRestorable = false
        window.isReleasedWhenClosed = false
        window.minSize = NSSize(width: 920, height: 580)
        window.center()

        let content = NSView()
        window.contentView = content

        let sidebar = NSVisualEffectView()
        sidebar.material = .sidebar
        sidebar.blendingMode = .behindWindow
        sidebar.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(sidebar)

        let drop = DropTargetView()
        drop.onDrop = { [weak self] urls in self?.handleDroppedURLs(urls) }
        mainContainer = drop
        mainContainer.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(mainContainer)

        // sidebar contents
        let logo = NSImageView()
        logo.image = NSImage(named: "AppIcon") ?? NSApplication.shared.applicationIconImage
        logo.translatesAutoresizingMaskIntoConstraints = false
        logo.wantsLayer = true
        logo.layer?.cornerRadius = 12
        logo.layer?.masksToBounds = true
        sidebar.addSubview(logo)

        let title = makeLabel("MacRefresh", size: 17, bold: true)
        title.alignment = .center
        title.translatesAutoresizingMaskIntoConstraints = false
        sidebar.addSubview(title)
        let subtitle = makeLabel(MacRefreshVersion, size: 12, color: .secondaryLabelColor)
        subtitle.alignment = .center
        subtitle.translatesAutoresizingMaskIntoConstraints = false
        sidebar.addSubview(subtitle)

        let navStack = NSStackView()
        navStack.orientation = .vertical
        navStack.alignment = .leading
        navStack.spacing = 2
        navStack.translatesAutoresizingMaskIntoConstraints = false
        sidebar.addSubview(navStack)

        let nav: [(Section, String, String)] = [
            (.overview, "Overview", "house"),
            (.updates, "Updates", "arrow.triangle.2.circlepath"),
            (.installed, "Installed", "square.grid.2x2"),
            (.shop, "Shop", "bag"),
            (.downloads, "Downloads", "tray.and.arrow.down"),
            (.tools, "Tools", "wrench"),
            (.settings, "Settings", "gearshape")
        ]
        for (section, label, symbol) in nav {
            let b = SidebarButton(title: label, symbol: symbol)
            b.tag = section.rawValue
            b.target = self
            b.action = #selector(navClicked(_:))
            navButtons.append(b)
            navStack.addArrangedSubview(b)
            b.widthAnchor.constraint(equalToConstant: 188).isActive = true
            b.heightAnchor.constraint(equalToConstant: 34).isActive = true
        }

        let footer = makeLabel("Independent updater\nFree · no account", size: 11, color: .tertiaryLabelColor)
        footer.alignment = .center
        footer.translatesAutoresizingMaskIntoConstraints = false
        sidebar.addSubview(footer)

        NSLayoutConstraint.activate([
            sidebar.topAnchor.constraint(equalTo: content.topAnchor),
            sidebar.leadingAnchor.constraint(equalTo: content.leadingAnchor),
            sidebar.bottomAnchor.constraint(equalTo: content.bottomAnchor),
            sidebar.widthAnchor.constraint(equalToConstant: 212),

            logo.topAnchor.constraint(equalTo: sidebar.topAnchor, constant: 22),
            logo.centerXAnchor.constraint(equalTo: sidebar.centerXAnchor),
            logo.widthAnchor.constraint(equalToConstant: 64),
            logo.heightAnchor.constraint(equalToConstant: 64),
            title.topAnchor.constraint(equalTo: logo.bottomAnchor, constant: 10),
            title.centerXAnchor.constraint(equalTo: sidebar.centerXAnchor),
            subtitle.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 2),
            subtitle.centerXAnchor.constraint(equalTo: sidebar.centerXAnchor),

            navStack.topAnchor.constraint(equalTo: subtitle.bottomAnchor, constant: 22),
            navStack.leadingAnchor.constraint(equalTo: sidebar.leadingAnchor, constant: 12),
            navStack.trailingAnchor.constraint(equalTo: sidebar.trailingAnchor, constant: -12),

            footer.bottomAnchor.constraint(equalTo: sidebar.bottomAnchor, constant: -16),
            footer.centerXAnchor.constraint(equalTo: sidebar.centerXAnchor),

            mainContainer.topAnchor.constraint(equalTo: content.topAnchor),
            mainContainer.leadingAnchor.constraint(equalTo: sidebar.trailingAnchor),
            mainContainer.trailingAnchor.constraint(equalTo: content.trailingAnchor),
            mainContainer.bottomAnchor.constraint(equalTo: content.bottomAnchor)
        ])
        window.makeKeyAndOrderFront(nil)
    }

    @objc func navClicked(_ sender: SidebarButton) {
        if let s = Section(rawValue: sender.tag) { switchTo(s) }
    }

    func switchTo(_ section: Section) {
        currentSection = section
        navButtons.forEach { $0.selected = $0.tag == section.rawValue }
        paneViews.values.forEach { $0.removeFromSuperview() }
        let view = pane(for: section)
        view.translatesAutoresizingMaskIntoConstraints = false
        mainContainer.addSubview(view)
        NSLayoutConstraint.activate([
            view.topAnchor.constraint(equalTo: mainContainer.topAnchor),
            view.leadingAnchor.constraint(equalTo: mainContainer.leadingAnchor),
            view.trailingAnchor.constraint(equalTo: mainContainer.trailingAnchor),
            view.bottomAnchor.constraint(equalTo: mainContainer.bottomAnchor)
        ])
        window.title = "MacRefresh \(MacRefreshVersion) — \(section.title)"
        UserDefaults.standard.set(sectionName(section), forKey: Prefs.lastSection)
        if section == .tools {
            refreshHistory()
            refreshStorage()
            refreshSkippedUI()
            refreshExtraAppsUI()
            refreshDownloadsFolderLabel()
            refreshSystemStatus()
        }
    }

    private func sectionName(_ s: Section) -> String {
        switch s {
        case .overview: return "overview"
        case .updates: return "updates"
        case .installed: return "installed"
        case .shop: return "shop"
        case .downloads: return "downloads"
        case .tools: return "tools"
        case .settings: return "settings"
        }
    }

    @objc private func gotoSection(_ sender: NSMenuItem) {
        if let s = Section(rawValue: sender.tag) { switchTo(s) }
    }

    private func pane(for section: Section) -> NSView {
        if let v = paneViews[section] { return v }
        let v: NSView
        switch section {
        case .overview: v = buildOverview()
        case .updates: v = buildUpdates()
        case .installed: v = buildInstalled()
        case .shop: v = buildShop()
        case .downloads: v = buildDownloads()
        case .tools: v = buildTools()
        case .settings: v = buildSettings()
        }
        paneViews[section] = v
        return v
    }

    func header(title: String, subtitle: String) -> NSView {
        let h = NSView()
        h.translatesAutoresizingMaskIntoConstraints = false
        let t = makeLabel(title, size: 22, bold: true)
        t.translatesAutoresizingMaskIntoConstraints = false
        let s = makeLabel(subtitle, size: 12, color: .secondaryLabelColor)
        s.translatesAutoresizingMaskIntoConstraints = false
        h.addSubview(t); h.addSubview(s)
        NSLayoutConstraint.activate([
            t.topAnchor.constraint(equalTo: h.topAnchor, constant: 16),
            t.leadingAnchor.constraint(equalTo: h.leadingAnchor, constant: 20),
            s.topAnchor.constraint(equalTo: t.bottomAnchor, constant: 2),
            s.leadingAnchor.constraint(equalTo: h.leadingAnchor, constant: 20),
            s.bottomAnchor.constraint(equalTo: h.bottomAnchor, constant: -8),
            h.heightAnchor.constraint(greaterThanOrEqualToConstant: 64)
        ])
        return h
    }

    // MARK: Overview pane

    private func buildOverview() -> NSView {
        let v = NSView()
        let head = header(title: "Overview", subtitle: "Scan your apps and install updates in one click")
        head.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(head)

        let logo = NSImageView()
        logo.image = NSImage(named: "AppIcon") ?? NSApplication.shared.applicationIconImage
        logo.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(logo)

        let name = makeLabel("MacRefresh \(MacRefreshVersion)", size: 20, bold: true)
        name.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(name)
        let tag = makeLabel("Self-contained updater · Sparkle · Homebrew · App Store · GitHub", size: 13,
                            color: .secondaryLabelColor)
        tag.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(tag)

        checkButton = NSButton(title: "Check for Updates Now", target: self, action: #selector(startCheck))
        checkButton.bezelStyle = .rounded
        checkButton.controlSize = .large
        checkButton.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(checkButton)

        checkSpinner = NSProgressIndicator()
        checkSpinner.style = .spinning
        checkSpinner.controlSize = .regular
        checkSpinner.isDisplayedWhenStopped = false
        checkSpinner.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(checkSpinner)

        lastCheckLabel = makeLabel("Never checked yet", size: 12, color: .secondaryLabelColor)
        lastCheckLabel.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(lastCheckLabel)

        let cardsRow = NSStackView()
        cardsRow.orientation = .horizontal
        cardsRow.spacing = 14
        cardsRow.distribution = .fillEqually
        cardsRow.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(cardsRow)
        let titles = ["Apps installed", "Updates", "Up to date", "No source", "Duplicates"]
        let dupColor = NSColor(calibratedRed: 0.83, green: 0.47, blue: 0.08, alpha: 1)
        let colors: [NSColor] = [.labelColor, .systemOrange, .systemGreen,
                                 .secondaryLabelColor, dupColor]
        for (i, t) in titles.enumerated() {
            let card = StatCard(title: t)
            card.tag = i
            card.target = self
            card.action = #selector(cardClicked(_:))
            card.setValue("—", color: colors[i])
            cards.append(card)
            cardsRow.addArrangedSubview(card)
            card.heightAnchor.constraint(equalToConstant: 96).isActive = true
        }

        let shopButton = NSButton(title: "Browse the free App Shop", target: self, action: #selector(openShop))
        shopButton.bezelStyle = .rounded
        shopButton.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(shopButton)

        overviewInfoLabel = makeLabel("", size: 11, color: .tertiaryLabelColor)
        overviewInfoLabel.alignment = .center
        overviewInfoLabel.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(overviewInfoLabel)

        NSLayoutConstraint.activate([
            head.topAnchor.constraint(equalTo: v.topAnchor),
            head.leadingAnchor.constraint(equalTo: v.leadingAnchor),
            head.trailingAnchor.constraint(equalTo: v.trailingAnchor),

            logo.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 26),
            logo.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            logo.widthAnchor.constraint(equalToConstant: 88),
            logo.heightAnchor.constraint(equalToConstant: 88),
            name.topAnchor.constraint(equalTo: logo.bottomAnchor, constant: 12),
            name.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            tag.topAnchor.constraint(equalTo: name.bottomAnchor, constant: 4),
            tag.centerXAnchor.constraint(equalTo: v.centerXAnchor),

            checkButton.topAnchor.constraint(equalTo: tag.bottomAnchor, constant: 22),
            checkButton.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            checkSpinner.centerYAnchor.constraint(equalTo: checkButton.centerYAnchor),
            checkSpinner.leadingAnchor.constraint(equalTo: checkButton.trailingAnchor, constant: 12),
            lastCheckLabel.topAnchor.constraint(equalTo: checkButton.bottomAnchor, constant: 10),
            lastCheckLabel.centerXAnchor.constraint(equalTo: v.centerXAnchor),

            cardsRow.topAnchor.constraint(equalTo: lastCheckLabel.bottomAnchor, constant: 30),
            cardsRow.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 40),
            cardsRow.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -40),

            shopButton.topAnchor.constraint(equalTo: cardsRow.bottomAnchor, constant: 26),
            shopButton.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            overviewInfoLabel.topAnchor.constraint(equalTo: shopButton.bottomAnchor, constant: 14),
            overviewInfoLabel.centerXAnchor.constraint(equalTo: v.centerXAnchor)
        ])
        updateOverviewInfo()
        return v
    }

    /// Small footer line under the overview buttons: catalog freshness,
    /// network state and the data folder. Safe to call from any pane.
    func updateOverviewInfo() {
        guard overviewInfoLabel != nil else { return }
        var parts: [String] = []
        if NetworkMonitor.shared.online {
            parts.append("Online")
        } else {
            parts.append("Offline — showing cached results")
        }
        if let vals = try? caskCacheURL().resourceValues(forKeys: [.contentModificationDateKey]),
           let date = vals.contentModificationDate {
            let f = DateFormatter()
            f.dateStyle = .medium; f.timeStyle = .short
            parts.append("Catalog \(f.string(from: date))")
        }
        if let free = diskFreeBytes() {
            parts.append("Free disk \(humanSize(free))")
        }
        overviewInfoLabel?.stringValue = parts.joined(separator: " · ")
    }

    @objc func cardClicked(_ sender: StatCard) {
        if sender.tag == 1 {
            switchTo(.updates)
        } else if sender.tag == 4 {
            switchTo(.installed)
            installedSearch.stringValue = "duplicate"
            installedFilter = "duplicate"
            installedTable?.reloadData()
        } else {
            switchTo(.installed)
        }
    }

    @objc func openShop() { switchTo(.shop) }

    // MARK: Updates pane

    private func buildUpdates() -> NSView {
        let v = NSView()
        let head = header(title: "Updates", subtitle: "Download and install updates without leaving MacRefresh")
        v.addSubview(head)

        let bar = NSStackView()
        bar.orientation = .horizontal
        bar.spacing = 10
        bar.alignment = .centerY
        bar.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(bar)

        updatesSearch.placeholderString = "Search"
        updatesSearchBox = SearchBox { [weak self] text in self?.updatesFilter = text; self?.updatesTable?.reloadData() }
        updatesSearch.delegate = updatesSearchBox
        updatesSearch.translatesAutoresizingMaskIntoConstraints = false

        let seg = NSSegmentedControl(labels: ["Updates only", "All apps"], trackingMode: .selectOne,
                                     target: self, action: #selector(updatesSegment(_:)))
        seg.selectedSegment = 0
        updatesSourceFilter.removeAllItems()
        updatesSourceFilter.addItems(withTitles: ["All sources", "App Store", "Homebrew",
                                                  "Sparkle", "GitHub", "Web"])
        updatesSourceFilter.target = self
        updatesSourceFilter.action = #selector(updatesSourceChanged(_:))
        let directOnly = NSButton(checkboxWithTitle: "Direct only", target: self,
                                  action: #selector(updatesDirectOnlyClicked(_:)))
        directOnly.state = UserDefaults.standard.bool(forKey: Prefs.updatesDirectOnly) ? .on : .off
        let updateAll = NSButton(title: "Update All", target: self, action: #selector(updateAllClicked))
        updateAll.bezelStyle = .rounded
        updateAll.contentTintColor = .systemOrange

        bar.addArrangedSubview(updatesSearch)
        bar.addArrangedSubview(seg)
        bar.addArrangedSubview(updatesSourceFilter)
        bar.addArrangedSubview(directOnly)
        let spacer = NSView()
        spacer.setContentHuggingPriority(.defaultLow, for: .horizontal)
        bar.addArrangedSubview(spacer)
        bar.addArrangedSubview(updateAll)
        updatesSearch.widthAnchor.constraint(equalToConstant: 220).isActive = true

        updatesTable = makeTable(columns: [
            ("app", "App", 240), ("change", "Installed → Latest", 210), ("source", "Source", 100),
            ("progress", "Progress", 170), ("notes", "", 56), ("action", "", 110)
        ])
        updatesTable.dataSource = self
        updatesTable.delegate = self
        // Click column headers to sort (App / Installed / Source).
        for key in ["app", "change", "source"] {
            if let col = updatesTable.tableColumn(withIdentifier: NSUserInterfaceItemIdentifier(key)) {
                col.sortDescriptorPrototype = NSSortDescriptor(key: key, ascending: true)
            }
        }
        updatesTable.target = self
        updatesTable.doubleAction = #selector(updatesDoubleClick)
        updatesTable.allowsMultipleSelection = true
        updatesTable.identifier = NSUserInterfaceItemIdentifier("updates")
        let sv = container(for: updatesTable)
        v.addSubview(sv)

        NSLayoutConstraint.activate([
            head.topAnchor.constraint(equalTo: v.topAnchor),
            head.leadingAnchor.constraint(equalTo: v.leadingAnchor),
            head.trailingAnchor.constraint(equalTo: v.trailingAnchor),
            bar.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 4),
            bar.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            bar.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            sv.topAnchor.constraint(equalTo: bar.bottomAnchor, constant: 10),
            sv.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            sv.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            sv.bottomAnchor.constraint(equalTo: v.bottomAnchor, constant: -16)
        ])
        return v
    }

    @objc func updatesSegment(_ seg: NSSegmentedControl) {
        updatesOnly = seg.selectedSegment == 0
        updatesTable.reloadData()
    }

    @objc func updatesDirectOnlyClicked(_ sender: NSButton) {
        UserDefaults.standard.set(sender.state == .on, forKey: Prefs.updatesDirectOnly)
        updatesTable.reloadData()
    }

    @objc func updatesSourceChanged(_ sender: NSPopUpButton) {
        updatesTable.reloadData()
    }

    @objc func updatesDoubleClick() {
        let r = updatesTable.clickedRow
        let list = filteredUpdates()
        guard r >= 0, r < list.count else { return }
        startDownloadOrOpen(list[r])
    }

    @objc func updateAllClicked() {
        // Use the multi-selection when the user picked rows, otherwise all.
        let list = filteredUpdates()
        let picks = updatesTable.selectedRowIndexes.compactMap { (i) -> AppRow? in
            i < list.count ? list[i] : nil
        }
        let targets = picks.isEmpty ? list.filter { $0.status == .update } : picks
        for row in targets where row.status == .update { startDownloadOrOpen(row) }
    }

    // MARK: Installed pane

    private func buildInstalled() -> NSView {
        let v = NSView()
        let head = header(title: "Installed Apps", subtitle: "Everything MacRefresh found in /Applications, ~/Applications and your Desktop (and Downloads if enabled)")
        v.addSubview(head)

        let bar = NSStackView()
        bar.orientation = .horizontal
        bar.spacing = 10
        bar.alignment = .centerY
        bar.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(bar)
        installedSearch.placeholderString = "Search installed apps"
        installedSearchBox = SearchBox { [weak self] text in self?.installedFilter = text; self?.installedTable?.reloadData() }
        installedSearch.delegate = installedSearchBox
        installedSearch.translatesAutoresizingMaskIntoConstraints = false
        bar.addArrangedSubview(installedSearch)
        installedSearch.widthAnchor.constraint(equalToConstant: 220).isActive = true
        installedKindFilter.removeAllItems()
        installedKindFilter.addItems(withTitles: ["All apps", "Duplicates", "App Store",
                                                  "Universal", "Apple Silicon", "Intel",
                                                  "Unsigned", "Quarantined"])
        installedKindFilter.target = self
        installedKindFilter.action = #selector(installedKindChanged(_:))
        bar.addArrangedSubview(installedKindFilter)

        installedTable = makeTable(columns: [
            ("app", "App", 230), ("kind", "Kind", 96), ("size", "Size", 80),
            ("signature", "Signature", 92), ("installed", "Installed", 92),
            ("modified", "Modified", 92), ("latest", "Latest", 104),
            ("source", "Source", 92), ("status", "Status", 150)
        ])
        installedTable.dataSource = self
        installedTable.delegate = self
        installedTable.target = self
        installedTable.doubleAction = #selector(installedDoubleClick)
        installedTable.allowsMultipleSelection = true
        for col in installedTable.tableColumns {
            col.sortDescriptorPrototype = NSSortDescriptor(
                key: col.identifier.rawValue, ascending: true)
        }
        installedTable.identifier = NSUserInterfaceItemIdentifier("installed")
        let sv = container(for: installedTable)
        sv.hasHorizontalScroller = true
        v.addSubview(sv)

        let actions = NSStackView()
        actions.orientation = .horizontal
        actions.spacing = 8
        actions.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(actions)
        let open = NSButton(title: "Open App", target: self, action: #selector(openSelectedApp))
        let reveal = NSButton(title: "Reveal", target: self, action: #selector(revealSelectedApp))
        let update = NSButton(title: "Get Update", target: self, action: #selector(updateSelectedApp))
        let homepage = NSButton(title: "Homepage", target: self, action: #selector(openSelectedHomepage))
        let ignore = NSButton(title: "Ignore / Unignore", target: self, action: #selector(toggleIgnoreSelected))
        let verify = NSButton(title: "Verify Signature", target: self, action: #selector(verifySelectedApp))
        let bulkVerify = NSButton(title: "Verify All Signatures", target: self,
                                  action: #selector(verifyAllSignaturesClicked))
        let quickLook = NSButton(title: "Quick Look", target: self, action: #selector(quickLookSelected))
        let data = NSButton(title: "Show App Data", target: self, action: #selector(revealSelectedData))
        let uninstall = NSButton(title: "Uninstall…", target: self, action: #selector(uninstallSelected))
        let quickClear = NSButton(title: "Quick Clear Duplicates", target: self,
                                  action: #selector(quickClearDuplicates))
        let quickUpdateDups = NSButton(title: "Quick Update Older Copies", target: self,
                                       action: #selector(quickUpdateDuplicates))
        let resolveDups = NSButton(title: "Resolve Duplicates…", target: self,
                                   action: #selector(resolveDuplicatesClicked))
        for b in [open, reveal, quickLook, update, homepage, ignore, verify, bulkVerify, data,
                  quickClear, quickUpdateDups, resolveDups, uninstall] {
            b.bezelStyle = .rounded
            actions.addArrangedSubview(b)
        }

        NSLayoutConstraint.activate([
            head.topAnchor.constraint(equalTo: v.topAnchor),
            head.leadingAnchor.constraint(equalTo: v.leadingAnchor),
            head.trailingAnchor.constraint(equalTo: v.trailingAnchor),
            bar.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 4),
            bar.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            bar.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            sv.topAnchor.constraint(equalTo: bar.bottomAnchor, constant: 10),
            sv.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            sv.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            actions.topAnchor.constraint(equalTo: sv.bottomAnchor, constant: 10),
            actions.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            actions.bottomAnchor.constraint(equalTo: v.bottomAnchor, constant: -14)
        ])
        return v
    }

    @objc func installedDoubleClick() { openSelectedApp() }

    @objc func installedKindChanged(_ sender: NSPopUpButton) {
        installedTable.reloadData()
        let kind = sender.titleOfSelectedItem ?? "All apps"
        if ["Universal", "Apple Silicon", "Intel"].contains(kind) {
            // Arch metadata is computed lazily; warm it and refresh as it lands.
            BundleMetaCache.shared.prefetch(paths: rows.map { $0.path }) { [weak self] in
                DispatchQueue.main.async { self?.installedTable?.reloadData() }
            }
        } else if kind == "Unsigned" {
            // Signature summaries are computed lazily; verify all and filter.
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                guard let self = self else { return }
                for r in self.rows {
                    if SignatureCache.shared.cached(for: r.path) == nil {
                        let sem = DispatchSemaphore(value: 0)
                        SignatureCache.shared.signature(for: r.path) { _, _ in sem.signal() }
                        _ = sem.wait(timeout: .now() + 20)
                    }
                }
                DispatchQueue.main.async { self.installedTable?.reloadData() }
            }
        }
    }

    @objc func quickLookSelected() {
        guard let row = selectedInstalledRows().first else { return }
        // Show the system Quick Look preview without launching the app.
        let p = Process()
        p.launchPath = "/usr/bin/qlmanage"
        p.arguments = ["-p", row.path]
        try? p.run()
    }
    func selectedInstalledRows() -> [AppRow] {
        let list = filteredInstalled()
        let idxs = installedTable.selectedRowIndexes
        var out: [AppRow] = []
        for i in idxs where i < list.count { out.append(list[i]) }
        return out
    }
    @objc func openSelectedApp() {
        guard let row = selectedInstalledRows().first else { return }
        NSWorkspace.shared.openApplication(at: URL(fileURLWithPath: row.path), configuration: .init())
    }
    @objc func revealSelectedApp() {
        let rows = selectedInstalledRows()
        guard !rows.isEmpty else { return }
        NSWorkspace.shared.activateFileViewerSelecting(rows.map { URL(fileURLWithPath: $0.path) })
    }
    @objc func updateSelectedApp() {
        for row in selectedInstalledRows() { startDownloadOrOpen(row) }
    }
    @objc func toggleIgnoreSelected() {
        let rows = selectedInstalledRows()
        guard !rows.isEmpty else { return }
        var ids = Prefs.ignoredIDs
        for row in rows {
            if ids.contains(row.bundleID) { ids.removeAll { $0 == row.bundleID } }
            else { ids.append(row.bundleID) }
        }
        Prefs.ignoredIDs = ids
        rescan(initial: false)
    }
    @objc func verifySelectedApp() {
        guard let row = selectedInstalledRows().first else { return }
        verifySignature(row: row)
    }
    @objc func revealSelectedData() {
        guard let row = selectedInstalledRows().first else { return }
        revealAppData(row: row)
    }
    @objc func uninstallSelected() {
        let rows = selectedInstalledRows()
        guard !rows.isEmpty else { return }
        let names = rows.map { $0.name }.joined(separator: ", ")
        if UserDefaults.standard.bool(forKey: Prefs.confirmUninstall) {
            let alert = NSAlert()
            alert.messageText = "Uninstall \(names)?"
            alert.informativeText = "The app(s) will be moved to the Trash. Preferences and data are left untouched."
            alert.addButton(withTitle: "Move to Trash")
            alert.addButton(withTitle: "Cancel")
            alert.alertStyle = .warning
            guard alert.runModal() == .alertFirstButtonReturn else { return }
        }
        // Quit running apps before trashing so the move does not fail.
        for row in rows {
            Installer.quitAppTree(destPath: row.path,
                                  bundleIDs: row.bundleID.isEmpty ? [] : [row.bundleID])
        }
        NSWorkspace.shared.recycle(rows.map { URL(fileURLWithPath: $0.path) }) { [weak self] _, error in
            DispatchQueue.main.async {
                if let error = error {
                    let a = NSAlert()
                    a.messageText = "Some apps could not be moved to Trash"
                    a.informativeText = error.localizedDescription
                    a.addButton(withTitle: "OK"); a.runModal()
                }
                self?.rescan(initial: false)
            }
        }
    }

    func selectedInstalledRow() -> AppRow? { selectedInstalledRows().first }

    // MARK: Shop pane

    private func buildShop() -> NSView {
        let v = NSView()
        let head = header(title: "Free App Shop", subtitle: "Free apps installed straight from their official sources via Homebrew casks")
        v.addSubview(head)

        let bar = NSStackView()
        bar.orientation = .horizontal
        bar.spacing = 10
        bar.alignment = .centerY
        bar.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(bar)
        shopSearch.placeholderString = "Search free apps"
        shopSearchBox = SearchBox { [weak self] text in self?.shopFilter = text; self?.shopTable?.reloadData() }
        shopSearch.delegate = shopSearchBox
        shopSearch.translatesAutoresizingMaskIntoConstraints = false
        bar.addArrangedSubview(shopSearch)
        shopSearch.widthAnchor.constraint(equalToConstant: 240).isActive = true

        shopCategory.addItems(withTitles: ["All categories"] + shopCatalog.map { $0.category })
        shopCategory.target = self
        shopCategory.action = #selector(shopCategoryChanged)
        bar.addArrangedSubview(shopCategory)

        shopFilterSegment = NSSegmentedControl(labels: ["All", "Not installed", "Installed", "Favorites"],
                                                trackingMode: .selectOne,
                                                target: self, action: #selector(shopFilterSegmentChanged))
        shopFilterSegment.selectedSegment = 0
        bar.addArrangedSubview(shopFilterSegment)

        let installSelected = NSButton(title: "Install Selected", target: self,
                                       action: #selector(shopInstallSelected))
        installSelected.bezelStyle = .rounded
        installSelected.contentTintColor = .systemGreen
        bar.addArrangedSubview(installSelected)

        let installCategory = NSButton(title: "Install All Shown", target: self,
                                       action: #selector(shopInstallAllShown))
        installCategory.bezelStyle = .rounded
        bar.addArrangedSubview(installCategory)

        let refreshShop = NSButton(title: "Refresh catalog", target: self,
                                   action: #selector(refreshShopClicked))
        refreshShop.bezelStyle = .rounded
        bar.addArrangedSubview(refreshShop)

        shopTable = makeTable(columns: [
            ("app", "App", 330), ("category", "Category", 108), ("version", "Version", 92),
            ("minos", "Requires", 74), ("status", "Status", 92), ("action", "", 118)
        ])
        shopTable.rowHeight = 44
        shopTable.dataSource = self
        shopTable.delegate = self
        shopTable.target = self
        shopTable.doubleAction = #selector(shopDoubleClick)
        shopTable.allowsMultipleSelection = true
        for col in shopTable.tableColumns {
            col.sortDescriptorPrototype = NSSortDescriptor(key: col.identifier.rawValue, ascending: true)
        }
        shopTable.identifier = NSUserInterfaceItemIdentifier("shop")
        let sv = container(for: shopTable)
        v.addSubview(sv)

        let note = makeLabel("All listed apps are free. Downloads come from each developer's official URL as published in the Homebrew cask catalog. Nothing is paid, cracked, or repackaged.",
                             size: 11, color: .tertiaryLabelColor)
        note.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(note)

        NSLayoutConstraint.activate([
            head.topAnchor.constraint(equalTo: v.topAnchor),
            head.leadingAnchor.constraint(equalTo: v.leadingAnchor),
            head.trailingAnchor.constraint(equalTo: v.trailingAnchor),
            bar.topAnchor.constraint(equalTo: head.bottomAnchor, constant: 4),
            bar.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            bar.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            sv.topAnchor.constraint(equalTo: bar.bottomAnchor, constant: 10),
            sv.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 20),
            sv.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -20),
            note.topAnchor.constraint(equalTo: sv.bottomAnchor, constant: 8),
            note.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 22),
            note.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -22),
            note.bottomAnchor.constraint(equalTo: v.bottomAnchor, constant: -12)
        ])
        return v
    }

    @objc func shopCategoryChanged() { shopTable.reloadData() }
    @objc func shopFilterSegmentChanged() { shopTable.reloadData() }

    /// Install every currently selected, not-yet-installed shop item.
    @objc func shopInstallSelected() {
        let list = filteredShop()
        var started = 0
        for i in shopTable.selectedRowIndexes where i < list.count {
            let item = list[i]
            if item.installedPath == nil { startShopInstall(item); started += 1 }
        }
        if started > 0 { switchTo(.downloads) }
    }

    /// Install every not-yet-installed item currently visible in the shop.
    @objc func shopInstallAllShown() {
        let list = filteredShop().filter { $0.installedPath == nil }
        guard !list.isEmpty else { return }
        let a = NSAlert()
        a.messageText = "Install \(list.count) apps?"
        a.informativeText = list.prefix(20).map { $0.cask.names.first ?? $0.cask.token }.joined(separator: ", ")
            + (list.count > 20 ? " and \(list.count - 20) more" : "")
        a.addButton(withTitle: "Install all")
        a.addButton(withTitle: "Cancel")
        guard a.runModal() == .alertFirstButtonReturn else { return }
        for item in list { startShopInstall(item) }
        switchTo(.downloads)
    }

    @objc func refreshShopClicked() {
        Maintenance.clearCatalog()
        loadCaskIndex(forceRefresh: true) { [weak self] map, list in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.ingestCasks(map: map, list: list)
                self.rebuildShop()
                self.shopTable?.reloadData()
                self.refreshCatalogDate()
            }
        }
    }

    @objc func toggleShopFavorite(_ sender: NSMenuItem) {
        guard let token = sender.representedObject as? String else { return }
        var favs = Prefs.shopFavorites
        if favs.contains(token) { favs.removeAll { $0 == token } } else { favs.append(token) }
        Prefs.shopFavorites = favs
        shopTable.reloadData()
    }

    @objc func shopDoubleClick() {
        let r = shopTable.clickedRow
        let list = filteredShop()
        guard r >= 0, r < list.count else { return }
        let item = list[r]
        if item.installedPath == nil { startShopInstall(item) }
        else if let p = item.installedPath { NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: p)]) }
    }

    func sortShop(_ list: [ShopItem]) -> [ShopItem] {
        let cmp: (ShopItem, ShopItem) -> ComparisonResult
        switch shopSortKey {
        case "category":
            cmp = { $0.category.localizedCaseInsensitiveCompare($1.category) }
        case "version":
            cmp = { compareVersions($0.cask.version, $1.cask.version) }
        case "status":
            cmp = { ($0.installedPath != nil ? "0" : "1").compare($1.installedPath != nil ? "0" : "1") }
        default:
            cmp = { ($0.cask.names.first ?? $0.cask.token)
                .localizedCaseInsensitiveCompare($1.cask.names.first ?? $1.cask.token) }
        }
        var out = list.sorted { cmp($0, $1) == .orderedAscending }
        if !shopSortAsc { out.reverse() }
        return out
    }

    func sortInstalled(_ list: [AppRow]) -> [AppRow] {
        if installedSortKey == "size" {
            // Cached values only — sorting must never enumerate on the main
            // thread; unknown sizes sort neutrally until prefetch completes.
            return list.sorted {
                let a = BundleMetaCache.shared.cachedSize(for: $0.path) ?? 0
                let b = BundleMetaCache.shared.cachedSize(for: $1.path) ?? 0
                return installedSortAsc ? a < b : a > b
            }
        }
        let cmp: (AppRow, AppRow) -> ComparisonResult
        switch installedSortKey {
        case "kind":
            cmp = { (BundleMetaCache.shared.cachedArchitecture(for: $0.path) ?? "…")
                .localizedCaseInsensitiveCompare(
                    BundleMetaCache.shared.cachedArchitecture(for: $1.path) ?? "…") }
        case "installed":
            cmp = { compareVersions($0.installed, $1.installed) }
        case "latest":
            cmp = { compareVersions($0.latest ?? "", $1.latest ?? "") }
        case "source":
            cmp = { $0.source.localizedCaseInsensitiveCompare($1.source) }
        case "status":
            cmp = { statusText($0.status).localizedCaseInsensitiveCompare(statusText($1.status)) }
        default:
            cmp = { $0.name.localizedCaseInsensitiveCompare($1.name) }
        }
        var out = list.sorted { cmp($0, $1) == .orderedAscending }
        if !installedSortAsc { out.reverse() }
        return out
    }

    // MARK: (Downloads pane builder lives in UI2.swift)
}
