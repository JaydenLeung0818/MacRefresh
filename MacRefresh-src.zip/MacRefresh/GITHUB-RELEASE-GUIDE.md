# Publishing MacRefresh to GitHub — release & copyright-safety guide

Follow this end to end for the **v1.0.0 public release**. The commands assume you are inside the project folder (`MacRefresh/`) and have the GitHub CLI (`gh`) installed; the web equivalents are noted where relevant.

---

## 1. Before you publish: the copyright / trademark checklist

This is the part that matters most after a suspension. Go through every box and only publish when all are true.

### 1.1 Name and identity
- [ ] The product name is **MacRefresh** everywhere — app name, bundle display name, bundle id, menu bar, About panel, window titles, README, release notes, screenshots.
- [ ] **No** reference to the discontinued product this was inspired by, or to its developer/company, in the code, binary, app name, repo name, UI, docs, screenshots, or release notes.
- [ ] The repository name is **`MacRefresh`** (or `macrefresh`) — do not reuse the old name or a "fixed/mod" style name that implies it is a repackaging of someone else's product.
- [ ] The description says it is an **independent, original** app, not a fork, patch, or re-host of an existing app.

### 1.2 Code and assets
- [ ] No third-party source code is included. The whole app is original Swift compiled with Apple's toolchain.
- [ ] No third-party **icons, images, or artwork** are bundled. The app icon is your own original artwork (transparent `AppIcon.icns`).
- [ ] Third-party **app names/icons** (e.g. the apps shown in the Shop) are only fetched at runtime from public sources and are clearly property of their owners — they are not shipped in your repo. The LICENSE/README state this.
- [ ] No copies of other applications' binaries, installers, or DMGs are committed or attached.
- [ ] The MIT `LICENSE` file is present with holder **"MacRefresh contributors"**, plus the note that referenced product names belong to their owners.
- [ ] No copyrighted text or help content from another product is copied.

### 1.3 What the app actually does
- [ ] The Shop only links to **official** developer downloads as published in the public Homebrew cask catalog — it never hosts, cracks, patches, or repackages anything.
- [ ] No piracy, key generators, bypasses, or paid-app redistribution.
- [ ] Release notes and README describe behavior honestly (no "official", no endorsement language, no comparison that names another product negatively).

### 1.4 Quick verification commands
```bash
# Nothing should print (no old name / old developer anywhere in source)
grep -rniE "macupdater|corecode" src/ README.md LICENSE GITHUB-RELEASE-GUIDE.md || echo "clean"

# Binary should not contain the old name either
strings MacRefresh.app/Contents/MacOS/MacRefresh | grep -iE "macupdater|corecode" || echo "binary clean"
```

> GitHub suspensions for this kind of project are usually trademark/name or content complaints. An original name, original icon, original code, MIT license, and a description that clearly states independence prevent almost all of them. If GitHub asks anything, the LICENSE + this checklist + the fact that you redistribute nothing are your answer.

---

## 2. Prepare the local repository

```bash
cd MacRefresh            # the folder containing src/, README.md, LICENSE, ...
chmod +x build.sh
git init -b main
git add .gitignore LICENSE README.md build.sh AppIcon.icns icon.png src/
git status               # confirm NO app bundle, DMG, cask.json or .DS_Store staged
```

The included `.gitignore` keeps these out of the commit (they are build output or machine-specific):

- `MacRefresh.app/`
- `*.dmg`, `*.zip`, `MacRefresh-src.zip`
- `.DS_Store`, `*.iconset`
- logs and Swift build folders

> `icon.png` is your original 2048×2048 artwork (used for the README header). `AppIcon.icns` is the built icon. Keep both.

---

## 3. Commit and tag

```bash
git commit -m "MacRefresh v1.0.0 public release"
git tag -a v1.0.0 -m "MacRefresh v1.0.0"
```

---

## 4. Create the GitHub repository

### Option A — GitHub CLI (fastest)

```bash
gh auth login                 # one time, follow the browser prompt
gh repo create MacRefresh --public --source=. --remote=origin --push
git push origin v1.0.0
```

### Option B — website

1. Go to https://github.com/new
2. Repository name: **MacRefresh**; choose **Public**; do **not** add a README/license there (you already have them).
3. Then run the commands GitHub shows to connect your existing folder, ending with:
   ```bash
   git remote add origin https://github.com/<your-username>/MacRefresh.git
   git push -u origin main
   git push origin v1.0.0
   ```

---

## 5. Build the release artifacts

Build a **universal** app so the same DMG works on Apple Silicon and Intel:

```bash
UNIVERSAL=1 ./build.sh
```

### 5.1 Create the DMG

```bash
STAGE=$(mktemp -d)/MacRefresh
mkdir -p "$STAGE"
cp -R MacRefresh.app "$STAGE/"
cp README.md "$STAGE/"
ln -s /Applications "$STAGE/Applications"
hdiutil create -volname MacRefresh -fs HFS+ -format UDZO -imagekey zlib-level=9 \
  -srcfolder "$STAGE" MacRefresh.dmg
```

### 5.2 Create the source archive

```bash
mkdir -p release-src/MacRefresh
cp -R src build.sh AppIcon.icns icon.png README.md LICENSE .gitignore release-src/MacRefresh/
find release-src -name '.DS_Store' -delete
cd release-src && zip -r -X ../MacRefresh-src.zip MacRefresh && cd ..
rm -rf release-src
```

### 5.3 (Recommended) checksums

```bash
shasum -a 256 MacRefresh.dmg MacRefresh-src.zip > SHA256SUMS.txt
```

### 5.4 Final gate before attaching

```bash
# App reports the right version
defaults read MacRefresh.app/Contents/Info.plist CFBundleShortVersionString    # -> 1.0.0

# Universal binary (should print arm64 x86_64)
lipo -archs MacRefresh.app/Contents/MacOS/MacRefresh

# Self-tests pass (180 checks, writes only to a temp dir)
./MacRefresh.app/Contents/MacOS/MacRefresh --selfcheck
```

---

## 6. Publish the release

### GitHub CLI

```bash
gh release create v1.0.0 \
  --title "MacRefresh v1.0.0" \
  --notes "Independent open-source app updater for macOS. See README.md for features and usage." \
  MacRefresh.dmg MacRefresh-src.zip SHA256SUMS.txt
```

### Website

1. Open https://github.com/`<your-username>`/MacRefresh/releases/new
2. Choose tag **v1.0.0**, title **MacRefresh v1.0.0**.
3. Write short, factual release notes (see below).
4. Attach `MacRefresh.dmg`, `MacRefresh-src.zip`, and `SHA256SUMS.txt`.
5. Publish.

### Suggested release notes (safe, factual)

```
MacRefresh v1.0.0 — first public release.

An independent, open-source macOS app updater. Scans installed apps,
checks multiple public update sources with strict version rules, and
downloads and installs updates in-app. Includes a free app shop,
a download queue, duplicate handling, signatures, reports and a
menu-bar item.

- Universal: works on Apple Silicon and Intel (macOS 12.4+)
- Download MacRefresh.dmg, or build from MacRefresh-src.zip
- MIT licensed; no accounts, tracking, or bundled third-party software.
The app is ad-hoc signed: if Gatekeeper prompts, right-click → Open.
```

---

## 7. After publishing

- [ ] Download the DMG from a fresh account/browser (or the link in a private window) to confirm it mounts and the app launches.
- [ ] Verify the SHA256 of the downloaded DMG matches `SHA256SUMS.txt`.
- [ ] Pin a short issue/notice that the app is independent and MIT-licensed.
- [ ] If you ever receive a complaint, do not argue publicly — review the specific item, rename or remove it, and reply with the corrective change.

## 8. Recommended repo settings (avoid future problems)

- Add topics: `macos`, `app-updater`, `swift`, `homebrew-cask`, `software-updater`, `appstore`.
- Disable third-party packages you don't need; keep the dependency list empty.
- Releasing updates later: bump the version in `src/Core.swift` and the `Info.plist`
  (both set via `build.sh`), tag `v1.0.1`, and repeat steps 5–6.
